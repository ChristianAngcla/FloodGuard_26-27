import { apiUrl } from '../config/api';

let engineDataCache = null;
let engineDataPromise = null;

export const fetchSharedEngineData = () => {
  if (engineDataPromise) {
    return engineDataPromise;
  }
  engineDataPromise = fetch(apiUrl('/api/status'))
    .then((res) => res.json())
    .then((data) => {
      engineDataCache = data;
      return data;
    })
    .catch((err) => {
      engineDataPromise = null; // allow retry on fail
      console.error("Engine API Error:", err);
      throw err;
    });
  return engineDataPromise;
};

export const forceRefreshEngineData = () => {
  engineDataPromise = fetch(apiUrl('/api/status'))
    .then((res) => res.json())
    .then((data) => {
      engineDataCache = data;
      return data;
    })
    .catch((err) => {
      engineDataPromise = null;
      console.error("Engine API Error:", err);
      throw err;
    });
  return engineDataPromise;
};

export const getSharedEngineDataCache = () => engineDataCache;

let dailyForecastCache = null;
let dailyForecastPromise = null;

export const fetchSharedDailyForecast = () => {
  if (dailyForecastPromise) {
    return dailyForecastPromise;
  }
  dailyForecastPromise = fetch(apiUrl('/api/forecasts/daily'))
    .then((res) => res.json())
    .then((data) => {
      dailyForecastCache = data;
      return data;
    })
    .catch((err) => {
      dailyForecastPromise = null; // allow retry on fail
      console.error("Daily Forecast API Error:", err);
      throw err;
    });
  return dailyForecastPromise;
};

export const forceRefreshDailyForecast = () => {
  dailyForecastPromise = fetch(apiUrl('/api/forecasts/daily'))
    .then((res) => res.json())
    .then((data) => {
      dailyForecastCache = data;
      return data;
    })
    .catch((err) => {
      dailyForecastPromise = null;
      console.error("Daily Forecast API Error:", err);
      throw err;
    });
  return dailyForecastPromise;
};

export const getSharedDailyForecastCache = () => dailyForecastCache;

