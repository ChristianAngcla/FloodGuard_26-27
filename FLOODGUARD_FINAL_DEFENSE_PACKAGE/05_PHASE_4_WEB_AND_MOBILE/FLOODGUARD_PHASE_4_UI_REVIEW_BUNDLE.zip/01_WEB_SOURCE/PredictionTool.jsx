import React, { useState, useEffect, useCallback } from "react";
import { MapContainer, TileLayer, GeoJSON } from "react-leaflet";
import "leaflet/dist/leaflet.css";
import marikinaGeoJSON from "../assets/data/marikina.json";
import { fetchSharedEngineData, getSharedEngineDataCache, forceRefreshEngineData, fetchSharedDailyForecast, getSharedDailyForecastCache, forceRefreshDailyForecast } from "../utils/apiCache";

const marikinaBarangays = [
  "Barangka",
  "Calumpang",
  "Concepcion Uno",
  "Concepcion Dos",
  "Fortune",
  "Industrial Valley (IVC)",
  "Jesus de la Peña",
  "Malanday",
  "Marikina Heights",
  "Nangka",
  "Parang",
  "San Roque",
  "Santa Elena",
  "Santo Niño",
  "Tañong",
  "Tumana",
];

const marikinaTableData = [
  { id: 1, name: "Barangka" },
  { id: 2, name: "Calumpang" },
  { id: 3, name: "Concepcion Uno" },
  { id: 4, name: "Concepcion Dos" },
  { id: 5, name: "Fortune" },
  { id: 6, name: "Industrial Valley (IVC)" },
  { id: 7, name: "Jesus de la Peña" },
  { id: 8, name: "Malanday" },
  { id: 9, name: "Marikina Heights" },
  { id: 10, name: "Nangka" },
  { id: 11, name: "Parang" },
  { id: 12, name: "San Roque" },
  { id: 13, name: "Santa Elena" },
  { id: 14, name: "Santo Niño" },
  { id: 15, name: "Tañong" },
  { id: 16, name: "Tumana" },
];

const getRelevantRiver = (barangayName) => {
  const nangkaGroup = [
    "Nangka",
    "Parang",
    "Fortune",
  ];
  const tumanaGroup = ["Tumana", "Malanday", "Concepcion Uno", "Marikina Heights", "Concepcion Dos"];
  const stoNinoGroup = [
    "Santo Niño",
    "Calumpang",
    "Industrial Valley (IVC)",
    "Industrial Valley",
    "Barangka",
    "San Roque",
    "Santa Elena",
    "Tañong",
    "Jesus de la Peña",
    "Jesus Dela Peña",
  ];
  if (nangkaGroup.includes(barangayName))
    return { key: "nangka", label: "Nangka River" };
  if (tumanaGroup.includes(barangayName))
    return { key: "tumana", label: "Tumana Bridge" };
  if (stoNinoGroup.includes(barangayName))
    return { key: "sto_nino", label: "Sto. Niño River" };
  return { key: "sto_nino", label: "Sto. Niño River" };
};

const defaultPagasaData = {
  cycloneBulletin: {
    active: false,
    name: "Loading...",
    category: "Loading Data...",
    center: "--",
    movement: "--",
    signalText: "--",
    lastUpdated: "--",
  },
  koicaFloodAdvisory: { stations: [], lastUpdated: "--" },
  dailyWeather: {
    location: "Marikina City",
    condition: "Loading...",
    tempRange: "--°C",
    humidity: "--%",
    heatIndex: "--°C",
    windSpeed: "-- km/h",
    lastUpdated: "--",
  },
};



/** Fallback thresholds = backend CACHE defaults. Prefer API river.thresholds when passed. */
const STATION_THRESHOLDS = {
  nangka: { critical: 17.7, alarm: 17.1, alert: 16.5 },
  tumana: { critical: 19.26, alarm: 18.26, alert: 17.26 },
  sto_nino: { critical: 17, alarm: 16, alert: 15 },
  montalban: { critical: 23.6, alarm: 23.0, alert: 22.4 },
  rosario: { critical: 15.0, alarm: 14.0, alert: 13.0 },
};

const getAlarmInfo = (level, riverKey = "sto_nino", thrOverride = null) => {
  const safeLevel = typeof level === "number" ? level : 0;
  const t =
    thrOverride || STATION_THRESHOLDS[riverKey] || STATION_THRESHOLDS.sto_nino;
  const bands = [
    { threshold: t.critical, alarm: "CRITICAL", label: "FORCE EVACUATION", color: "#dc2626", gradient: "linear-gradient(to right, #dc2626, #f87171)", bg: "#fef2f2", border: "#fecaca", textColor: "#991b1b" },
    { threshold: t.alarm, alarm: "WARNING", label: "PREPARE TO EVACUATE", color: "#ea580c", gradient: "linear-gradient(to right, #ea580c, #fb923c)", bg: "#fff7ed", border: "#fed7aa", textColor: "#9a3412" },
    { threshold: t.alert, alarm: "ALERT", label: "ALERT", color: "#ca8a04", gradient: "linear-gradient(to right, #ca8a04, #fde047)", bg: "#fefce8", border: "#fef08a", textColor: "#854d0e" },
    { threshold: -Infinity, alarm: "SAFE", label: "SAFE", color: "#16a34a", gradient: "linear-gradient(to right, #16a34a, #86efac)", bg: "#f0fdf4", border: "#bbf7d0", textColor: "#166534" },
  ];
  for (const alarm of bands) {
    if (safeLevel >= alarm.threshold) return alarm;
  }
  return bands[bands.length - 1];
};

// Dynamic River Gauge Config — colors come from station thresholds via getAlarmInfo
const getRiverGaugeConfig = (riverLabel) => {
  const label = (riverLabel || "").toLowerCase();
  let key = "sto_nino";
  if (label.includes("nangka")) key = "nangka";
  else if (label.includes("montalban")) key = "montalban";
  else if (label.includes("rosario")) key = "rosario";
  else if (label.includes("tumana")) key = "tumana";

  const t = STATION_THRESHOLDS[key] || STATION_THRESHOLDS.sto_nino;
  const criticalBand = getAlarmInfo(t.critical, key);
  const alarmBand = getAlarmInfo(t.alarm, key);
  const alertBand = getAlarmInfo(t.alert, key);

  if (key === "nangka") {
    return {
      min: 14, max: 20,
      lines: [
        { level: t.critical, alarm: criticalBand },
        { level: t.alarm, alarm: alarmBand },
        { level: t.alert, alarm: alertBand },
      ],
      ticks: [14, t.alert, t.alarm, t.critical, 20],
    };
  }
  if (key === "montalban") {
    return {
      min: 20, max: 26,
      lines: [
        { level: t.critical, alarm: criticalBand },
        { level: t.alarm, alarm: alarmBand },
        { level: t.alert, alarm: alertBand },
      ],
      ticks: [20, t.alert, t.alarm, t.critical, 26],
    };
  }
  if (key === "rosario") {
    return {
      min: 10, max: 17,
      lines: [
        { level: t.critical, alarm: criticalBand },
        { level: t.alarm, alarm: alarmBand },
        { level: t.alert, alarm: alertBand },
      ],
      ticks: [10, t.alert, t.alarm, t.critical, 17],
    };
  }
  if (key === "tumana") {
    return {
      min: 11, max: 21,
      lines: [
        { level: t.critical, alarm: criticalBand },
        { level: t.alarm, alarm: alarmBand },
        { level: t.alert, alarm: alertBand },
      ],
      ticks: [11, t.alert, t.alarm, t.critical, 21],
    };
  }
  // Sto. Niño
  return {
    min: 11, max: 20,
    lines: [
      { level: t.critical, alarm: criticalBand },
      { level: t.alarm, alarm: alarmBand },
      { level: t.alert, alarm: alertBand },
    ],
    ticks: [11, t.alert, t.alarm, t.critical, 20],
  };
};

// Visual Water Level Gauge component (Horizontal)
const WaterLevelGauge = ({ level, peakTime, riverLabel, riverKey }) => {
  const resolvedKey = riverKey || (
    (riverLabel || "").toLowerCase().includes("nangka") ? "nangka" :
    (riverLabel || "").toLowerCase().includes("tumana") ? "tumana" : "sto_nino"
  );
  const alarmInfo = getAlarmInfo(level, resolvedKey);
  const gaugeCfg = getRiverGaugeConfig(riverLabel);
  const stationThr = STATION_THRESHOLDS[resolvedKey] || STATION_THRESHOLDS.sto_nino;
  const range = gaugeCfg.max - gaugeCfg.min;
  const fillPct = Math.min(100, Math.max(0, (((level || gaugeCfg.min) - gaugeCfg.min) / range) * 100));

  return (
    <div style={{
      display: "flex", flexDirection: "column", gap: "1rem",
      marginTop: "1rem", backgroundColor: "#f8fafc",
      padding: "1.5rem", borderRadius: "16px", border: "1px solid #e2e8f0",
    }}>
      {/* Top section: reading + alarm info */}
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-end" }}>
        <div>
          <div style={{ fontSize: "0.75rem", color: "#475569", fontWeight: "700", letterSpacing: "0.08em", marginBottom: "0.25rem" }}>
            PROJECTED PEAK
          </div>
          <div style={{ fontSize: "1rem", fontWeight: "800", color: "#0f172a", marginBottom: "0.25rem" }}>
            📅 {peakTime}
          </div>
          <div style={{ fontSize: "3rem", fontWeight: "800", color: alarmInfo.color, lineHeight: 1 }}>
            {(level || 0).toFixed(2)}
            <span style={{ fontSize: "1.2rem", fontWeight: "600", marginLeft: "0.25rem" }}>m</span>
          </div>
        </div>
        <div style={{ textAlign: "right" }}>
          <div style={{
            display: "inline-flex", alignItems: "center", gap: "0.4rem",
            backgroundColor: alarmInfo.bg,
            border: `1px solid ${alarmInfo.border}`,
            borderRadius: "999px",
            padding: "0.4rem 1rem",
            marginBottom: "0.5rem",
          }}>
            <span style={{ fontSize: "0.9rem", fontWeight: "800", color: alarmInfo.textColor }}>
              {alarmInfo.alarm} — {alarmInfo.label}
            </span>
          </div>
          <div style={{ fontSize: "0.75rem", color: "#64748b", fontWeight: "600" }}>
            {riverLabel}
          </div>
        </div>
      </div>

      {/* The bar itself */}
      <div style={{ position: "relative", marginTop: "0.5rem" }}>
        <div style={{
          position: "relative", width: "100%", height: "24px",
          backgroundColor: "#e2e8f0", borderRadius: "12px",
          overflow: "hidden", border: "2px solid #cbd5e1",
        }}>
          {/* Water fill */}
          <div style={{
            position: "absolute", left: 0, top: 0, bottom: 0,
            width: `${fillPct}%`,
            background: alarmInfo.gradient,
            transition: "width 0.8s cubic-bezier(.4,0,.2,1)",
            borderRadius: "10px 0 0 10px",
          }} />
          {/* Threshold lines */}
          {gaugeCfg.lines.map(({ level: lvl, alarm }) => (
            <div key={lvl} style={{
              position: "absolute", bottom: 0, top: 0,
              left: `${((lvl - gaugeCfg.min) / range) * 100}%`,
              width: "2px", backgroundColor: alarm.color, zIndex: 2,
            }} />
          ))}
        </div>

        {/* Tick labels row */}
        <div style={{
          position: "relative",
          height: "20px",
          marginTop: "0.5rem"
        }}>
          {gaugeCfg.ticks.map((tick) => {
            const leftPct = ((tick - gaugeCfg.min) / range) * 100;
            return (
              <div key={tick} style={{
                position: "absolute",
                left: `${leftPct}%`,
                transform: "translateX(-50%)",
                display: "flex",
                flexDirection: "column",
                alignItems: "center"
              }}>
                <div style={{ width: "2px", height: "4px", backgroundColor: "#cbd5e1", marginBottom: "2px" }} />
                <span style={{
                  fontSize: "0.65rem", fontWeight: "800",
                  color: tick >= stationThr.critical ? "#dc2626"
                    : tick >= stationThr.alarm ? "#ea580c"
                    : tick >= stationThr.alert ? "#ca8a04"
                    : "#94a3b8",
                }}>{tick}m</span>
              </div>
            );
          })}
        </div>
      </div>

      {/* Legend (station-specific) */}
      <div style={{
        display: "flex", flexWrap: "wrap", gap: "1rem",
        marginTop: "0.5rem", padding: "0.8rem",
        backgroundColor: "#ffffff", borderRadius: "8px", border: "1px solid #e2e8f0"
      }}>
        {[
          { label: `CRITICAL: ≥ ${stationThr.critical}m`, color: "#dc2626" },
          { label: `WARNING: ≥ ${stationThr.alarm}m`, color: "#ea580c" },
          { label: `ALERT: ≥ ${stationThr.alert}m`, color: "#ca8a04" },
          { label: `SAFE: < ${stationThr.alert}m`, color: "#16a34a" },
        ].map((a) => (
          <div key={a.label} style={{ display: "flex", alignItems: "center", gap: "0.4rem" }}>
            <div style={{ width: "8px", height: "8px", backgroundColor: a.color, borderRadius: "2px", flexShrink: 0 }} />
            <span style={{ fontSize: "0.65rem", color: "#475569", fontWeight: "700" }}>
              {a.label}
            </span>
          </div>
        ))}
      </div>
      <p style={{ margin: "0.35rem 0 0", fontSize: "0.7rem", color: "#64748b", fontStyle: "italic" }}>
        Predictions are not 100% accurate. Follow official PAGASA/MDRRMO advisories.
      </p>
    </div>
  );
};

const getStatusColor = (status) => {
  if (status === "CRITICAL") return "#dc2626";
  if (status === "WARNING") return "#ea580c";
  if (status === "SAFE") return "#16a34a";
  return "#94a3b8";
};

const PredictionTool = () => {
  const [selectedBarangay, setSelectedBarangay] = useState("Malanday");
  const [selectedRiverKey, setSelectedRiverKey] = useState("tumana");
  const [scrapedPagasaData, setScrapedPagasaData] = useState(defaultPagasaData);
  const [engineData, setEngineData] = useState(() => getSharedEngineDataCache());
  const [dailyForecasts, setDailyForecasts] = useState(() => getSharedDailyForecastCache());

  const RIVER_OPTIONS = [
    { key: "nangka", label: "Nangka River", sampleBarangay: "Nangka" },
    { key: "sto_nino", label: "Sto. Niño River", sampleBarangay: "Calumpang" },
    { key: "tumana", label: "Tumana Bridge", sampleBarangay: "Tumana" },
  ];

  const handleRiverChange = (riverKey) => {
    const river = RIVER_OPTIONS.find((r) => r.key === riverKey);
    if (!river) return;
    setSelectedRiverKey(riverKey);
    setSelectedBarangay(river.sampleBarangay);
  };

  const handleBarangayChange = (barangay) => {
    setSelectedBarangay(barangay);
    setSelectedRiverKey(getRelevantRiver(barangay).key);
  };

  useEffect(() => {
    const fetchBackendData = async (isRefresh = false) => {
      try {
        const [data, forecastData] = await Promise.all([
          isRefresh ? forceRefreshEngineData() : fetchSharedEngineData(),
          isRefresh ? forceRefreshDailyForecast() : fetchSharedDailyForecast(),
        ]);

        if (forecastData && forecastData.stations) {
          setDailyForecasts(forecastData);
        }

        setScrapedPagasaData((prev) => ({
          ...prev,
          cycloneBulletin: {
            ...prev.cycloneBulletin,
            active: data.storm.name !== "None",
            name: data.storm.name,
            category: data.storm.category,
            center: data.storm.center,
            movement: data.storm.movement,
            signalText:
              data.storm.signal > 0
                ? `Signal ${data.storm.signal}`
                : "No Signal",
            lastUpdated: new Date().toLocaleTimeString(),
          },
          koicaFloodAdvisory: {
            ...prev.koicaFloodAdvisory,
            lastUpdated: new Date().toLocaleTimeString(),
            stations: [
              {
                name: "Sto. Niño",
                currentLevel: data.live_sensors.sto_nino,
                status: data.prediction?.rivers?.sto_nino?.status || "SAFE",
              },
              {
                name: "Tumana",
                currentLevel: data.live_sensors.tumana,
                status: data.prediction?.rivers?.tumana?.status || "SAFE",
              },
              {
                name: "Nangka",
                currentLevel: data.live_sensors.nangka,
                status: data.prediction?.rivers?.nangka?.status || "SAFE",
              },
            ],
          },
        }));

        setEngineData(data);
      } catch (err) {
        console.error("Backend Fetch Error:", err);
      }
    };

    fetchBackendData(false);
    const intervalId = setInterval(() => fetchBackendData(true), 300000);
    return () => clearInterval(intervalId);
  }, []);

  useEffect(() => {
    const fetchRealWeather = async () => {
      try {
        const res = await fetch(
          "https://api.open-meteo.com/v1/forecast?latitude=14.6408&longitude=121.1041&current=temperature_2m,relative_humidity_2m,apparent_temperature,precipitation,wind_speed_10m,weather_code&timezone=Asia%2FManila",
        );
        const data = await res.json();
        let conditionStr = "Partly Cloudy";
        const code = data.current.weather_code;
        if (code === 0) conditionStr = "Clear / Sunny";
        if (code >= 51 && code <= 65) conditionStr = "Raining";
        if (code >= 95) conditionStr = "Thunderstorms";

        setScrapedPagasaData((prev) => ({
          ...prev,
          dailyWeather: {
            ...prev.dailyWeather,
            condition: conditionStr,
            tempRange: `${Math.round(data.current.temperature_2m)}°C`,
            humidity: `${data.current.relative_humidity_2m}%`,
            heatIndex: `${Math.round(data.current.apparent_temperature)}°C`,
            windSpeed: `${Math.round(data.current.wind_speed_10m)} km/h`,
            precipitation: `${data.current.precipitation} mm`,
            lastUpdated: new Date().toLocaleTimeString(),
          },
        }));
      } catch (err) {
        console.debug("Weather fetch skipped or failed:", err);
      }
    };
    fetchRealWeather();
  }, []);

  const marikinaBounds = [
    [14.6105, 121.08],
    [14.6785, 121.1275],
  ];

  const getFeatureStyle = (feature) => {
    const barangayName = feature.properties.NAME_3;
    const isSelected = barangayName === selectedBarangay;

    let color = "#16a34a"; // Default Safe (Normal)

    const bgyForecast = dailyForecasts?.barangays?.[barangayName];
    if (bgyForecast) {
      const status = bgyForecast.statusBand;
      if (status === 'CRITICAL') color = '#dc2626';
      else if (status === 'ALARM' || status === 'WARNING') color = '#ea580c';
      else if (status === 'ALERT') color = '#ca8a04';
      else if (status === 'SAFE') color = '#16a34a';
      else color = '#94a3b8';
    } else if (engineData && engineData.live_sensors) {
      const riverKey = getRelevantRiver(barangayName).key;
      const liveWL = engineData.live_sensors[riverKey];
      if (liveWL != null) {
        const alarm = getAlarmInfo(liveWL, riverKey);
        color = alarm.color;
      }
    }

    return {
      fillColor: color,
      fillOpacity: isSelected ? 0.9 : 0.4,
      weight: isSelected ? 3 : 1.5,
      color: isSelected ? "#0284c7" : "#ffffff",
      dashArray: isSelected ? "" : "3",
    };
  };

  const onEachBarangay = (feature, layer) => {
    const barangayName = feature.properties.NAME_3;
    layer.on({
      mouseover: (e) => {
        e.target.setStyle({ fillOpacity: 0.85, weight: 3 });
        e.target.bringToFront();
      },
      mouseout: (e) => {
        e.target.setStyle(getFeatureStyle(feature));
      },
      click: () => {
        handleBarangayChange(barangayName);
      },
    });
  };

  const isCycloneActive = scrapedPagasaData.cycloneBulletin.active;
  const cycloneCardStyle = isCycloneActive
    ? {
      bg: "#ffffff",
      border: "#fecaca",
      accent: "#ef4444",
      iconBg: "#fef2f2",
      textHead: "#b91c1c",
      textBody: "#7f1d1d",
    }
    : {
      bg: "#ffffff",
      border: "#bbf7d0",
      accent: "#22c55e",
      iconBg: "#f0fdf4",
      textHead: "#15803d",
      textBody: "#166534",
    };

  const isFloodActive = scrapedPagasaData.koicaFloodAdvisory.stations.some(
    (s) => s.status !== "Normal",
  );
  const floodCardStyle = isFloodActive
    ? {
      bg: "#ffffff",
      border: "#fef08a",
      accent: "#eab308",
      iconBg: "#fefce8",
      textHead: "#a16207",
      textSub: "#854d0e",
    }
    : {
      bg: "#ffffff",
      border: "#bae6fd",
      accent: "#0ea5e9",
      iconBg: "#f0f9ff",
      textHead: "#0369a1",
      textSub: "#075985",
    };

  return (
    <div
      style={{
        minHeight: "100vh",
        background: "linear-gradient(135deg, #f0f9ff 0%, #e0f2fe 100%)",
        padding: "3rem 2rem",
      }}
    >
      <div
        style={{
          maxWidth: "1600px",
          margin: "0 auto",
          display: "flex",
          flexDirection: "column",
          gap: "2rem",
        }}
      >
        <div
          style={{
            display: "flex",
            justifyContent: "space-between",
            alignItems: "flex-end",
            flexWrap: "wrap",
            gap: "1rem",
          }}
        >
          <div>
            <h1
              style={{
                fontSize: "2.5rem",
                fontWeight: "800",
                color: "#0f172a",
                margin: "0 0 0.5rem 0",
                letterSpacing: "-0.03em",
              }}
            >
              Flood Prediction Intelligence
            </h1>
            <p style={{ fontSize: "1.1rem", color: "#475569", margin: 0 }}>
              Powered by FloodGuard and real-time APIs.
            </p>
          </div>
          {engineData && engineData.prediction.overall_status && (
            <div
              style={{
                display: "flex",
                alignItems: "center",
                gap: "0.5rem",
                backgroundColor:
                  engineData.prediction.overall_status !== "SAFE"
                    ? "#fef2f2"
                    : "#e0f2fe",
                border: `1px solid ${engineData.prediction.overall_status !== "SAFE" ? "#fecaca" : "#bae6fd"}`,
                padding: "0.5rem 1rem",
                borderRadius: "999px",
              }}
            >
              <div
                style={{
                  width: "10px",
                  height: "10px",
                  backgroundColor: getStatusColor(
                    engineData.prediction.overall_status,
                  ),
                  borderRadius: "50%",
                }}
              ></div>
              <span
                style={{
                  fontSize: "0.85rem",
                  fontWeight: "700",
                  color:
                    engineData.prediction.overall_status !== "SAFE"
                      ? "#b91c1c"
                      : "#0369a1",
                }}
              >
                City-Wide Status: {engineData.prediction.overall_status}
              </span>
            </div>
          )}
        </div>

        <div
          style={{
            display: "grid",
            gridTemplateColumns: "repeat(auto-fit, minmax(350px, 1fr))",
            gap: "1.5rem",
          }}
        >
          <div
            style={{
              backgroundColor: cycloneCardStyle.bg,
              borderRadius: "16px",
              border: `1px solid ${cycloneCardStyle.border}`,
              borderTop: `6px solid ${cycloneCardStyle.accent}`,
              padding: "1.5rem",
              boxShadow: "0 10px 25px -5px rgba(0,0,0,0.05)",
              display: "flex",
              flexDirection: "column",
            }}
          >
            <div
              style={{
                display: "flex",
                justifyContent: "space-between",
                marginBottom: "1rem",
              }}
            >
              <div
                style={{
                  display: "flex",
                  alignItems: "center",
                  gap: "0.75rem",
                }}
              >
                <span style={{ fontSize: "1.5rem" }}>
                  {isCycloneActive ? "🌀" : "☀️"}
                </span>
                <div>
                  <h3
                    style={{
                      margin: 0,
                      color: cycloneCardStyle.textHead,
                      fontSize: "1rem",
                      fontWeight: "800",
                    }}
                  >
                    Tropical Cyclone
                  </h3>
                  <span style={{ fontSize: "0.75rem", color: "#64748b" }}>
                    Updated: {scrapedPagasaData.cycloneBulletin.lastUpdated}
                  </span>
                </div>
              </div>
            </div>
            <div
              style={{
                flex: 1,
                backgroundColor: cycloneCardStyle.iconBg,
                padding: "1rem",
                borderRadius: "12px",
                border: `1px solid ${cycloneCardStyle.border}`,
                marginBottom: "1rem",
                display: "flex",
                flexDirection: "column",
                gap: "0.5rem",
              }}
            >
              <div style={{ display: "flex", justifyContent: "space-between" }}>
                <span
                  style={{
                    fontSize: "0.85rem",
                    color: cycloneCardStyle.textHead,
                    fontWeight: "600",
                  }}
                >
                  Name:
                </span>
                <span
                  style={{
                    fontSize: "0.85rem",
                    color: cycloneCardStyle.textBody,
                    fontWeight: "800",
                  }}
                >
                  {scrapedPagasaData.cycloneBulletin.name}
                </span>
              </div>
              <div style={{ display: "flex", justifyContent: "space-between" }}>
                <span
                  style={{
                    fontSize: "0.85rem",
                    color: cycloneCardStyle.textHead,
                    fontWeight: "600",
                  }}
                >
                  Status:
                </span>
                <span
                  style={{
                    fontSize: "0.85rem",
                    color: cycloneCardStyle.textBody,
                    fontWeight: "800",
                  }}
                >
                  {scrapedPagasaData.cycloneBulletin.category}
                </span>
              </div>
              {isCycloneActive && (
                <>
                  <div
                    style={{ display: "flex", justifyContent: "space-between" }}
                  >
                    <span
                      style={{
                        fontSize: "0.85rem",
                        color: cycloneCardStyle.textHead,
                        fontWeight: "600",
                      }}
                    >
                      Center:
                    </span>
                    <span
                      style={{
                        fontSize: "0.85rem",
                        color: cycloneCardStyle.textBody,
                        fontWeight: "800",
                        textAlign: "right",
                        maxWidth: "65%",
                      }}
                    >
                      {scrapedPagasaData.cycloneBulletin.center}
                    </span>
                  </div>
                  <div
                    style={{ display: "flex", justifyContent: "space-between" }}
                  >
                    <span
                      style={{
                        fontSize: "0.85rem",
                        color: cycloneCardStyle.textHead,
                        fontWeight: "600",
                      }}
                    >
                      Movement:
                    </span>
                    <span
                      style={{
                        fontSize: "0.85rem",
                        color: cycloneCardStyle.textBody,
                        fontWeight: "800",
                        textAlign: "right",
                        maxWidth: "65%",
                      }}
                    >
                      {scrapedPagasaData.cycloneBulletin.movement}
                    </span>
                  </div>
                  <div
                    style={{ display: "flex", justifyContent: "space-between" }}
                  >
                    <span
                      style={{
                        fontSize: "0.85rem",
                        color: cycloneCardStyle.textHead,
                        fontWeight: "600",
                      }}
                    >
                      Warning:
                    </span>
                    <span
                      style={{
                        fontSize: "0.85rem",
                        color: cycloneCardStyle.textBody,
                        fontWeight: "800",
                      }}
                    >
                      {scrapedPagasaData.cycloneBulletin.signalText}
                    </span>
                  </div>
                </>
              )}
            </div>
          </div>

          <div
            style={{
              backgroundColor: "#ffffff",
              borderRadius: "16px",
              border: "1px solid #bae6fd",
              borderTop: "6px solid #0ea5e9",
              padding: "1.5rem",
              boxShadow: "0 10px 25px -5px rgba(14, 165, 233, 0.1)",
              display: "flex",
              flexDirection: "column",
            }}
          >
            <div
              style={{
                display: "flex",
                justifyContent: "space-between",
                marginBottom: "1rem",
              }}
            >
              <div
                style={{
                  display: "flex",
                  alignItems: "center",
                  gap: "0.75rem",
                }}
              >
                <span style={{ fontSize: "1.5rem" }}>🌤️</span>
                <div>
                  <h3
                    style={{
                      margin: 0,
                      color: "#0369a1",
                      fontSize: "1rem",
                      fontWeight: "800",
                    }}
                  >
                    Daily Weather
                  </h3>
                  <span style={{ fontSize: "0.75rem", color: "#64748b" }}>
                    Updated: {scrapedPagasaData.dailyWeather.lastUpdated}
                  </span>
                </div>
              </div>
            </div>
            <div
              style={{
                flex: 1,
                backgroundColor: "#f0f9ff",
                padding: "1rem",
                borderRadius: "12px",
                border: "1px solid #7dd3fc",
                marginBottom: "1rem",
              }}
            >
              <div
                style={{
                  display: "flex",
                  justifyContent: "space-between",
                  marginBottom: "0.5rem",
                }}
              >
                <span
                  style={{
                    fontSize: "0.85rem",
                    color: "#075985",
                    fontWeight: "600",
                  }}
                >
                  Condition:
                </span>
                <span
                  style={{
                    fontSize: "0.85rem",
                    color: "#0c4a6e",
                    fontWeight: "800",
                  }}
                >
                  {scrapedPagasaData.dailyWeather.condition}
                </span>
              </div>
              <div style={{ display: "flex", justifyContent: "space-between" }}>
                <span
                  style={{
                    fontSize: "0.85rem",
                    color: "#075985",
                    fontWeight: "600",
                  }}
                >
                  Temp:
                </span>
                <span
                  style={{
                    fontSize: "0.85rem",
                    color: "#0c4a6e",
                    fontWeight: "800",
                  }}
                >
                  {scrapedPagasaData.dailyWeather.tempRange}
                </span>
              </div>
              <div style={{ display: "flex", justifyContent: "space-between", marginTop: "0.5rem" }}>
                <span
                  style={{
                    fontSize: "0.85rem",
                    color: "#075985",
                    fontWeight: "600",
                  }}
                >
                  Humidity:
                </span>
                <span
                  style={{
                    fontSize: "0.85rem",
                    color: "#0c4a6e",
                    fontWeight: "800",
                  }}
                >
                  {scrapedPagasaData.dailyWeather.humidity}
                </span>
              </div>
              <div style={{ display: "flex", justifyContent: "space-between", marginTop: "0.5rem" }}>
                <span
                  style={{
                    fontSize: "0.85rem",
                    color: "#075985",
                    fontWeight: "600",
                  }}
                >
                  Heat Index:
                </span>
                <span
                  style={{
                    fontSize: "0.85rem",
                    color: "#0c4a6e",
                    fontWeight: "800",
                  }}
                >
                  {scrapedPagasaData.dailyWeather.heatIndex}
                </span>
              </div>
              <div style={{ display: "flex", justifyContent: "space-between", marginTop: "0.5rem" }}>
                <span
                  style={{
                    fontSize: "0.85rem",
                    color: "#075985",
                    fontWeight: "600",
                  }}
                >
                  Wind Speed:
                </span>
                <span
                  style={{
                    fontSize: "0.85rem",
                    color: "#0c4a6e",
                    fontWeight: "800",
                  }}
                >
                  {scrapedPagasaData.dailyWeather.windSpeed}
                </span>
              </div>
              <div style={{ display: "flex", justifyContent: "space-between", marginTop: "0.5rem" }}>
                <span
                  style={{
                    fontSize: "0.85rem",
                    color: "#075985",
                    fontWeight: "600",
                  }}
                >
                  Rain (Precip):
                </span>
                <span
                  style={{
                    fontSize: "0.85rem",
                    color: "#0c4a6e",
                    fontWeight: "800",
                  }}
                >
                  {scrapedPagasaData.dailyWeather.precipitation || "0 mm"}
                </span>
              </div>
            </div>
          </div>

          <div
            style={{
              backgroundColor: floodCardStyle.bg,
              borderRadius: "16px",
              border: `1px solid ${floodCardStyle.border}`,
              borderTop: `6px solid ${floodCardStyle.accent}`,
              padding: "1.5rem",
              boxShadow: "0 10px 25px -5px rgba(0,0,0,0.05)",
              display: "flex",
              flexDirection: "column",
            }}
          >
            <div
              style={{
                display: "flex",
                justifyContent: "space-between",
                marginBottom: "1rem",
              }}
            >
              <div
                style={{
                  display: "flex",
                  alignItems: "center",
                  gap: "0.75rem",
                }}
              >
                <span style={{ fontSize: "1.5rem" }}>🌊</span>
                <div>
                  <h3
                    style={{
                      margin: 0,
                      color: floodCardStyle.textHead,
                      fontSize: "1rem",
                      fontWeight: "800",
                    }}
                  >
                    Sensor Activity
                  </h3>
                  <span style={{ fontSize: "0.75rem", color: "#64748b" }}>
                    Updated: {scrapedPagasaData.koicaFloodAdvisory.lastUpdated}
                  </span>
                </div>
              </div>
            </div>
            <div
              style={{
                flex: 1,
                backgroundColor: floodCardStyle.iconBg,
                padding: "1rem",
                borderRadius: "12px",
                border: `1px solid ${floodCardStyle.border}`,
                display: "flex",
                flexDirection: "column",
                gap: "0.5rem",
                marginBottom: "1rem",
              }}
            >
              {scrapedPagasaData.koicaFloodAdvisory.stations.length === 0 ? (
                <div
                  style={{ fontSize: "0.85rem", color: floodCardStyle.textSub }}
                >
                  Waiting for API...
                </div>
              ) : (
                scrapedPagasaData.koicaFloodAdvisory.stations.map(
                  (station, idx) => (
                    <div
                      key={idx}
                      style={{
                        display: "flex",
                        justifyContent: "space-between",
                        alignItems: "center",
                        paddingBottom: "0.5rem",
                        borderBottom:
                          idx !== 2
                            ? `1px solid ${floodCardStyle.border}`
                            : "none",
                      }}
                    >
                      <span
                        style={{
                          fontSize: "0.85rem",
                          color: floodCardStyle.textSub,
                          fontWeight: "800",
                        }}
                      >
                        {station.name}
                      </span>
                      <span
                        style={{
                          fontSize: "0.85rem",
                          color: floodCardStyle.textSub,
                          fontWeight: "800",
                        }}
                      >
                        {station.currentLevel}m
                      </span>
                    </div>
                  ),
                )
              )}
            </div>
          </div>
        </div>

        <div
          style={{
            display: "flex",
            gap: "2rem",
            alignItems: "stretch",
            flexWrap: "wrap",
            marginTop: "2rem",
          }}
        >
          <div
            style={{
              flex: "1.2",
              minWidth: "400px",
              display: "flex",
              flexDirection: "column",
            }}
          >
            <div
              style={{
                height: "75vh",
                borderRadius: "20px",
                overflow: "hidden",
                boxShadow: "0 15px 35px -5px rgba(2, 132, 199, 0.1)",
                border: "1px solid #bae6fd",
                backgroundColor: "#ffffff",
              }}
            >
              <MapContainer
                center={[14.645, 121.105]}
                zoom={14}
                minZoom={13}
                maxBounds={marikinaBounds}
                maxBoundsViscosity={1.0}
                scrollWheelZoom={false}
                style={{ background: "#e0f2fe", height: "100%", width: "100%" }}
              >
                <TileLayer url="https://{s}.basemaps.cartocdn.com/rastertiles/voyager/{z}/{x}/{y}{r}.png" />
                {marikinaGeoJSON &&
                  engineData &&
                  engineData.prediction.overall_status && (
                    <GeoJSON
                      key={
                        engineData.prediction.overall_status + selectedBarangay
                      }
                      data={marikinaGeoJSON}
                      style={getFeatureStyle}
                      onEachFeature={onEachBarangay}
                    />
                  )}
              </MapContainer>
            </div>

            {/* --- DAILY FORECAST SUMMARY & ALERTS --- */}
            <div style={{ marginTop: "1.5rem", display: "flex", gap: "1.5rem", flexWrap: "wrap" }}>
              <div style={{ flex: "1 1 350px", padding: "1.5rem", backgroundColor: "#ffffff", border: "1px solid #bae6fd", borderRadius: "16px", boxShadow: "0 10px 25px -5px rgba(2, 132, 199, 0.1)" }}>
                <h4 style={{ fontSize: "1.1rem", fontWeight: "800", color: "#0f172a", margin: "0 0 1rem 0" }}>
                  📊 Daily Forecast & Live Status
                </h4>
                <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: "1rem" }}>
                  <div>
                    <div style={{ fontSize: "0.8rem", color: "#64748b", fontWeight: "600" }}>LIVE OBSERVED (CURRENT)</div>
                    <div style={{ fontSize: "1.1rem", fontWeight: "800", color: "#0284c7" }}>
                      {engineData?.live_sensors?.[selectedRiverKey] != null ? `${engineData.live_sensors[selectedRiverKey].toFixed(2)} m` : "--"}
                    </div>
                  </div>
                  <div>
                    <div style={{ fontSize: "0.8rem", color: "#64748b", fontWeight: "600" }}>DAILY FORECAST</div>
                    <div style={{ fontSize: "1.1rem", fontWeight: "800", color: "#0f172a" }}>
                      {dailyForecasts?.stations?.[selectedRiverKey]?.predictedWaterLevel != null ? `${dailyForecasts.stations[selectedRiverKey].predictedWaterLevel.toFixed(2)} m` : "Unavailable"}
                    </div>
                  </div>
                  <div>
                    <div style={{ fontSize: "0.8rem", color: "#64748b", fontWeight: "600" }}>FORECAST TARGET</div>
                    <div style={{ fontSize: "0.95rem", fontWeight: "800", color: "#475569" }}>
                      {dailyForecasts?.stations?.[selectedRiverKey]?.forecastTargetDate || "Next Day"}
                    </div>
                  </div>
                  <div>
                    <div style={{ fontSize: "0.8rem", color: "#64748b", fontWeight: "600" }}>CALCULATION MODE</div>
                    <div style={{ fontSize: "0.85rem", fontWeight: "800", color: "#0369a1" }}>
                      {dailyForecasts?.stations?.[selectedRiverKey]?.calculationMode === 'primary_model' ? 'PRIMARY MODEL' : (dailyForecasts?.stations?.[selectedRiverKey]?.calculationMode === 'persistence_fallback' ? 'PERSISTENCE' : 'UNAVAILABLE')}
                    </div>
                  </div>
                </div>
              </div>

              {/* Daily 07:00 AM Scheduled FCM Alert Info */}
              <div style={{ flex: "1 1 200px", display: "flex", flexDirection: "column" }}>
                <div style={{
                  padding: "1.25rem",
                  backgroundColor: "#f0f9ff",
                  border: "1px solid #bae6fd",
                  borderRadius: "16px",
                  height: "100%",
                  minHeight: "100px",
                  display: "flex",
                  flexDirection: "column",
                  justifyContent: "center",
                  gap: "0.4rem",
                  boxShadow: "0 10px 25px -5px rgba(2, 132, 199, 0.08)",
                }}>
                  <div style={{ fontSize: "0.95rem", fontWeight: 800, color: "#0c4a6e" }}>
                    Daily 07:00 AM PST Advisory
                  </div>
                  <div style={{ fontSize: "0.8rem", color: "#0369a1", lineHeight: 1.45, fontWeight: 600 }}>
                    Authoritative daily forecast advisories are automatically dispatched once per day at 07:00 AM PST to subscribed barangay topics via Firebase Cloud Messaging.
                  </div>
                  <div style={{ fontSize: "0.75rem", color: "#64748b", marginTop: "0.25rem" }}>
                    Selected: {selectedBarangay} · Sensor: {RIVER_OPTIONS.find(r => r.key === selectedRiverKey)?.label}
                  </div>
                </div>
              </div>
            </div>
          </div>

          <div
            style={{
              flex: "1",
              minWidth: "400px",
              backgroundColor: "#ffffff",
              borderRadius: "20px",
              border: "1px solid #bae6fd",
              padding: "2.5rem",
              boxShadow: "0 15px 35px -5px rgba(2, 132, 199, 0.1)",
              display: "flex",
              flexDirection: "column",
            }}
          >
            <h2
              style={{
                fontSize: "1.5rem",
                fontWeight: "800",
                color: "#0f172a",
                margin: "0 0 1.5rem 0",
              }}
            >
              Live Risk Assessment
            </h2>

            <label style={{ fontSize: "0.75rem", fontWeight: 700, color: "#64748b", letterSpacing: "0.04em" }}>
              RIVER / STATION
            </label>
            <select
              value={selectedRiverKey}
              onChange={(e) => handleRiverChange(e.target.value)}
              style={{
                width: "100%",
                padding: "0.85rem 1rem",
                fontSize: "1rem",
                fontWeight: "700",
                border: "2px solid #bae6fd",
                borderRadius: "10px",
                marginBottom: "0.75rem",
                marginTop: "0.35rem",
                backgroundColor: "#f0f9ff",
              }}
            >
              {RIVER_OPTIONS.map((river) => (
                <option key={river.key} value={river.key}>
                  {river.label}
                </option>
              ))}
            </select>

            <label style={{ fontSize: "0.75rem", fontWeight: 700, color: "#64748b", letterSpacing: "0.04em" }}>
              BARANGAY
            </label>
            <select
              value={selectedBarangay}
              onChange={(e) => handleBarangayChange(e.target.value)}
              style={{
                width: "100%",
                padding: "1rem",
                fontSize: "1.1rem",
                fontWeight: "700",
                border: "2px solid #e2e8f0",
                borderRadius: "10px",
                marginBottom: "1rem",
                marginTop: "0.35rem",
              }}
            >
              {marikinaTableData.map((brgy) => (
                <option key={brgy.name} value={brgy.name}>
                  {brgy.name}
                </option>
              ))}
            </select>

            <p style={{
              margin: "0 0 1.25rem 0",
              fontSize: "0.8rem",
              lineHeight: 1.45,
              color: "#64748b",
              fontStyle: "italic",
            }}>
              Note: FloodGuard predictions are not 100% accurate. They are decision-support estimates based on historical patterns and live inputs. Always follow official PAGASA and MDRRMO advisories.
            </p>

            {engineData ? (() => {
              const riverObj = RIVER_OPTIONS.find(r => r.key === selectedRiverKey) || RIVER_OPTIONS[0];
              const liveLvl = engineData?.live_sensors?.[selectedRiverKey];
              const stationForecast = dailyForecasts?.stations?.[selectedRiverKey];
              const hasForecast = stationForecast && stationForecast.predictedWaterLevel != null;
              const isTumana = selectedRiverKey === "tumana";

              return (
                <div style={{ flex: 1, display: "flex", flexDirection: "column", gap: "1.25rem" }}>
                  <div style={{ display: "flex", justifyContent: "space-between", alignItems: "baseline" }}>
                    <h3 style={{ fontSize: "1.1rem", fontWeight: "700", color: "#1e293b", margin: 0 }}>
                      Assessment for {selectedBarangay}
                    </h3>
                    <div style={{ fontSize: "0.75rem", color: "#64748b", fontWeight: "600" }}>
                      Sensor: {riverObj.label}
                    </div>
                  </div>

                  {/* ── CARD 1: CURRENT LIVE MONITORING ── */}
                  <div style={{
                    backgroundColor: "#f8fafc",
                    padding: "1.25rem",
                    borderRadius: "16px",
                    border: "1px solid #e2e8f0",
                  }}>
                    <div style={{ fontSize: "0.75rem", color: "#64748b", fontWeight: "700", letterSpacing: "0.08em", marginBottom: "0.25rem" }}>
                      CURRENT OBSERVED WATER LEVEL (LIVE MONITORING)
                    </div>
                    <div style={{ display: "flex", justifyContent: "space-between", alignItems: "baseline" }}>
                      <div style={{ fontSize: "2.25rem", fontWeight: "800", color: "#0f172a", lineHeight: 1 }}>
                        {liveLvl != null ? liveLvl.toFixed(2) : "--"}
                        <span style={{ fontSize: "1.1rem", fontWeight: "600", color: "#94a3b8", marginLeft: "0.25rem" }}>m</span>
                      </div>
                      <div style={{ fontSize: "0.75rem", color: "#64748b", fontStyle: "italic" }}>
                        Real-time FFWS telemetry
                      </div>
                    </div>
                  </div>

                  {/* ── CARD 2: AUTHORITATIVE DAILY FORECAST ── */}
                  <div style={{
                    backgroundColor: "#f0f9ff",
                    padding: "1.5rem",
                    borderRadius: "16px",
                    border: "1px solid #bae6fd",
                  }}>
                    <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: "0.75rem" }}>
                      <div>
                        <div style={{ fontSize: "0.75rem", color: "#0369a1", fontWeight: "800", letterSpacing: "0.08em" }}>
                          DAILY DECISION-SUPPORT FORECAST
                        </div>
                        <div style={{ fontSize: "0.85rem", color: "#0284c7", fontWeight: "700", marginTop: "2px" }}>
                          {stationForecast?.forecastTargetDate ? `Target Date: ${stationForecast.forecastTargetDate}` : "Next Calendar Day"}
                        </div>
                      </div>
                      <div>
                        <span style={{
                          fontSize: "0.7rem",
                          fontWeight: "800",
                          padding: "0.25rem 0.6rem",
                          borderRadius: "999px",
                          backgroundColor: stationForecast?.calculationMode === 'primary_model' ? '#dbeafe' : (stationForecast?.calculationMode === 'persistence_fallback' ? '#fef3c7' : '#f1f5f9'),
                          color: stationForecast?.calculationMode === 'primary_model' ? '#1d4ed8' : (stationForecast?.calculationMode === 'persistence_fallback' ? '#b45309' : '#64748b'),
                          border: `1px solid ${stationForecast?.calculationMode === 'primary_model' ? '#93c5fd' : (stationForecast?.calculationMode === 'persistence_fallback' ? '#fde68a' : '#cbd5e1')}`,
                        }}>
                          {stationForecast?.calculationMode === 'primary_model' ? 'PRIMARY MODEL' : (stationForecast?.calculationMode === 'persistence_fallback' ? 'PERSISTENCE FALLBACK' : 'FORECAST UNAVAILABLE')}
                        </span>
                      </div>
                    </div>

                    {hasForecast ? (
                      <div>
                        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-end", marginBottom: "0.75rem" }}>
                          <div>
                            <div style={{ fontSize: "0.75rem", color: "#64748b", fontWeight: "600" }}>
                              {isTumana ? "Forecasted Tumana Water Level:" : "Forecasted Daily Maximum:"}
                            </div>
                            <div style={{ fontSize: "2.75rem", fontWeight: "800", color: "#0369a1", lineHeight: 1 }}>
                              {stationForecast.predictedWaterLevel.toFixed(2)}
                              <span style={{ fontSize: "1.2rem", fontWeight: "600", marginLeft: "0.25rem" }}>m</span>
                            </div>
                          </div>

                          {!isTumana && (
                            <div style={{ textAlign: "right" }}>
                              <div style={{
                                fontSize: "0.85rem",
                                fontWeight: "800",
                                padding: "0.35rem 0.8rem",
                                borderRadius: "999px",
                                backgroundColor: stationForecast.statusBand === 'CRITICAL' ? '#fef2f2' : (stationForecast.statusBand === 'ALARM' || stationForecast.statusBand === 'WARNING' ? '#fffbeb' : (stationForecast.statusBand === 'ALERT' ? '#fefce8' : '#f0fdf4')),
                                color: stationForecast.statusBand === 'CRITICAL' ? '#b91c1c' : (stationForecast.statusBand === 'ALARM' || stationForecast.statusBand === 'WARNING' ? '#b45309' : (stationForecast.statusBand === 'ALERT' ? '#a16207' : '#15803d')),
                                border: `1px solid ${stationForecast.statusBand === 'CRITICAL' ? '#fecaca' : (stationForecast.statusBand === 'ALARM' || stationForecast.statusBand === 'WARNING' ? '#fde68a' : (stationForecast.statusBand === 'ALERT' ? '#fef08a' : '#bbf7d0'))}`,
                              }}>
                                {stationForecast.statusBand || "SAFE"}
                              </div>
                              <div style={{ fontSize: "0.7rem", color: "#64748b", marginTop: "4px" }}>
                                Backend Authoritative Status
                              </div>
                            </div>
                          )}
                        </div>

                        {isTumana ? (
                          <div style={{
                            backgroundColor: "#ffffff",
                            padding: "0.75rem 1rem",
                            borderRadius: "10px",
                            border: "1px solid #bae6fd",
                            fontSize: "0.78rem",
                            color: "#0369a1",
                            fontWeight: "600",
                            lineHeight: 1.4,
                          }}>
                            ℹ️ <strong>Tumana Note:</strong> Daily decision-support forecast (PAGASA-reported daily Tumana water-level observation). No forecast threshold mapping is applied.
                          </div>
                        ) : (
                          <div style={{
                            backgroundColor: "#ffffff",
                            padding: "0.75rem 1rem",
                            borderRadius: "10px",
                            border: "1px solid #bae6fd",
                            fontSize: "0.75rem",
                            color: "#0369a1",
                            lineHeight: 1.4,
                          }}>
                            Decision-support forecast for <strong>{stationForecast.forecastTargetDate || "Next Calendar Day"}</strong>. Status is authoritative from backend daily model. Always follow official PAGASA and MDRRMO flood advisories for emergency response.
                          </div>
                        )}
                      </div>
                    ) : (
                      <div style={{
                        backgroundColor: "#ffffff",
                        padding: "1.5rem",
                        borderRadius: "12px",
                        border: "1px dashed #cbd5e1",
                        textAlign: "center",
                      }}>
                        <div style={{ fontSize: "1.1rem", fontWeight: "800", color: "#64748b", marginBottom: "0.35rem" }}>
                          FORECAST UNAVAILABLE
                        </div>
                        <div style={{ fontSize: "0.8rem", color: "#94a3b8" }}>
                          {isTumana
                            ? "Required completed daily observation is unavailable for Tumana station."
                            : "Input data incomplete for daily model and persistence fallback."}
                        </div>
                      </div>
                    )}
                  </div>
                </div>
              );
            })() : (
              <div
                style={{
                  textAlign: "center",
                  color: "#0369a1",
                  fontWeight: "700",
                  marginTop: "2rem",
                }}
              >
                Awaiting connection to analytics engine...
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default PredictionTool;
