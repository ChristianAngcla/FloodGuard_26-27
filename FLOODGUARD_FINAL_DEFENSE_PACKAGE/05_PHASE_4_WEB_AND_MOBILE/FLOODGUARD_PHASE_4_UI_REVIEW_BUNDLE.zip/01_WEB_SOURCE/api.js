/** Single source of truth for FloodGuard Website → API host. */
export const API_BASE =
  typeof window !== 'undefined' && (window.location.hostname === 'localhost' || window.location.hostname === '127.0.0.1')
    ? '' // Use same-origin relative path on localhost to route through Vite proxy (eliminates CORS and preflight blocks)
    : (import.meta.env.VITE_API_BASE || import.meta.env.VITE_API_URL || 'https://floodguard-api-xyjx.onrender.com').replace(/\/$/, '');

export const apiUrl = (path = '') => {
  const p = path.startsWith('/') ? path : `/${path}`;
  return `${API_BASE}${p}`;
};
