/**
 * FloodGuard Truthful Daily Forecast Service
 * 
 * Evaluates the three certified station models (Sto. Niño C9, Nangka C4, Tumana C8)
 * using deterministic OLS formulas and strict fallback rules.
 */

import { STATION_MODEL_REGISTRY } from '../config/stationModelRegistry.js';

const getStatusLabel = (wl, thresholds, isTumana = false) => {
    if (isTumana) return 'UNMAPPED_DAILY_OBSERVATION';
    if (!Number.isFinite(wl) || wl === null) return 'UNAVAILABLE';
    if (!thresholds) return 'UNMAPPED';
    if (wl >= thresholds.critical) return 'CRITICAL';
    if (wl >= thresholds.alarm) return 'WARNING';
    if (wl >= thresholds.alert) return 'ALERT';
    return 'SAFE';
};

export const getPstDates = () => {
    // Current time in Asia/Manila (PST: UTC+8)
    const now = new Date();
    const pstOffsetMs = 8 * 3600 * 1000;
    const pstNow = new Date(now.getTime() + (now.getTimezoneOffset() * 60 * 1000) + pstOffsetMs);

    const pad = (n) => String(n).padStart(2, '0');
    const toYmd = (d) => `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`;

    const todayYmd = toYmd(pstNow);
    const yesterday = new Date(pstNow.getTime() - 24 * 3600 * 1000);
    const yesterdayYmd = toYmd(yesterday);

    return {
        sourceDataDate: yesterdayYmd,
        forecastTargetDate: todayYmd,
    };
};

/**
 * Evaluates daily forecasts for all three certified stations.
 * 
 * @param {Object} telemetry - Telemetry state containing sensors, upstreamRain, dailyInputs, or customDates.
 * @returns {Object} Structured station forecasts and overall status.
 */
export const evaluateDailyForecasts = (telemetry = {}) => {
    const {
        sensors = {},
        upstreamRain = {},
        dailyInputs = null,
        customDates = null,
    } = telemetry;

    const { sourceDataDate, forecastTargetDate } = customDates || getPstDates();

    // 1. Sto. Niño Inputs (Candidate 9: AR2 + Boso-Boso Rain)
    // Sto_t_3 must NEVER fallback to Sto_t_1. If missing, it strictly remains null.
    const sto_t_1 = (dailyInputs && dailyInputs.sto_t_1 !== undefined)
        ? (Number.isFinite(dailyInputs.sto_t_1) && dailyInputs.sto_t_1 !== null ? dailyInputs.sto_t_1 : null)
        : (Number.isFinite(sensors.sto_nino) && sensors.sto_nino !== null ? sensors.sto_nino : null);

    const sto_t_3 = (dailyInputs && dailyInputs.sto_t_3 !== undefined)
        ? (Number.isFinite(dailyInputs.sto_t_3) && dailyInputs.sto_t_3 !== null ? dailyInputs.sto_t_3 : null)
        : (Number.isFinite(sensors.sto_nino_t_3) && sensors.sto_nino_t_3 !== null ? sensors.sto_nino_t_3 : null);

    // Numeric 0.0 is valid rainfall. Null/undefined/NaN is missing.
    const bosoboso_t_1 = (dailyInputs && dailyInputs.bosoboso_t_1 !== undefined)
        ? (Number.isFinite(dailyInputs.bosoboso_t_1) && dailyInputs.bosoboso_t_1 !== null ? dailyInputs.bosoboso_t_1 : null)
        : (Number.isFinite(upstreamRain.boso_boso_rfday) && upstreamRain.boso_boso_rfday !== null
            ? upstreamRain.boso_boso_rfday
            : (Number.isFinite(upstreamRain.boso_boso) && upstreamRain.boso_boso !== null ? upstreamRain.boso_boso : null));

    const stoEval = STATION_MODEL_REGISTRY.sto_nino.evaluate({
        sto_t_1,
        sto_t_3,
        bosoboso_t_1,
    });

    const stoStatus = getStatusLabel(stoEval.predictedWaterLevel, STATION_MODEL_REGISTRY.sto_nino.thresholds, false);

    const stoForecast = {
        stationId: STATION_MODEL_REGISTRY.sto_nino.stationId,
        stationName: STATION_MODEL_REGISTRY.sto_nino.stationName,
        sourceDataDate,
        forecastTargetDate,
        predictedWaterLevel: stoEval.predictedWaterLevel,
        unit: STATION_MODEL_REGISTRY.sto_nino.unit,
        selectedCandidate: STATION_MODEL_REGISTRY.sto_nino.selectedCandidate,
        modelVersion: STATION_MODEL_REGISTRY.sto_nino.modelVersion,
        calculationMode: stoEval.calculationMode,
        fallbackReason: stoEval.fallbackReason,
        targetSemantics: STATION_MODEL_REGISTRY.sto_nino.targetSemantics,
        statusBand: stoStatus,
        status: stoStatus,
        thresholds: STATION_MODEL_REGISTRY.sto_nino.thresholds,
        thresholdMappingAllowed: STATION_MODEL_REGISTRY.sto_nino.thresholdMappingAllowed,
        inputsUsed: stoEval.inputsUsed,
        missingInputs: stoEval.missingInputs,
    };

    // 2. Nangka Inputs (Candidate 4: AR1 + Boso-Boso Rain)
    const nangka_wl_t_1 = (dailyInputs && dailyInputs.nangka_wl_t_1 !== undefined)
        ? (Number.isFinite(dailyInputs.nangka_wl_t_1) && dailyInputs.nangka_wl_t_1 !== null ? dailyInputs.nangka_wl_t_1 : null)
        : (Number.isFinite(sensors.nangka) && sensors.nangka !== null ? sensors.nangka : null);

    const nangkaEval = STATION_MODEL_REGISTRY.nangka.evaluate({
        nangka_wl_t_1,
        bosoboso_t_1,
    });

    const nangkaStatus = getStatusLabel(nangkaEval.predictedWaterLevel, STATION_MODEL_REGISTRY.nangka.thresholds, false);

    const nangkaForecast = {
        stationId: STATION_MODEL_REGISTRY.nangka.stationId,
        stationName: STATION_MODEL_REGISTRY.nangka.stationName,
        sourceDataDate,
        forecastTargetDate,
        predictedWaterLevel: nangkaEval.predictedWaterLevel,
        unit: STATION_MODEL_REGISTRY.nangka.unit,
        selectedCandidate: STATION_MODEL_REGISTRY.nangka.selectedCandidate,
        modelVersion: STATION_MODEL_REGISTRY.nangka.modelVersion,
        calculationMode: nangkaEval.calculationMode,
        fallbackReason: nangkaEval.fallbackReason,
        targetSemantics: STATION_MODEL_REGISTRY.nangka.targetSemantics,
        statusBand: nangkaStatus,
        status: nangkaStatus,
        thresholds: STATION_MODEL_REGISTRY.nangka.thresholds,
        thresholdMappingAllowed: STATION_MODEL_REGISTRY.nangka.thresholdMappingAllowed,
        inputsUsed: nangkaEval.inputsUsed,
        missingInputs: nangkaEval.missingInputs,
    };

    // 3. Tumana Inputs (Candidate 8: AR1 + Science Garden Rain)
    const tumana_wl_t_1 = (dailyInputs && dailyInputs.tumana_wl_t_1 !== undefined)
        ? (Number.isFinite(dailyInputs.tumana_wl_t_1) && dailyInputs.tumana_wl_t_1 !== null ? dailyInputs.tumana_wl_t_1 : null)
        : (Number.isFinite(sensors.tumana) && sensors.tumana !== null ? sensors.tumana : null);

    const pagasa_sg_rain_t_1 = (dailyInputs && dailyInputs.pagasa_sg_rain_t_1 !== undefined)
        ? (Number.isFinite(dailyInputs.pagasa_sg_rain_t_1) && dailyInputs.pagasa_sg_rain_t_1 !== null ? dailyInputs.pagasa_sg_rain_t_1 : null)
        : (Number.isFinite(upstreamRain.science_garden_rfday) && upstreamRain.science_garden_rfday !== null
            ? upstreamRain.science_garden_rfday
            : (Number.isFinite(upstreamRain.science_garden) && upstreamRain.science_garden !== null ? upstreamRain.science_garden : null));

    const tumanaEval = STATION_MODEL_REGISTRY.tumana.evaluate({
        tumana_wl_t_1,
        pagasa_sg_rain_t_1,
    });

    // Tumana status must NOT be classified as SAFE/ALERT/ALARM/CRITICAL.
    const tumanaForecast = {
        stationId: STATION_MODEL_REGISTRY.tumana.stationId,
        stationName: STATION_MODEL_REGISTRY.tumana.stationName,
        sourceDataDate,
        forecastTargetDate,
        predictedWaterLevel: tumanaEval.predictedWaterLevel,
        unit: STATION_MODEL_REGISTRY.tumana.unit,
        selectedCandidate: STATION_MODEL_REGISTRY.tumana.selectedCandidate,
        modelVersion: STATION_MODEL_REGISTRY.tumana.modelVersion,
        calculationMode: tumanaEval.calculationMode,
        fallbackReason: tumanaEval.fallbackReason,
        targetSemantics: STATION_MODEL_REGISTRY.tumana.targetSemantics,
        statusBand: 'UNMAPPED_DAILY_OBSERVATION',
        status: 'UNMAPPED_DAILY_OBSERVATION',
        thresholds: null,
        thresholdMappingAllowed: false,
        inputsUsed: tumanaEval.inputsUsed,
        missingInputs: tumanaEval.missingInputs,
    };

    const stations = {
        sto_nino: stoForecast,
        nangka: nangkaForecast,
        tumana: tumanaForecast,
    };

    // Overall Status across threshold-mapped stations only (Sto. Niño & Nangka)
    const activeStatuses = [stoStatus, nangkaStatus].filter(s => s !== 'UNAVAILABLE');
    let overall_status = 'SAFE';
    if (activeStatuses.includes('CRITICAL')) overall_status = 'CRITICAL';
    else if (activeStatuses.includes('WARNING')) overall_status = 'WARNING';
    else if (activeStatuses.includes('ALERT')) overall_status = 'ALERT';

    return {
        stations,
        overall_status,
        sourceDataDate,
        forecastTargetDate,
    };
};
