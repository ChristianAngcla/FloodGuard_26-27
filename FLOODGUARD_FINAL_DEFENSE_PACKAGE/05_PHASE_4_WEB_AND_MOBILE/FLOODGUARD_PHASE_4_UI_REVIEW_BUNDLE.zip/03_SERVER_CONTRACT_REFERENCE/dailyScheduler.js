/**
 * FloodGuard Daily Forecast Scheduler (Phase 2 & Phase 3)
 * 
 * Schedules one daily forecast execution at 07:00 AM Asia/Manila (PST: UTC+8).
 * Upon successful execution, triggers Phase 3 daily deduplicated FCM dispatch.
 * Pure Node.js implementation without external scheduler dependencies.
 */

import { executeDailyForecastRun } from './dailyPipelineService.js';
import { dispatchDailyForecastNotifications } from './dailyFcmDispatcher.js';

let _timerHandle = null;

/**
 * Calculates milliseconds from current time until the next 07:00:00 AM in Asia/Manila (UTC+8).
 */
export const getMsUntilNext0700Pst = () => {
    const now = new Date();
    // PST is UTC+8
    const pstOffsetMs = 8 * 3600 * 1000;
    const pstNow = new Date(now.getTime() + (now.getTimezoneOffset() * 60 * 1000) + pstOffsetMs);

    const next0700 = new Date(pstNow);
    next0700.setHours(7, 0, 0, 0);

    // If already past 07:00 AM today, target tomorrow 07:00 AM
    if (pstNow.getTime() >= next0700.getTime()) {
        next0700.setDate(next0700.getDate() + 1);
    }

    return next0700.getTime() - pstNow.getTime();
};

export const initDailyForecastScheduler = () => {
    if (_timerHandle) {
        clearTimeout(_timerHandle);
    }

    const msUntilNextRun = getMsUntilNext0700Pst();
    const hours = (msUntilNextRun / 3600000).toFixed(2);
    console.log(`[DailyScheduler] Initialized. Next automated forecast run in ${hours} hours (07:00 AM PST).`);

    const scheduleNext = () => {
        const ms = getMsUntilNext0700Pst();
        _timerHandle = setTimeout(async () => {
            console.log(`[DailyScheduler] Executing scheduled 07:00 AM PST forecast run at ${new Date().toISOString()}...`);
            try {
                const res = await executeDailyForecastRun();
                console.log(`[DailyScheduler] Daily forecast completed successfully for target date ${res.forecastTargetDate}.`);
                
                // Phase 3: Trigger deduplicated daily FCM notification dispatch
                const notifyRes = await dispatchDailyForecastNotifications(res.forecastTargetDate);
                console.log(`[DailyScheduler] Phase 3 FCM dispatch completed. Dispatched: ${notifyRes.dispatchedCount}, Skipped: ${notifyRes.skippedCount}.`);
            } catch (err) {
                console.error(`[DailyScheduler] Error during scheduled forecast run:`, err.message);
            }
            // Chain next day's run
            scheduleNext();
        }, ms);
    };

    scheduleNext();
};

export const triggerManualForecastRun = async (targetDateStr = null, sendNotifications = false) => {
    console.log(`[DailyScheduler] Manual forecast run triggered for target date: ${targetDateStr || 'Today (PST)'} (sendNotifications: ${sendNotifications})`);
    const res = await executeDailyForecastRun(targetDateStr);
    let notificationResult = null;
    if (sendNotifications === true) {
        notificationResult = await dispatchDailyForecastNotifications(res.forecastTargetDate);
    }
    return {
        ...res,
        notifications: notificationResult,
    };
};
