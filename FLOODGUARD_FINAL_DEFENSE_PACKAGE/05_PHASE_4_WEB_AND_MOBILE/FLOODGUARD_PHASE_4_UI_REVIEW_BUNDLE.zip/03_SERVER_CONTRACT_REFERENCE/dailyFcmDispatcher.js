/**
 * FloodGuard Daily FCM Dispatcher (Phase 3 Final Delivery-Sealed)
 * 
 * Consumes persisted DailyForecast records from MongoDB and dispatches exactly ONE truthful,
 * atomically deduplicated daily forecast advisory per station per forecast target date via Firebase Admin messaging.
 */

import admin from 'firebase-admin';
import { DailyForecast } from '../models/DailyForecast.js';

export const RIVER_TO_BARANGAYS = {
    nangka: ['Nangka', 'Parang', 'Fortune'],
    tumana: ['Tumana', 'Malanday', 'Concepcion Uno', 'Marikina Heights', 'Concepcion Dos'],
    sto_nino: [
        'Santo Niño', 'Calumpang', 'Industrial Valley', 'Barangka',
        'San Roque', 'Santa Elena', 'Tañong', 'Jesus Dela Peña',
    ],
};

/**
 * Canonical Barangay Topic Formatter used across the entire FloodGuard server
 * (Subscriptions, Manual Alerts, and Automated Phase 3 Forecast FCM).
 * 
 * Rules:
 * 1. Lowercase
 * 2. Unicode NFD normalization + strip diacritics (ñ -> n)
 * 3. Trim whitespace
 * 4. Replace one or more spaces with single underscore (_)
 */
export const topicFromBarangay = (barangay) =>
    `barangay_${String(barangay || '').toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g, '').trim().replace(/\s+/g, '_')}`;

export const formatForecastDate = (dateStr) => {
    if (!dateStr || typeof dateStr !== 'string') return dateStr || '';
    const parts = dateStr.split('-');
    if (parts.length === 3) {
        const months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
        const monthIdx = parseInt(parts[1], 10) - 1;
        const day = parseInt(parts[2], 10);
        if (monthIdx >= 0 && monthIdx < 12) {
            return `${months[monthIdx]} ${day}`;
        }
    }
    return dateStr;
};

/**
 * Pure function: Builds truthful, station-specific advisory message from persisted DailyForecast.
 */
export const buildStationAdvisoryMessage = (forecast) => {
    if (!forecast) return null;
    const { stationId, forecastTargetDate, predictedWaterLevel, calculationMode, statusBand } = forecast;

    // Unavailable or missing predicted level -> No notification
    if (predictedWaterLevel === null || calculationMode === 'unavailable' || !Number.isFinite(predictedWaterLevel)) {
        return null;
    }

    const formattedDate = formatForecastDate(forecastTargetDate);
    const modeText = calculationMode === 'persistence_fallback'
        ? 'Persistence fallback.'
        : 'Primary model.';

    if (stationId === 'sto_nino') {
        return {
            title: 'FloodGuard Daily Forecast — Sto. Niño',
            body: `Forecast for ${formattedDate}: ${predictedWaterLevel.toFixed(2)} m (${statusBand}). ${modeText}`,
        };
    }

    if (stationId === 'nangka') {
        return {
            title: 'FloodGuard Daily Forecast — Nangka',
            body: `Forecast for ${formattedDate}: ${predictedWaterLevel.toFixed(2)} m (${statusBand}). ${modeText}`,
        };
    }

    if (stationId === 'tumana') {
        // Tumana must NEVER have SAFE/ALERT/ALARM/WARNING/CRITICAL or mention daily max/peak/probability
        return {
            title: 'FloodGuard Daily Forecast — Tumana',
            body: `Forecasted Tumana water level for ${formattedDate}: ${predictedWaterLevel.toFixed(2)} m.${calculationMode === 'persistence_fallback' ? ' Persistence fallback.' : ''}`,
        };
    }

    return null;
};

/**
 * Default Firebase Admin helpers
 */
export const isFirebaseInitialized = () => Boolean(admin.apps && admin.apps.length);
export const sendFcmMessage = async (payload) => {
    return await admin.messaging().send(payload);
};

/**
 * Atomically claims a DailyForecast record for dispatching.
 * Prevents race conditions from multiple simultaneous scheduler runs.
 */
export const claimForecastForDispatch = async (stationId, targetDate) => {
    const claimFilter = {
        stationId,
        forecastTargetDate: targetDate,
        notificationStatus: { $nin: ['sent', 'sending'] },
        notificationSentAt: null,
        calculationMode: { $ne: 'unavailable' },
        predictedWaterLevel: { $ne: null },
    };

    return await DailyForecast.findOneAndUpdate(
        claimFilter,
        {
            $set: {
                notificationStatus: 'sending',
                updatedAt: new Date(),
            }
        },
        { new: true }
    );
};

/**
 * Dispatches one deduplicated daily forecast advisory per certified station for a target date.
 * Reads strictly from persisted DailyForecast collection.
 */
export const dispatchDailyForecastNotifications = async (targetDate, {
    isInitialized = isFirebaseInitialized,
    sender = sendFcmMessage,
} = {}) => {
    if (!targetDate) {
        console.warn('[!] dispatchDailyForecastNotifications called without targetDate');
        return { targetDate, dispatchedCount: 0, skippedCount: 0, failedCount: 0, results: [] };
    }

    console.log(`[*] Phase 3: Inspecting persisted DailyForecast records for ${targetDate}...`);

    const stationsToCheck = ['sto_nino', 'nangka', 'tumana'];
    const results = [];
    let dispatchedCount = 0;
    let skippedCount = 0;
    let failedCount = 0;

    for (const stationId of stationsToCheck) {
        // 1. Initial status inspection
        let existing = null;
        try {
            existing = await DailyForecast.findOne({ stationId, forecastTargetDate: targetDate });
        } catch (err) {
            console.warn(`[!] Error inspecting DailyForecast for ${stationId}:`, err.message);
        }

        if (!existing) {
            console.log(`[-] [${stationId}] No DailyForecast record found for ${targetDate}. Skipping FCM.`);
            results.push({ stationId, status: 'skipped', reason: 'record_not_found' });
            skippedCount++;
            continue;
        }

        if (existing.calculationMode === 'unavailable' || existing.predictedWaterLevel === null) {
            console.log(`[-] [${stationId}] Forecast is unavailable for ${targetDate}. Skipping FCM.`);
            results.push({ stationId, status: 'skipped', reason: 'forecast_unavailable' });
            skippedCount++;
            continue;
        }

        if (existing.notificationSentAt != null || existing.notificationStatus === 'sent') {
            console.log(`[-] [${stationId}] Advisory for ${targetDate} was already dispatched at ${existing.notificationSentAt}. Skipping deduplicated send.`);
            results.push({ stationId, status: 'skipped', reason: 'already_sent', sentAt: existing.notificationSentAt });
            skippedCount++;
            continue;
        }

        if (existing.notificationStatus === 'sending') {
            console.log(`[-] [${stationId}] Advisory for ${targetDate} is currently being dispatched by another process. Skipping concurrent send.`);
            results.push({ stationId, status: 'skipped', reason: 'already_in_progress' });
            skippedCount++;
            continue;
        }

        // 2. Atomic claim
        const claimed = await claimForecastForDispatch(stationId, targetDate).catch(() => null);
        if (!claimed) {
            console.log(`[-] [${stationId}] Could not obtain atomic sending claim for ${targetDate}. Skipping.`);
            results.push({ stationId, status: 'skipped', reason: 'claim_failed_already_sent_or_in_progress' });
            skippedCount++;
            continue;
        }

        // 3. Build truthful station advisory message
        const advisory = buildStationAdvisoryMessage(claimed);
        if (!advisory) {
            await DailyForecast.findOneAndUpdate(
                { stationId, forecastTargetDate: targetDate },
                { $set: { notificationStatus: 'skipped', updatedAt: new Date() } }
            ).catch(() => {});
            results.push({ stationId, status: 'skipped', reason: 'empty_advisory' });
            skippedCount++;
            continue;
        }

        // 4. Verify Firebase Admin availability
        if (!isInitialized()) {
            console.warn(`[!] Firebase Admin not initialized; cannot dispatch FCM for ${stationId}. Setting notificationStatus = 'failed'.`);
            await DailyForecast.findOneAndUpdate(
                { stationId, forecastTargetDate: targetDate },
                {
                    $set: {
                        notificationStatus: 'failed',
                        notificationSentAt: null,
                        notificationMessageId: null,
                        updatedAt: new Date(),
                    }
                }
            ).catch(() => {});
            results.push({ stationId, status: 'failed', reason: 'firebase_not_initialized' });
            failedCount++;
            continue;
        }

        // 5. Delivery fan-out to mapped barangay topics
        const barangays = RIVER_TO_BARANGAYS[stationId] || [];
        let deliveredToTopics = 0;
        let failedTopics = 0;
        let lastMessageId = null;

        for (const b of barangays) {
            const topic = topicFromBarangay(b);
            try {
                const response = await sender({
                    notification: {
                        title: advisory.title,
                        body: advisory.body,
                    },
                    data: {
                        type: 'daily_forecast_advisory',
                        stationId,
                        forecastTargetDate: claimed.forecastTargetDate,
                        sourceDataDate: claimed.sourceDataDate,
                        predictedWaterLevel: String(claimed.predictedWaterLevel),
                        calculationMode: claimed.calculationMode,
                        statusBand: claimed.statusBand || 'UNMAPPED',
                        barangay: b,
                    },
                    topic,
                });
                lastMessageId = response || lastMessageId;
                deliveredToTopics++;
                console.log(`📢 [Phase 3 FCM] Dispatched ${stationId} advisory to [${topic}]: "${advisory.body}"`);
            } catch (sendErr) {
                failedTopics++;
                console.warn(`[!] FCM dispatch failed for ${topic}:`, sendErr.message);
            }
        }

        // 6. Final status evaluation based on REAL delivery
        if (deliveredToTopics === 0) {
            // All topic sends failed -> Mark failed, NOT sent (eligible for retry)
            await DailyForecast.findOneAndUpdate(
                { stationId, forecastTargetDate: targetDate },
                {
                    $set: {
                        notificationStatus: 'failed',
                        notificationSentAt: null,
                        notificationMessageId: null,
                        updatedAt: new Date(),
                    }
                }
            ).catch(() => {});
            results.push({ stationId, status: 'failed', reason: 'all_topic_sends_failed', failedTopics });
            failedCount++;
        } else {
            // At least one topic send succeeded -> Mark sent
            await DailyForecast.findOneAndUpdate(
                { stationId, forecastTargetDate: targetDate },
                {
                    $set: {
                        notificationStatus: 'sent',
                        notificationSentAt: new Date(),
                        notificationMessageId: lastMessageId || `fcm_${Date.now()}`,
                        updatedAt: new Date(),
                    }
                }
            ).catch(() => {});
            results.push({
                stationId,
                status: 'sent',
                title: advisory.title,
                body: advisory.body,
                topicsDelivered: deliveredToTopics,
                failedTopics,
                messageId: lastMessageId,
            });
            dispatchedCount++;
        }
    }

    return {
        targetDate,
        dispatchedCount,
        skippedCount,
        failedCount,
        results,
    };
};
