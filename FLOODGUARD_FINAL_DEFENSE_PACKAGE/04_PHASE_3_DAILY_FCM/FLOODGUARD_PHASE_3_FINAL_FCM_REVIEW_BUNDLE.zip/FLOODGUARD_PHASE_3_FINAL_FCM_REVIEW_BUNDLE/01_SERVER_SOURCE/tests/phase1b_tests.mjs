/**
 * FloodGuard Phase 3 Final Delivery-Sealed Verification Suite
 * 
 * Verifies:
 * 1. Frozen C9, C4, C8 parity and fallback rules (untouched).
 * 2. Phase 2 data-construction, timestamp separation, strict 24/24 completeness, and production pipeline idempotency.
 * 3. Phase 3 final delivery-sealed tests:
 *    - 6.1: Sto. Niño primary_model message format.
 *    - 6.2: Nangka primary_model message format.
 *    - 6.3: Persistence fallback message format.
 *    - 6.4: Tumana message semantics (zero threshold / peak / probability wording).
 *    - 6.5: Tumana unavailable forecast sends nothing.
 *    - 6.6: Sto/Nangka unavailable forecast sends nothing.
 *    - 6.7 [Required Test A]: Firebase unavailable -> dispatchedCount = 0, notificationStatus = 'failed', notificationSentAt = null.
 *    - 6.8 [Required Test B]: All topic sends fail -> deliveredToTopics = 0, notificationStatus = 'failed', notificationSentAt = null.
 *    - 6.9 [Required Test C]: Successful delivery -> deliveredToTopics > 0, notificationStatus = 'sent', notificationSentAt != null.
 *    - 6.10 [Required Test D]: Deduplicated second run -> 0 additional sends, reason = 'already_sent'.
 *    - 6.11 [Required Test E]: Atomic concurrent claim -> only one process claims 'sending', second process skips.
 *    - 6.12 [Required Test F]: Canonical topic consistency (Santo Niño -> barangay_santo_nino, Tañong -> barangay_tanong, Jesus Dela Peña -> barangay_jesus_dela_pena, Concepcion Uno -> barangay_concepcion_uno).
 *    - 6.13: 5-minute background telemetry sync does NOT dispatch daily forecast FCM.
 *    - 6.14: Manual triggerManualForecastRun defaults sendNotifications = false.
 *    - 6.15: Daily notification consumes persisted DailyForecast, not live sensors.
 *    - 6.16: Manual admin alert endpoint exists and uses canonical topicFromBarangay.
 * 4. Security and schema audits: zero rejectUnauthorized: false, DailyForecast schema validation.
 */

import admin from 'firebase-admin';
import { STATION_MODEL_REGISTRY } from '../config/stationModelRegistry.js';
import { evaluateDailyForecasts } from '../services/dailyForecastService.js';
import { computePredictions, CACHE, runBackgroundSync } from '../services/predictionEngine.js';
import {
    subtractCalendarDays,
    parsePstYmdhm,
    extractHourlyTopWindowObservations,
    aggregateCompleteHourlyWaterLevelMax,
    aggregateCompleteHourlyRainfallTotal,
    recordRawTelemetrySync,
    finalizeCalendarDayObservations,
    getCompletedDailyInputs,
    executeDailyForecastRun,
} from '../services/dailyPipelineService.js';
import { getMsUntilNext0700Pst, triggerManualForecastRun } from '../services/dailyScheduler.js';
import {
    buildStationAdvisoryMessage,
    formatForecastDate,
    dispatchDailyForecastNotifications,
    claimForecastForDispatch,
    RIVER_TO_BARANGAYS,
    topicFromBarangay,
} from '../services/dailyFcmDispatcher.js';
import { DailyObservation } from '../models/DailyObservation.js';
import { DailyForecast } from '../models/DailyForecast.js';
import { RawTelemetryReading } from '../models/RawTelemetryReading.js';
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';
import { execFileSync } from 'child_process';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const results = [];

function assert(condition, message) {
    if (!condition) {
        throw new Error(message);
    }
}

function check(name, fn) {
    try {
        fn();
        results.push({ name, pass: true });
        console.log(`[PASS] ${name}`);
    } catch (e) {
        results.push({ name, pass: false, error: e.message });
        console.error(`[FAIL] ${name}: ${e.message}`);
    }
}

async function checkAsync(name, fn) {
    try {
        await fn();
        results.push({ name, pass: true });
        console.log(`[PASS] ${name}`);
    } catch (e) {
        results.push({ name, pass: false, error: e.message });
        console.error(`[FAIL] ${name}: ${e.message}`);
    }
}

console.log('================================================================');
console.log('FLOODGUARD PHASE 3 FINAL DELIVERY-SEALED VERIFICATION SUITE');
console.log('================================================================\n');

// 1. FROZEN MODEL FORMULA PARITY TESTS
check('1.1 Sto. Niño C9 Parity (Normal Operation)', () => {
    const result = STATION_MODEL_REGISTRY.sto_nino.evaluate({
        sto_t_1: 13.50,
        sto_t_3: 13.00,
        bosoboso_t_1: 25.0,
    });
    assert(result.calculationMode === 'primary_model', `Expected primary_model, got ${result.calculationMode}`);
    assert(result.predictedWaterLevel === 13.29, `Expected 13.29, got ${result.predictedWaterLevel}`);
});

check('1.2 Sto. Niño C9 Persistence Fallback (Missing Rain)', () => {
    const result = STATION_MODEL_REGISTRY.sto_nino.evaluate({
        sto_t_1: 14.20,
        sto_t_3: 13.80,
        bosoboso_t_1: null,
    });
    assert(result.calculationMode === 'persistence_fallback', `Expected persistence_fallback, got ${result.calculationMode}`);
    assert(result.predictedWaterLevel === 14.20, `Expected 14.20, got ${result.predictedWaterLevel}`);
});

check('2.1 Nangka C4 Parity (Normal Operation)', () => {
    const result = STATION_MODEL_REGISTRY.nangka.evaluate({
        nangka_wl_t_1: 15.84,
        bosoboso_t_1: 25.5,
    });
    assert(result.calculationMode === 'primary_model', `Expected primary_model, got ${result.calculationMode}`);
    assert(result.predictedWaterLevel === 16.12, `Expected 16.12, got ${result.predictedWaterLevel}`);
});

check('2.2 Nangka C4 Persistence Fallback (Missing Rain)', () => {
    const result = STATION_MODEL_REGISTRY.nangka.evaluate({
        nangka_wl_t_1: 16.35,
        bosoboso_t_1: null,
    });
    assert(result.calculationMode === 'persistence_fallback', `Expected persistence_fallback, got ${result.calculationMode}`);
    assert(result.predictedWaterLevel === 16.35, `Expected 16.35, got ${result.predictedWaterLevel}`);
});

check('3.1 Tumana C8 Parity (Normal Operation)', () => {
    const result = STATION_MODEL_REGISTRY.tumana.evaluate({
        tumana_wl_t_1: 12.50,
        pagasa_sg_rain_t_1: 15.0,
    });
    assert(result.calculationMode === 'primary_model', `Expected primary_model, got ${result.calculationMode}`);
    assert(result.predictedWaterLevel === 12.56, `Expected 12.56, got ${result.predictedWaterLevel}`);
});

check('3.2 Tumana C8 Persistence Fallback (Missing Science Garden Rain)', () => {
    const result = STATION_MODEL_REGISTRY.tumana.evaluate({
        tumana_wl_t_1: 12.80,
        pagasa_sg_rain_t_1: null,
    });
    assert(result.calculationMode === 'persistence_fallback', `Expected persistence_fallback, got ${result.calculationMode}`);
    assert(result.predictedWaterLevel === 12.80, `Expected 12.80, got ${result.predictedWaterLevel}`);
});

check('3.3 Tumana Target Semantics & Strict Unmapped Restrictions', () => {
    const reg = STATION_MODEL_REGISTRY.tumana;
    assert(reg.targetSemantics === 'PAGASA-reported daily Tumana water-level observation', 'Target semantics mismatch');
    assert(reg.thresholds === null, 'Tumana thresholds must be null');
    assert(reg.thresholdMappingAllowed === false, 'Tumana thresholdMappingAllowed must be false');
});

// ================================================================
// PHASE 2 DATA-CONSTRUCTION INTEGRITY (SEALED RE-CHECKS)
// ================================================================

await checkAsync('4.1 [Phase 2] Separate Water & Rain Source Timestamps Across Midnight Boundary', async () => {
    const waterMeta = parsePstYmdhm('202608182350');
    const rainMeta = parsePstYmdhm('202608190000');

    assert(waterMeta.dateStr === '2026-08-18', `Water date mismatch: ${waterMeta.dateStr}`);
    assert(waterMeta.hour === 23, `Water hour mismatch: ${waterMeta.hour}`);
    assert(rainMeta.dateStr === '2026-08-19', `Rain date mismatch: ${rainMeta.dateStr}`);
    assert(rainMeta.hour === 0, `Rain hour mismatch: ${rainMeta.hour}`);

    const count = await recordRawTelemetrySync({
        freshSensors: { sto_nino: null, nangka: null, tumana: null },
        freshUpstreamRain: { boso_boso_rf1hr: null, science_garden_rf1hr: null },
        waterSourceYmdhm: '202608182350',
        rainSourceYmdhm: '202608190000'
    });
    assert(count === 0, `Stale/failed fetch must insert 0 records, got ${count}`);
});

check('4.2 [Phase 2] Strict 24/24 Hourly Completeness (Sto & Nangka)', () => {
    const complete24 = [];
    for (let h = 0; h < 24; h++) {
        complete24.push({ hour: h, minute: 0, value: 12.00 + (h * 0.1) });
    }
    assert(aggregateCompleteHourlyWaterLevelMax(complete24) === 14.30, 'Complete 24h Sto max failed');
    assert(aggregateCompleteHourlyWaterLevelMax(complete24.filter(r => r.hour !== 12)) === null, 'Incomplete 23h must be null');
});

// ================================================================
// PHASE 3 FINAL DELIVERY-SEALED TESTS (TESTS 6.1 - 6.16)
// ================================================================

check('6.1 Sto. Niño primary_model Message Format', () => {
    const msg = buildStationAdvisoryMessage({
        stationId: 'sto_nino',
        forecastTargetDate: '2026-08-20',
        predictedWaterLevel: 14.72,
        calculationMode: 'primary_model',
        statusBand: 'SAFE',
    });
    assert(msg !== null, 'Message should not be null');
    assert(msg.title === 'FloodGuard Daily Forecast — Sto. Niño', `Title mismatch: ${msg.title}`);
    assert(msg.body === 'Forecast for Aug 20: 14.72 m (SAFE). Primary model.', `Body mismatch: ${msg.body}`);
});

check('6.2 Nangka primary_model Message Format', () => {
    const msg = buildStationAdvisoryMessage({
        stationId: 'nangka',
        forecastTargetDate: '2026-08-20',
        predictedWaterLevel: 16.80,
        calculationMode: 'primary_model',
        statusBand: 'ALERT',
    });
    assert(msg !== null, 'Message should not be null');
    assert(msg.title === 'FloodGuard Daily Forecast — Nangka', `Title mismatch: ${msg.title}`);
    assert(msg.body === 'Forecast for Aug 20: 16.80 m (ALERT). Primary model.', `Body mismatch: ${msg.body}`);
});

check('6.3 Persistence Fallback Message Text', () => {
    const msg = buildStationAdvisoryMessage({
        stationId: 'sto_nino',
        forecastTargetDate: '2026-08-20',
        predictedWaterLevel: 14.20,
        calculationMode: 'persistence_fallback',
        statusBand: 'SAFE',
    });
    assert(msg.body.includes('Persistence fallback.'), `Expected persistence fallback in body: ${msg.body}`);
});

check('6.4 Tumana Message Semantics (Zero Threshold / Peak / Probability Wording)', () => {
    const msg = buildStationAdvisoryMessage({
        stationId: 'tumana',
        forecastTargetDate: '2026-08-20',
        predictedWaterLevel: 17.20,
        calculationMode: 'primary_model',
        statusBand: 'UNMAPPED_DAILY_OBSERVATION',
    });
    assert(msg !== null, 'Tumana message should not be null');
    assert(msg.title === 'FloodGuard Daily Forecast — Tumana', `Title mismatch: ${msg.title}`);
    assert(msg.body === 'Forecasted Tumana water level for Aug 20: 17.20 m.', `Body mismatch: ${msg.body}`);

    const forbidden = ['SAFE', 'ALERT', 'ALARM', 'WARNING', 'CRITICAL', 'peak', 'daily max', 'flood probability', 'evacuation'];
    for (const word of forbidden) {
        assert(!msg.body.toLowerCase().includes(word.toLowerCase()), `Forbidden term "${word}" found in Tumana body: ${msg.body}`);
    }
});

check('6.5 Tumana Unavailable Forecast Sends Nothing (Null Message)', () => {
    const msg = buildStationAdvisoryMessage({
        stationId: 'tumana',
        forecastTargetDate: '2026-08-20',
        predictedWaterLevel: null,
        calculationMode: 'unavailable',
        statusBand: 'UNMAPPED_DAILY_OBSERVATION',
    });
    assert(msg === null, 'Unavailable Tumana forecast must produce null message');
});

check('6.6 Sto/Nangka Unavailable Forecast Sends Nothing (Null Message)', () => {
    const msgSto = buildStationAdvisoryMessage({
        stationId: 'sto_nino',
        forecastTargetDate: '2026-08-20',
        predictedWaterLevel: null,
        calculationMode: 'unavailable',
        statusBand: 'UNAVAILABLE',
    });
    assert(msgSto === null, 'Unavailable Sto forecast must produce null message');

    const msgNangka = buildStationAdvisoryMessage({
        stationId: 'nangka',
        forecastTargetDate: '2026-08-20',
        predictedWaterLevel: null,
        calculationMode: 'unavailable',
        statusBand: 'UNAVAILABLE',
    });
    assert(msgNangka === null, 'Unavailable Nangka forecast must produce null message');
});

await checkAsync('6.7 [Required Test A] Firebase Unavailable Marks Record Failed (Never Sent)', async () => {
    const mockForecastDb = new Map();
    mockForecastDb.set('sto_nino:2026-08-20', {
        stationId: 'sto_nino',
        forecastTargetDate: '2026-08-20',
        sourceDataDate: '2026-08-19',
        predictedWaterLevel: 13.50,
        calculationMode: 'primary_model',
        statusBand: 'SAFE',
        notificationSentAt: null,
        notificationStatus: null,
    });

    const origFindOne = DailyForecast.findOne;
    const origFindOneAndUpdate = DailyForecast.findOneAndUpdate;

    try {
        DailyForecast.findOne = (q) => Promise.resolve(mockForecastDb.get(`${q.stationId}:${q.forecastTargetDate}`));
        DailyForecast.findOneAndUpdate = (f, u) => {
            const key = `${f.stationId}:${f.forecastTargetDate}`;
            const existing = mockForecastDb.get(key) || {};
            const updatePayload = u.$set || u;
            const updated = { ...existing, ...updatePayload };
            mockForecastDb.set(key, updated);
            return Promise.resolve(updated);
        };

        const result = await dispatchDailyForecastNotifications('2026-08-20', {
            isInitialized: () => false, // Simulate Firebase uninitialized
        });
        assert(result.dispatchedCount === 0, `Expected 0 dispatched when Firebase is unavailable, got ${result.dispatchedCount}`);
        assert(result.failedCount === 1, `Expected 1 failed count, got ${result.failedCount}`);

        const stoDoc = mockForecastDb.get('sto_nino:2026-08-20');
        assert(stoDoc.notificationStatus === 'failed', `notificationStatus must be 'failed', got '${stoDoc.notificationStatus}'`);
        assert(stoDoc.notificationSentAt === null, `notificationSentAt must remain null, got ${stoDoc.notificationSentAt}`);
    } finally {
        DailyForecast.findOne = origFindOne;
        DailyForecast.findOneAndUpdate = origFindOneAndUpdate;
    }
});

await checkAsync('6.8 [Required Test B] All Topic Sends Fail Marks Record Failed (Eligible for Retry)', async () => {
    const mockForecastDb = new Map();
    mockForecastDb.set('sto_nino:2026-08-20', {
        stationId: 'sto_nino',
        forecastTargetDate: '2026-08-20',
        sourceDataDate: '2026-08-19',
        predictedWaterLevel: 13.50,
        calculationMode: 'primary_model',
        statusBand: 'SAFE',
        notificationSentAt: null,
        notificationStatus: null,
    });

    const origFindOne = DailyForecast.findOne;
    const origFindOneAndUpdate = DailyForecast.findOneAndUpdate;

    try {
        DailyForecast.findOne = (q) => Promise.resolve(mockForecastDb.get(`${q.stationId}:${q.forecastTargetDate}`));
        DailyForecast.findOneAndUpdate = (f, u) => {
            const key = `${f.stationId}:${f.forecastTargetDate}`;
            const existing = mockForecastDb.get(key) || {};
            const updatePayload = u.$set || u;
            const updated = { ...existing, ...updatePayload };
            mockForecastDb.set(key, updated);
            return Promise.resolve(updated);
        };

        const result = await dispatchDailyForecastNotifications('2026-08-20', {
            isInitialized: () => true,
            sender: () => Promise.reject(new Error('Simulated FCM Network Timeout')),
        });
        assert(result.dispatchedCount === 0, `Expected 0 dispatched when all topics fail, got ${result.dispatchedCount}`);
        assert(result.failedCount === 1, `Expected 1 failed count, got ${result.failedCount}`);

        const stoDoc = mockForecastDb.get('sto_nino:2026-08-20');
        assert(stoDoc.notificationStatus === 'failed', `notificationStatus must be 'failed', got '${stoDoc.notificationStatus}'`);
        assert(stoDoc.notificationSentAt === null, `notificationSentAt must remain null, got ${stoDoc.notificationSentAt}`);
    } finally {
        DailyForecast.findOne = origFindOne;
        DailyForecast.findOneAndUpdate = origFindOneAndUpdate;
    }
});

await checkAsync('6.9 [Required Test C] Successful Delivery Marks Record Sent with Timestamp', async () => {
    const mockForecastDb = new Map();
    mockForecastDb.set('sto_nino:2026-08-20', {
        stationId: 'sto_nino',
        forecastTargetDate: '2026-08-20',
        sourceDataDate: '2026-08-19',
        predictedWaterLevel: 13.50,
        calculationMode: 'primary_model',
        statusBand: 'SAFE',
        notificationSentAt: null,
        notificationStatus: null,
    });

    const origFindOne = DailyForecast.findOne;
    const origFindOneAndUpdate = DailyForecast.findOneAndUpdate;

    try {
        DailyForecast.findOne = (q) => Promise.resolve(mockForecastDb.get(`${q.stationId}:${q.forecastTargetDate}`));
        DailyForecast.findOneAndUpdate = (f, u) => {
            const key = `${f.stationId}:${f.forecastTargetDate}`;
            const existing = mockForecastDb.get(key) || {};
            const updatePayload = u.$set || u;
            const updated = { ...existing, ...updatePayload };
            mockForecastDb.set(key, updated);
            return Promise.resolve(updated);
        };

        const result = await dispatchDailyForecastNotifications('2026-08-20', {
            isInitialized: () => true,
            sender: () => Promise.resolve('projects/test-project/messages/msg_12345'),
        });
        assert(result.dispatchedCount === 1, `Expected 1 dispatched, got ${result.dispatchedCount}`);
        assert(result.failedCount === 0, `Expected 0 failed, got ${result.failedCount}`);

        const stoDoc = mockForecastDb.get('sto_nino:2026-08-20');
        assert(stoDoc.notificationStatus === 'sent', `notificationStatus must be 'sent', got '${stoDoc.notificationStatus}'`);
        assert(stoDoc.notificationSentAt instanceof Date, 'notificationSentAt must be a Date');
        assert(stoDoc.notificationMessageId === 'projects/test-project/messages/msg_12345', 'notificationMessageId mismatch');
    } finally {
        DailyForecast.findOne = origFindOne;
        DailyForecast.findOneAndUpdate = origFindOneAndUpdate;
    }
});

await checkAsync('6.10 [Required Test D] Deduplicated Second Run Skips Dispatching', async () => {
    const mockForecastDb = new Map();
    mockForecastDb.set('sto_nino:2026-08-20', {
        stationId: 'sto_nino',
        forecastTargetDate: '2026-08-20',
        sourceDataDate: '2026-08-19',
        predictedWaterLevel: 13.50,
        calculationMode: 'primary_model',
        statusBand: 'SAFE',
        notificationSentAt: new Date('2026-08-20T07:00:00Z'),
        notificationStatus: 'sent',
    });

    const origFindOne = DailyForecast.findOne;
    const origFindOneAndUpdate = DailyForecast.findOneAndUpdate;

    try {
        DailyForecast.findOne = (q) => Promise.resolve(mockForecastDb.get(`${q.stationId}:${q.forecastTargetDate}`));
        DailyForecast.findOneAndUpdate = (f, u) => Promise.resolve(mockForecastDb.get(`${f.stationId}:${f.forecastTargetDate}`));

        const result = await dispatchDailyForecastNotifications('2026-08-20');
        assert(result.dispatchedCount === 0, `Deduplicated run must dispatch 0, got ${result.dispatchedCount}`);
        const stoRes = result.results.find(r => r.stationId === 'sto_nino');
        assert(stoRes.reason === 'already_sent', `Expected already_sent, got ${stoRes.reason}`);
    } finally {
        DailyForecast.findOne = origFindOne;
        DailyForecast.findOneAndUpdate = origFindOneAndUpdate;
    }
});

await checkAsync('6.11 [Required Test E] Atomic Concurrent Claim Prevents Race Conditions', async () => {
    const mockForecastDb = new Map();
    mockForecastDb.set('nangka:2026-08-20', {
        stationId: 'nangka',
        forecastTargetDate: '2026-08-20',
        sourceDataDate: '2026-08-19',
        predictedWaterLevel: 16.50,
        calculationMode: 'primary_model',
        statusBand: 'ALERT',
        notificationSentAt: null,
        notificationStatus: null,
    });

    const origFindOneAndUpdate = DailyForecast.findOneAndUpdate;

    try {
        DailyForecast.findOneAndUpdate = (filter, update) => {
            const key = `${filter.stationId}:${filter.forecastTargetDate}`;
            const doc = mockForecastDb.get(key);
            if (!doc) return Promise.resolve(null);

            // Atomic condition check: notificationStatus not in ['sent', 'sending'] and notificationSentAt is null
            if (filter.notificationStatus && filter.notificationStatus.$nin) {
                if (filter.notificationStatus.$nin.includes(doc.notificationStatus)) {
                    return Promise.resolve(null); // Claim denied!
                }
            }
            if (doc.notificationSentAt !== null) {
                return Promise.resolve(null); // Already sent
            }

            const updatePayload = update.$set || update;
            const updated = { ...doc, ...updatePayload };
            mockForecastDb.set(key, updated);
            return Promise.resolve(updated);
        };

        // First process claims
        const claim1 = await claimForecastForDispatch('nangka', '2026-08-20');
        assert(claim1 !== null, 'First claim must succeed');
        assert(claim1.notificationStatus === 'sending', 'First claim status must be sending');

        // Second simultaneous process attempts to claim
        const claim2 = await claimForecastForDispatch('nangka', '2026-08-20');
        assert(claim2 === null, 'Second concurrent claim must fail/be denied');
    } finally {
        DailyForecast.findOneAndUpdate = origFindOneAndUpdate;
    }
});

check('6.12 [Required Test F] Canonical Barangay Topic Consistency Across All Server Paths', () => {
    const cases = [
        { input: 'Santo Niño', expected: 'barangay_santo_nino' },
        { input: 'Tañong', expected: 'barangay_tanong' },
        { input: 'Jesus Dela Peña', expected: 'barangay_jesus_dela_pena' },
        { input: 'Concepcion Uno', expected: 'barangay_concepcion_uno' },
        { input: 'Barangka', expected: 'barangay_barangka' },
    ];

    for (const { input, expected } of cases) {
        const topic = topicFromBarangay(input);
        assert(topic === expected, `Topic mismatch for "${input}": expected "${expected}", got "${topic}"`);
    }

    // Verify server/index.js uses canonical topicFromBarangay for subscribe and send-alert
    const indexCode = fs.readFileSync(path.join(__dirname, '../index.js'), 'utf-8');
    assert(indexCode.includes('import { topicFromBarangay }'), 'server/index.js must import topicFromBarangay');
    assert(indexCode.includes('const topic = topicFromBarangay(barangay);'), 'server/index.js routes must call topicFromBarangay');
});

check('6.13 [Check I] Five-Minute Background Telemetry Sync Does NOT Trigger FCM', () => {
    const indexCode = fs.readFileSync(path.join(__dirname, '../index.js'), 'utf-8');
    assert(!indexCode.includes('maybeSendAutoWaterLevelAlerts(predictionSnapshot)'), '5-minute loop must not call auto-alerts');
    assert(indexCode.includes('syncTelemetry();'), '5-minute loop must call telemetry sync only');
});

await checkAsync('6.14 [Check J] Manual triggerManualForecastRun Defaults sendNotifications = false', async () => {
    const origRawFind = RawTelemetryReading.find;
    const origObsFindOne = DailyObservation.findOne;
    const origObsFindOneAndUpdate = DailyObservation.findOneAndUpdate;
    const origForecastFind = DailyForecast.find;
    const origForecastFindOne = DailyForecast.findOne;
    const origForecastFindOneAndUpdate = DailyForecast.findOneAndUpdate;

    try {
        RawTelemetryReading.find = () => Promise.resolve([]);
        DailyObservation.findOne = () => Promise.resolve(null);
        DailyObservation.findOneAndUpdate = (f, u) => Promise.resolve({ ...f, ...u });
        DailyForecast.find = () => Promise.resolve([]);
        DailyForecast.findOne = () => Promise.resolve(null);
        DailyForecast.findOneAndUpdate = (f, u) => Promise.resolve({ ...f, ...u });

        const mockRun = await triggerManualForecastRun('2026-08-20');
        assert(mockRun.notifications === null, 'notifications must be null when sendNotifications is omitted/false');

        const mockRunWithFCM = await triggerManualForecastRun('2026-08-20', true);
        assert(mockRunWithFCM.notifications !== null, 'notifications should not be null when sendNotifications is true');
    } finally {
        RawTelemetryReading.find = origRawFind;
        DailyObservation.findOne = origObsFindOne;
        DailyObservation.findOneAndUpdate = origObsFindOneAndUpdate;
        DailyForecast.find = origForecastFind;
        DailyForecast.findOne = origForecastFindOne;
        DailyForecast.findOneAndUpdate = origForecastFindOneAndUpdate;
    }
});

await checkAsync('6.15 [Check K] Daily Notification Consumes Persisted DailyForecast, Not Live Sensors', async () => {
    const persistedRecord = {
        stationId: 'sto_nino',
        forecastTargetDate: '2026-08-20',
        predictedWaterLevel: 13.80,
        calculationMode: 'primary_model',
        statusBand: 'SAFE',
    };
    const msg = buildStationAdvisoryMessage(persistedRecord);
    assert(msg.body.includes('13.80 m (SAFE)'), `Notification should contain persisted 13.80m (SAFE), got: ${msg.body}`);
    assert(!msg.body.includes('17.50'), 'Notification must never contain live sensor value');
    assert(!msg.body.includes('CRITICAL'), 'Notification must never contain live sensor status');
});

check('6.16 [Check L] Manual Admin Alert Endpoint Exists and Uses Canonical Topic Format', () => {
    const indexCode = fs.readFileSync(path.join(__dirname, '../index.js'), 'utf-8');
    assert(indexCode.includes("app.post('/api/user/send-alert'"), 'Admin manual alert endpoint must exist');
    assert(indexCode.includes("const topic = topicFromBarangay(barangay);"), 'Send-alert must use topicFromBarangay');
});

// ================================================================
// SECURITY & ARCHITECTURAL AUDITS
// ================================================================

check('7.1 Zero rejectUnauthorized: false Across Server Code', () => {
    const serverDir = path.resolve(__dirname, '..');
    const filesToScan = [
        path.join(serverDir, 'index.js'),
        path.join(serverDir, 'services', 'predictionEngine.js'),
        path.join(serverDir, 'services', 'dailyForecastService.js'),
        path.join(serverDir, 'services', 'dailyPipelineService.js'),
        path.join(serverDir, 'services', 'dailyScheduler.js'),
        path.join(serverDir, 'services', 'dailyFcmDispatcher.js'),
        path.join(serverDir, 'config', 'stationModelRegistry.js'),
    ];

    for (const file of filesToScan) {
        if (fs.existsSync(file)) {
            const content = fs.readFileSync(file, 'utf-8');
            assert(!content.includes('rejectUnauthorized: false'), `Security violation: rejectUnauthorized: false in ${file}`);
        }
    }
});

check('7.2 Schema Validation for DailyForecast Deduplication & Sending Fields', () => {
    assert(DailyForecast.schema.path('notificationSentAt'), 'Missing notificationSentAt path');
    assert(DailyForecast.schema.path('notificationMessageId'), 'Missing notificationMessageId path');
    assert(DailyForecast.schema.path('notificationStatus'), 'Missing notificationStatus path');
    const enumVals = DailyForecast.schema.path('notificationStatus').enumValues;
    assert(enumVals.includes('sending'), `notificationStatus enum must contain 'sending', got ${enumVals}`);
});

check('7.3 Server Critical Files Parse Successfully (node --check)', () => {
    const serverDir = path.resolve(__dirname, '..');
    const criticalFiles = [
        path.join(serverDir, 'index.js'),
        path.join(serverDir, 'services', 'dailyFcmDispatcher.js'),
        path.join(serverDir, 'services', 'dailyScheduler.js'),
        path.join(serverDir, 'services', 'dailyPipelineService.js'),
        path.join(serverDir, 'services', 'dailyForecastService.js'),
        path.join(serverDir, 'services', 'predictionEngine.js'),
        path.join(serverDir, 'config', 'stationModelRegistry.js'),
    ];

    for (const f of criticalFiles) {
        try {
            execFileSync(process.execPath, ['--check', f], { stdio: 'pipe' });
        } catch (err) {
            throw new Error(`Syntax check failed for ${path.basename(f)}: ${err.stderr ? err.stderr.toString() : err.message}`);
        }
    }

    // Verify index.js contains exactly ONE binding named topicFromBarangay
    const indexCode = fs.readFileSync(path.join(serverDir, 'index.js'), 'utf-8');
    const declMatches = indexCode.match(/(?:const|let|var|function)\s+topicFromBarangay\b/g);
    assert(!declMatches || declMatches.length === 0, `index.js must have 0 local declarations of topicFromBarangay, got ${declMatches?.length}`);
    const importMatches = indexCode.match(/import\s*\{[^}]*topicFromBarangay[^}]*\}\s*from/g);
    assert(importMatches && importMatches.length === 1, `index.js must have exactly 1 import of topicFromBarangay, got ${importMatches?.length}`);
});

console.log('\n================================================================');
const passedCount = results.filter(r => r.pass).length;
console.log(`TEST SUMMARY: ${passedCount}/${results.length} PASSED`);
console.log('================================================================');

if (passedCount === results.length) {
    console.log('\nALL PHASE 3 FINAL DELIVERY-SEALED TESTS PASSED SUCCESSFULLY.');
    process.exit(0);
} else {
    console.error(`\nFAILED ${results.length - passedCount} TESTS.`);
    process.exit(1);
}
