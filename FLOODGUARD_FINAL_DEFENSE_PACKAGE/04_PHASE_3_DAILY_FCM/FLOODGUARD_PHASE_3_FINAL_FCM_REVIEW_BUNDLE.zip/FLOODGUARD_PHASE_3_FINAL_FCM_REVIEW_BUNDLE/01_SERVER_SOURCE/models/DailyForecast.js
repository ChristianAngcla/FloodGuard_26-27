import mongoose from 'mongoose';

const dailyForecastSchema = new mongoose.Schema({
    stationId: {
        type: String, // 'sto_nino', 'nangka', 'tumana'
        required: true,
        index: true,
    },
    forecastTargetDate: {
        type: String, // Format: YYYY-MM-DD (Asia/Manila calendar date)
        required: true,
        index: true,
    },
    sourceDataDate: {
        type: String, // Format: YYYY-MM-DD (prior completed source day)
        required: true,
    },
    predictedWaterLevel: {
        type: Number,
        default: null,
    },
    unit: {
        type: String,
        default: 'm',
    },
    calculationMode: {
        type: String,
        enum: ['primary_model', 'persistence_fallback', 'unavailable'],
        required: true,
    },
    fallbackReason: {
        type: String,
        default: null,
    },
    candidateId: {
        type: String,
        required: true,
    },
    modelVersion: {
        type: String,
        default: '2.0.0-CERTIFIED',
    },
    targetSemantics: {
        type: String,
        required: true,
    },
    statusBand: {
        type: String,
        required: true,
    },
    status: {
        type: String,
        required: true,
    },
    thresholds: {
        type: mongoose.Schema.Types.Mixed,
        default: null,
    },
    thresholdMappingAllowed: {
        type: Boolean,
        default: false,
    },
    inputsUsed: {
        type: mongoose.Schema.Types.Mixed,
        default: {},
    },
    missingInputs: {
        type: [String],
        default: [],
    },
    notificationSentAt: {
        type: Date,
        default: null,
    },
    notificationMessageId: {
        type: String,
        default: null,
    },
    notificationStatus: {
        type: String,
        enum: ['pending', 'sending', 'sent', 'failed', 'skipped', null],
        default: null,
    },
    createdAt: {
        type: Date,
        default: Date.now,
    },
    updatedAt: {
        type: Date,
        default: Date.now,
    },
}, { collection: 'daily_forecasts' });

dailyForecastSchema.index({ stationId: 1, forecastTargetDate: 1 }, { unique: true });

export const DailyForecast = mongoose.models.DailyForecast || mongoose.model('DailyForecast', dailyForecastSchema);
export default DailyForecast;
