import React, { useState, useEffect, useCallback } from 'react';
import { apiUrl } from '../config/api';

const STATION_META = {
  sto_nino: {
    name: 'Sto. Niño Monitoring Station',
    candidate: 'Candidate 9 (AR2 + Boso-Boso Rain)',
    equation: 'Sto_WL = β₀ + β₁(Sto_t-1) + β₂(Sto_t-3) + β₃(BosoBoso_Rain_t-1)',
    thresholds: 'Alert 15.00m | Alarm 16.00m | Critical 17.00m',
  },
  nangka: {
    name: 'Nangka River Station',
    candidate: 'Candidate 4 (AR1 + Boso-Boso Rain)',
    equation: 'Nangka_WL = β₀ + β₁(Nangka_t-1) + β₂(BosoBoso_Rain_t-1)',
    thresholds: 'Alert 16.50m | Alarm 17.10m | Critical 17.70m',
  },
  tumana: {
    name: 'Tumana Bridge Station',
    candidate: 'Candidate 8 (AR1 + Science Garden Rain)',
    equation: 'Tumana_WL = β₀ + β₁(Tumana_t-1) + β₂(PAGASA_SG_Rain_t-1)',
    thresholds: 'Unmapped Observation (Threshold Classification Strictly Forbidden)',
  },
};

export const Algorithm = () => {
  const [selectedStation, setSelectedStation] = useState('sto_nino');
  const [activeModels, setActiveModels] = useState({});
  const [calibrations, setCalibrations] = useState([]);
  const [auditLogs, setAuditLogs] = useState([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);
  const [successMsg, setSuccessMsg] = useState(null);

  // Calibration Form State
  const [uploadFile, setUploadFile] = useState(null);
  const [currentCalibration, setCurrentCalibration] = useState(null);
  const [isProcessing, setIsProcessing] = useState(false);
  const [rejectionReason, setRejectionReason] = useState('');
  const [showRejectModal, setShowRejectModal] = useState(false);

  // Password Reconfirmation Modal State
  const [showPasswordModal, setShowPasswordModal] = useState(false);
  const [passwordAction, setPasswordAction] = useState(null); // 'ACTIVATE' | 'ROLLBACK'
  const [reconfirmPassword, setReconfirmPassword] = useState('');
  const [passwordError, setPasswordError] = useState(null);

  const authHeaders = () => {
    const token = sessionStorage.getItem('adminToken') || localStorage.getItem('adminToken');
    return token ? { Authorization: `Bearer ${token}` } : {};
  };

  const fetchActiveData = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const [actRes, calRes, logRes] = await Promise.all([
        fetch(apiUrl('/api/calibration/active'), { headers: authHeaders() }),
        fetch(apiUrl('/api/calibration'), { headers: authHeaders() }),
        fetch(apiUrl('/api/calibration/audit-logs'), { headers: authHeaders() }),
      ]);

      if (actRes.ok) {
        const actData = await actRes.json();
        setActiveModels(actData.activeModels || {});
      }
      if (calRes.ok) {
        const calData = await calRes.json();
        setCalibrations(calData.calibrations || []);
      }
      if (logRes.ok) {
        const logData = await logRes.json();
        setAuditLogs(logData.logs || []);
      }
    } catch (err) {
      console.error('Fetch Calibration Data Error:', err);
      setError('Failed to connect to backend server. Please verify the server is running.');
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    fetchActiveData();
  }, [fetchActiveData]);

  // Handle Step 1: Upload Dataset
  const handleUpload = async (e) => {
    e.preventDefault();
    if (!uploadFile) return;

    setIsProcessing(true);
    setError(null);
    setSuccessMsg(null);

    const formData = new FormData();
    formData.append('stationId', selectedStation);
    formData.append('dataset', uploadFile);

    try {
      const res = await fetch(apiUrl('/api/calibration/upload'), {
        method: 'POST',
        headers: authHeaders(),
        body: formData,
      });
      const data = await res.json();
      if (data.success) {
        setSuccessMsg(`Dataset uploaded and verified! ${data.calibration.sourceRowCount} rows staged in durable snapshot.`);
        setCurrentCalibration(data.calibration);
        setUploadFile(null);
        fetchActiveData();
      } else {
        setError(data.message || 'Upload failed.');
      }
    } catch (err) {
      setError('Network error during upload.');
    } finally {
      setIsProcessing(false);
    }
  };

  // Handle Step 2: Run Calibration Engine
  const handleRun = async (calId) => {
    if (!calId) return;
    setIsProcessing(true);
    setError(null);
    setSuccessMsg(null);

    try {
      const res = await fetch(apiUrl(`/api/calibration/${calId}/run`), {
        method: 'POST',
        headers: {
          ...authHeaders(),
          'Content-Type': 'application/json',
        },
      });
      const data = await res.json();
      if (data.success) {
        setSuccessMsg('Statistical estimation & HC3 inference complete.');
        setCurrentCalibration(data.calibration);
        fetchActiveData();
      } else {
        setError(data.message || 'Calibration run failed.');
      }
    } catch (err) {
      setError('Network error during calibration execution.');
    } finally {
      setIsProcessing(false);
    }
  };

  // Handle Step 3: Approve Calibration
  const handleApprove = async (calId) => {
    if (!calId) return;
    setIsProcessing(true);
    setError(null);
    setSuccessMsg(null);

    try {
      const res = await fetch(apiUrl(`/api/calibration/${calId}/approve`), {
        method: 'POST',
        headers: authHeaders(),
      });
      const data = await res.json();
      if (data.success) {
        setSuccessMsg('Calibration successfully approved for production deployment.');
        setCurrentCalibration(data.calibration);
        fetchActiveData();
      } else {
        setError(data.message || 'Approval failed.');
      }
    } catch (err) {
      setError('Network error during approval.');
    } finally {
      setIsProcessing(false);
    }
  };

  // Handle Step 3: Reject Calibration
  const handleReject = async (calId) => {
    if (!calId) return;
    setIsProcessing(true);
    setError(null);

    try {
      const res = await fetch(apiUrl(`/api/calibration/${calId}/reject`), {
        method: 'POST',
        headers: {
          ...authHeaders(),
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ reason: rejectionReason || 'Rejected by super administrator.' }),
      });
      const data = await res.json();
      if (data.success) {
        setSuccessMsg('Calibration rejected.');
        setCurrentCalibration(data.calibration);
        setShowRejectModal(false);
        setRejectionReason('');
        fetchActiveData();
      } else {
        setError(data.message || 'Rejection failed.');
      }
    } catch (err) {
      setError('Network error during rejection.');
    } finally {
      setIsProcessing(false);
    }
  };

  // Handle Step 4: Execute Protected Action (Activate or Rollback)
  const handleConfirmPasswordAction = async () => {
    if (!reconfirmPassword) {
      setPasswordError('Please enter your super-admin password.');
      return;
    }

    setIsProcessing(true);
    setPasswordError(null);

    try {
      if (passwordAction === 'ACTIVATE' && currentCalibration) {
        const res = await fetch(apiUrl(`/api/calibration/${currentCalibration._id}/activate`), {
          method: 'POST',
          headers: {
            ...authHeaders(),
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({ reconfirmPassword }),
        });
        const data = await res.json();
        if (data.success) {
          setSuccessMsg(`Model successfully activated! Live model updated to ${data.modelVersion}.`);
          setShowPasswordModal(false);
          setReconfirmPassword('');
          setCurrentCalibration(null);
          fetchActiveData();
        } else {
          setPasswordError(data.message || 'Activation failed.');
        }
      } else if (passwordAction === 'ROLLBACK') {
        const res = await fetch(apiUrl(`/api/calibration/rollback/${selectedStation}`), {
          method: 'POST',
          headers: {
            ...authHeaders(),
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({ reconfirmPassword }),
        });
        const data = await res.json();
        if (data.success) {
          setSuccessMsg(`Rollback successful! Model reverted to ${data.toVersion}.`);
          setShowPasswordModal(false);
          setReconfirmPassword('');
          fetchActiveData();
        } else {
          setPasswordError(data.message || 'Rollback failed.');
        }
      }
    } catch (err) {
      setPasswordError('Server communication error.');
    } finally {
      setIsProcessing(false);
    }
  };

  const activeModel = activeModels[selectedStation];
  const stationCalibrations = calibrations.filter((c) => c.stationId === selectedStation);

  return (
    <div className="w-full max-w-7xl mx-auto px-4 py-8">
      {/* Header Banner */}
      <div className="mb-8 bg-white border border-slate-200 rounded-2xl p-6 shadow-sm">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-3">
              <span className="px-3 py-1 bg-indigo-100 text-indigo-700 text-xs font-bold rounded-full uppercase tracking-wider">
                Phase 5 Governance
              </span>
              <span className="text-xs font-semibold text-slate-500">Locked In-System Recalibration</span>
            </div>
            <h1 className="text-3xl font-extrabold text-slate-900 mt-2 tracking-tight">
              Model Calibration & Governance Console
            </h1>
            <p className="text-slate-600 text-sm mt-1">
              Deterministic OLS estimation, HC3 heteroskedasticity-consistent inference, VIF diagnostics, and auditable deployment.
            </p>
          </div>
          <button
            onClick={fetchActiveData}
            disabled={loading}
            className="self-start md:self-auto px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 font-semibold text-xs rounded-lg transition-colors flex items-center gap-2"
          >
            <svg className={`w-4 h-4 ${loading ? 'animate-spin' : ''}`} fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15" />
            </svg>
            Refresh Status
          </button>
        </div>
      </div>

      {/* Notifications */}
      {error && (
        <div className="mb-6 p-4 bg-rose-50 border border-rose-200 text-rose-800 rounded-xl text-sm font-semibold flex items-center justify-between">
          <span>⚠️ {error}</span>
          <button onClick={() => setError(null)} className="text-rose-600 font-bold ml-4">✕</button>
        </div>
      )}
      {successMsg && (
        <div className="mb-6 p-4 bg-emerald-50 border border-emerald-200 text-emerald-800 rounded-xl text-sm font-semibold flex items-center justify-between">
          <span>✅ {successMsg}</span>
          <button onClick={() => setSuccessMsg(null)} className="text-emerald-600 font-bold ml-4">✕</button>
        </div>
      )}

      {/* Station Selector Tabs */}
      <div className="flex border-b border-slate-200 mb-8 space-x-2">
        {Object.entries(STATION_META).map(([sId, meta]) => (
          <button
            key={sId}
            onClick={() => {
              setSelectedStation(sId);
              setCurrentCalibration(null);
            }}
            className={`py-3 px-5 text-sm font-bold border-b-2 transition-colors ${
              selectedStation === sId
                ? 'border-indigo-600 text-indigo-600 bg-indigo-50/50 rounded-t-lg'
                : 'border-transparent text-slate-500 hover:text-slate-800'
            }`}
          >
            {meta.name}
          </button>
        ))}
      </div>

      {/* Grid: Production Active Card & In-System Recalibration Upload */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 mb-8">
        {/* Active Production Card */}
        <div className="lg:col-span-1 bg-white border border-slate-200 rounded-2xl p-6 shadow-sm flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between mb-4">
              <span className="text-xs font-bold text-slate-400 uppercase tracking-wider">Live Model Deployment</span>
              <span className={`px-2.5 py-1 text-xs font-bold rounded-full ${
                activeModel?.isRecalibrated ? 'bg-amber-100 text-amber-800' : 'bg-blue-100 text-blue-800'
              }`}>
                {activeModel?.isRecalibrated ? 'Recalibrated' : 'Certified Baseline'}
              </span>
            </div>

            <h3 className="text-xl font-bold text-slate-900">{STATION_META[selectedStation].name}</h3>
            <p className="text-xs font-semibold text-indigo-600 mt-1">{STATION_META[selectedStation].candidate}</p>

            <div className="mt-4 p-3 bg-slate-50 border border-slate-100 rounded-xl text-xs font-mono text-slate-700 break-words">
              {STATION_META[selectedStation].equation}
            </div>

            <div className="mt-4 space-y-2 text-xs text-slate-600">
              <div className="flex justify-between py-1 border-b border-slate-100">
                <span className="font-medium text-slate-400">Deployed Version:</span>
                <span className="font-bold text-slate-800">{activeModel?.modelVersion || '2.0.0-CERTIFIED'}</span>
              </div>
              <div className="flex justify-between py-1 border-b border-slate-100">
                <span className="font-medium text-slate-400">Threshold Policy:</span>
                <span className="font-bold text-slate-800">{selectedStation === 'tumana' ? 'Unmapped Daily WL' : 'Mapped (Alert/Alarm/Crit)'}</span>
              </div>
              <div className="flex justify-between py-1 border-b border-slate-100">
                <span className="font-medium text-slate-400">Activated On:</span>
                <span className="font-medium text-slate-800">
                  {activeModel?.activatedAt ? new Date(activeModel.activatedAt).toLocaleString() : 'System Bootstrap'}
                </span>
              </div>
            </div>

            {/* Active Coefficients Table */}
            <div className="mt-4">
              <span className="text-xs font-bold text-slate-400 uppercase tracking-wider">Active β Coefficients</span>
              <div className="mt-2 bg-slate-50 border border-slate-200 rounded-lg overflow-hidden">
                <table className="w-full text-left text-xs font-mono">
                  <tbody>
                    {activeModel?.coefficients && Object.entries(activeModel.coefficients).map(([k, v]) => (
                      <tr key={k} className="border-b border-slate-100 last:border-0">
                        <td className="px-3 py-1.5 font-semibold text-slate-600">{k}</td>
                        <td className="px-3 py-1.5 text-right font-bold text-slate-900">{Number(v).toFixed(6)}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          </div>

          <div className="mt-6 pt-4 border-t border-slate-100">
            <button
              onClick={() => {
                setPasswordAction('ROLLBACK');
                setShowPasswordModal(true);
              }}
              disabled={isProcessing}
              className="w-full py-2 px-4 bg-rose-50 hover:bg-rose-100 text-rose-700 text-xs font-bold rounded-xl border border-rose-200 transition-colors flex items-center justify-center gap-2"
            >
              <span>↺ Roll Back Model</span>
            </button>
          </div>
        </div>

        {/* In-System Recalibration Upload & Workflow */}
        <div className="lg:col-span-2 bg-white border border-slate-200 rounded-2xl p-6 shadow-sm">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h3 className="text-xl font-bold text-slate-900">Yearly Recalibration Audit</h3>
              <p className="text-xs text-slate-500 mt-0.5">Upload new verified hydrological data to run locked OLS estimation.</p>
            </div>
            <span className="px-3 py-1 bg-slate-100 text-slate-700 text-xs font-bold rounded-lg">
              {STATION_META[selectedStation].candidate.split(' ')[0]} {STATION_META[selectedStation].candidate.split(' ')[1]}
            </span>
          </div>

          {!currentCalibration ? (
            <form onSubmit={handleUpload} className="space-y-4">
              <div className="border-2 border-dashed border-slate-300 hover:border-indigo-400 rounded-2xl p-8 text-center transition-colors">
                <input
                  type="file"
                  id="cal-dataset"
                  accept=".csv, .xlsx, .xls"
                  onChange={(e) => setUploadFile(e.target.files?.[0] || null)}
                  className="hidden"
                />
                <label htmlFor="cal-dataset" className="cursor-pointer flex flex-col items-center">
                  <svg className="w-12 h-12 text-slate-400 mb-3" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M7 16a4 4 0 01-.88-7.903A5 5 0 1115.9 6L16 6a5 5 0 011 9.9M15 13l-3-3m0 0l-3 3m3-3v12" />
                  </svg>
                  <span className="text-sm font-bold text-slate-800">
                    {uploadFile ? uploadFile.name : 'Select CSV or XLSX Dataset'}
                  </span>
                  <span className="text-xs text-slate-400 mt-1">
                    {uploadFile ? `${(uploadFile.size / 1024).toFixed(1)} KB` : 'Pre-lagged or daily chronological observation time-series'}
                  </span>
                </label>
              </div>

              <button
                type="submit"
                disabled={!uploadFile || isProcessing}
                className="w-full py-3 bg-indigo-600 hover:bg-indigo-700 disabled:opacity-50 text-white font-bold text-sm rounded-xl transition-all shadow-sm"
              >
                {isProcessing ? 'Processing Dataset...' : '1. Upload & Verify Dataset'}
              </button>
            </form>
          ) : (
            <div className="space-y-6">
              {/* Draft / Audited / Approved Banner */}
              <div className="p-4 bg-slate-50 border border-slate-200 rounded-xl flex items-center justify-between">
                <div>
                  <div className="flex items-center gap-2">
                    <span className={`px-2.5 py-0.5 text-xs font-extrabold rounded-full ${
                      currentCalibration.status === 'AUDITED' ? 'bg-indigo-100 text-indigo-700' :
                      currentCalibration.status === 'APPROVED' ? 'bg-emerald-100 text-emerald-700' :
                      currentCalibration.status === 'DEPLOYED' ? 'bg-blue-100 text-blue-700' : 'bg-slate-200 text-slate-700'
                    }`}>
                      {currentCalibration.status}
                    </span>
                    <span className="text-xs font-bold text-slate-700">{currentCalibration.sourceFilename}</span>
                  </div>
                  <p className="text-xs text-slate-400 font-mono mt-1">SHA-256: {currentCalibration.sourceSha256?.slice(0, 24)}...</p>
                </div>
                <div className="text-right">
                  <span className="text-xs font-medium text-slate-400">Combined / New Year Rows:</span>
                  <p className="text-sm font-extrabold text-slate-800">{currentCalibration.effectiveRowCount} total ({currentCalibration.newYearEffectiveRowCount || 0} new)</p>
                </div>
              </div>

              {/* Step 2: Run Button if DRAFT */}
              {currentCalibration.status === 'DRAFT' && (
                <button
                  onClick={() => handleRun(currentCalibration._id)}
                  disabled={isProcessing}
                  className="w-full py-3 bg-indigo-600 hover:bg-indigo-700 disabled:opacity-50 text-white font-bold text-sm rounded-xl transition-all shadow-sm"
                >
                  {isProcessing ? 'Running Estimation...' : '2. Run Deterministic OLS & HC3 Diagnostics'}
                </button>
              )}

              {/* Step 3: Statistical Diagnostics Results if AUDITED or APPROVED */}
              {['AUDITED', 'APPROVED', 'DEPLOYED'].includes(currentCalibration.status) && (
                <div className="space-y-4">
                  {/* Diagnostic Badge */}
                  <div className={`p-4 rounded-xl border flex items-center justify-between ${
                    currentCalibration.diagnosticPassed
                      ? 'bg-emerald-50 border-emerald-200 text-emerald-900'
                      : 'bg-rose-50 border-rose-200 text-rose-900'
                  }`}>
                    <div className="flex items-center gap-3">
                      <span className="text-2xl">{currentCalibration.diagnosticPassed ? '✅' : '❌'}</span>
                      <div>
                        <p className="text-sm font-bold">
                          {currentCalibration.diagnosticPassed ? 'All Statistical Diagnostic Gates Passed' : 'Statistical Diagnostic Failure'}
                        </p>
                        <p className="text-xs opacity-80">
                          {currentCalibration.diagnosticPassed
                            ? 'All slope HC3 p < 0.05, max VIF ≤ 5.0, non-singular OLS solver.'
                            : currentCalibration.diagnosticFailures?.join('; ')}
                        </p>
                      </div>
                    </div>
                    <div className="text-right">
                      <span className="text-xs font-semibold">Max VIF:</span>
                      <p className="text-sm font-bold font-mono">{currentCalibration.maxVif?.toFixed(2) || '1.00'}</p>
                    </div>
                  </div>

                  {/* Coefficients & HC3 Table */}
                  <div className="border border-slate-200 rounded-xl overflow-hidden">
                    <table className="w-full text-left text-xs font-mono">
                      <thead className="bg-slate-100 border-b border-slate-200 text-slate-600 font-bold">
                        <tr>
                          <th className="px-3 py-2">Parameter</th>
                          <th className="px-3 py-2 text-right">Recalibrated β</th>
                          <th className="px-3 py-2 text-right">HC3 SE</th>
                          <th className="px-3 py-2 text-right">t-stat</th>
                          <th className="px-3 py-2 text-right">p-value</th>
                          <th className="px-3 py-2 text-right">VIF</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-slate-100">
                        {currentCalibration.coefficients && Object.entries(currentCalibration.coefficients).map(([k, beta]) => {
                          const se = currentCalibration.standardErrorsHC3?.[k];
                          const t = currentCalibration.hc3TStats?.[k];
                          const p = currentCalibration.hc3PValues?.[k];
                          const vif = currentCalibration.vifByPredictor?.[k];
                          const isSig = p !== undefined ? p < 0.05 : true;

                          return (
                            <tr key={k} className="hover:bg-slate-50/50">
                              <td className="px-3 py-2 font-bold text-slate-800">{k}</td>
                              <td className="px-3 py-2 text-right font-extrabold text-indigo-900">{Number(beta).toFixed(6)}</td>
                              <td className="px-3 py-2 text-right text-slate-600">{se ? Number(se).toFixed(6) : '—'}</td>
                              <td className="px-3 py-2 text-right text-slate-600">{t ? Number(t).toFixed(3) : '—'}</td>
                              <td className={`px-3 py-2 text-right font-bold ${isSig ? 'text-emerald-700' : 'text-rose-600'}`}>
                                {p !== undefined ? (p < 0.0001 ? p.toExponential(3) : p.toFixed(4)) : '—'}
                              </td>
                              <td className="px-3 py-2 text-right text-slate-600">{vif ? Number(vif).toFixed(2) : '1.00'}</td>
                            </tr>
                          );
                        })}
                      </tbody>
                    </table>
                  </div>

                  {/* Validation vs Persistence Metrics */}
                  <div className="grid grid-cols-2 gap-4">
                    <div className="p-3 bg-slate-50 border border-slate-200 rounded-xl text-xs space-y-1">
                      <span className="font-bold text-slate-600">OLS Validation Split Metrics:</span>
                      <div className="flex justify-between text-slate-800">
                        <span>MAE:</span>
                        <span className="font-bold font-mono">{currentCalibration.validationMAE?.toFixed(4)} m</span>
                      </div>
                      <div className="flex justify-between text-slate-800">
                        <span>RMSE:</span>
                        <span className="font-bold font-mono">{currentCalibration.validationRMSE?.toFixed(4)} m</span>
                      </div>
                    </div>
                    <div className="p-3 bg-slate-50 border border-slate-200 rounded-xl text-xs space-y-1">
                      <span className="font-bold text-slate-600">In-Situ Persistence Benchmark:</span>
                      <div className="flex justify-between text-slate-800">
                        <span>Persistence MAE:</span>
                        <span className="font-bold font-mono">{currentCalibration.persistenceMAE?.toFixed(4)} m</span>
                      </div>
                      <div className="flex justify-between text-slate-800">
                        <span>Persistence RMSE:</span>
                        <span className="font-bold font-mono">{currentCalibration.persistenceRMSE?.toFixed(4)} m</span>
                      </div>
                    </div>
                  </div>

                  {/* Action Governance Buttons */}
                  <div className="flex items-center gap-3 pt-2">
                    {currentCalibration.status === 'AUDITED' && (
                      <>
                        <button
                          onClick={() => handleApprove(currentCalibration._id)}
                          disabled={!currentCalibration.diagnosticPassed || isProcessing}
                          className="flex-1 py-2.5 bg-emerald-600 hover:bg-emerald-700 disabled:opacity-50 text-white font-bold text-xs rounded-xl transition-all shadow-sm"
                        >
                          Approve Calibration
                        </button>
                        <button
                          onClick={() => setShowRejectModal(true)}
                          disabled={isProcessing}
                          className="px-4 py-2.5 bg-rose-50 hover:bg-rose-100 text-rose-700 font-bold text-xs rounded-xl border border-rose-200 transition-colors"
                        >
                          Reject
                        </button>
                      </>
                    )}

                    {currentCalibration.status === 'APPROVED' && (
                      <button
                        onClick={() => {
                          setPasswordAction('ACTIVATE');
                          setShowPasswordModal(true);
                        }}
                        disabled={isProcessing}
                        className="flex-1 py-3 bg-indigo-600 hover:bg-indigo-700 text-white font-bold text-sm rounded-xl transition-all shadow-sm flex items-center justify-center gap-2"
                      >
                        <span>🔒 Activate & Deploy to Production</span>
                      </button>
                    )}
                  </div>
                </div>
              )}
            </div>
          )}
        </div>
      </div>

      {/* Historical Calibrations Table */}
      <div className="bg-white border border-slate-200 rounded-2xl p-6 shadow-sm mb-8">
        <h3 className="text-lg font-bold text-slate-900 mb-4">Historical Calibration Records ({STATION_META[selectedStation].name})</h3>
        {stationCalibrations.length === 0 ? (
          <p className="text-xs text-slate-400 py-4 text-center">No calibration records found for this station.</p>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="bg-slate-50 border-b border-slate-200 text-slate-500 font-semibold">
                <tr>
                  <th className="px-4 py-2.5">Date</th>
                  <th className="px-4 py-2.5">Source Dataset</th>
                  <th className="px-4 py-2.5">Status</th>
                  <th className="px-4 py-2.5">Diagnostics</th>
                  <th className="px-4 py-2.5">Max VIF</th>
                  <th className="px-4 py-2.5">Val MAE</th>
                  <th className="px-4 py-2.5">Created By</th>
                  <th className="px-4 py-2.5 text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {stationCalibrations.map((c) => (
                  <tr key={c._id} className="hover:bg-slate-50/50">
                    <td className="px-4 py-3 font-medium text-slate-600">
                      {new Date(c.createdAt).toLocaleDateString()}
                    </td>
                    <td className="px-4 py-3 font-bold text-slate-800">{c.sourceFilename}</td>
                    <td className="px-4 py-3">
                      <span className={`px-2 py-0.5 text-2xs font-extrabold rounded-full ${
                        c.status === 'DEPLOYED' ? 'bg-blue-100 text-blue-800' :
                        c.status === 'APPROVED' ? 'bg-emerald-100 text-emerald-800' :
                        c.status === 'AUDITED' ? 'bg-indigo-100 text-indigo-800' :
                        c.status === 'REJECTED' ? 'bg-rose-100 text-rose-800' : 'bg-slate-100 text-slate-700'
                      }`}>
                        {c.status}
                      </span>
                    </td>
                    <td className="px-4 py-3">
                      {c.diagnosticPassed !== undefined ? (
                        c.diagnosticPassed ? <span className="text-emerald-600 font-bold">PASS</span> : <span className="text-rose-600 font-bold">FAIL</span>
                      ) : '—'}
                    </td>
                    <td className="px-4 py-3 font-mono">{c.maxVif ? c.maxVif.toFixed(2) : '—'}</td>
                    <td className="px-4 py-3 font-mono">{c.validationMAE ? `${c.validationMAE.toFixed(3)} m` : '—'}</td>
                    <td className="px-4 py-3 text-slate-500">{c.createdBy}</td>
                    <td className="px-4 py-3 text-right">
                      <button
                        onClick={() => setCurrentCalibration(c)}
                        className="px-3 py-1 bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold text-xs rounded-lg transition-colors"
                      >
                        Inspect
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {/* Immutable Governance Audit Trail */}
      <div className="bg-white border border-slate-200 rounded-2xl p-6 shadow-sm">
        <h3 className="text-lg font-bold text-slate-900 mb-4">Immutable Governance Audit Log</h3>
        {auditLogs.length === 0 ? (
          <p className="text-xs text-slate-400 py-4 text-center">No governance events logged yet.</p>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs font-mono">
              <thead className="bg-slate-50 border-b border-slate-200 text-slate-500 font-semibold">
                <tr>
                  <th className="px-4 py-2.5">Timestamp</th>
                  <th className="px-4 py-2.5">Action</th>
                  <th className="px-4 py-2.5">Station</th>
                  <th className="px-4 py-2.5">Actor</th>
                  <th className="px-4 py-2.5">Version Transition</th>
                  <th className="px-4 py-2.5">Details</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {auditLogs.map((log) => (
                  <tr key={log._id} className="hover:bg-slate-50/50">
                    <td className="px-4 py-2.5 text-slate-500">{new Date(log.timestamp).toLocaleString()}</td>
                    <td className="px-4 py-2.5">
                      <span className={`px-2 py-0.5 rounded text-2xs font-extrabold ${
                        log.action === 'ACTIVATE' ? 'bg-indigo-100 text-indigo-800' :
                        log.action === 'APPROVE' ? 'bg-emerald-100 text-emerald-800' :
                        log.action === 'ROLLBACK' ? 'bg-rose-100 text-rose-800' : 'bg-slate-100 text-slate-700'
                      }`}>
                        {log.action}
                      </span>
                    </td>
                    <td className="px-4 py-2.5 font-bold text-slate-700">{log.stationId}</td>
                    <td className="px-4 py-2.5 text-slate-600">{log.actorUserId}</td>
                    <td className="px-4 py-2.5 text-slate-600">
                      {log.fromVersion || log.toVersion ? `${log.fromVersion || 'Baseline'} → ${log.toVersion}` : '—'}
                    </td>
                    <td className="px-4 py-2.5 text-slate-500 truncate max-w-xs">{log.reason || JSON.stringify(log.metadata || {})}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {/* Password Reconfirmation Modal */}
      {showPasswordModal && (
        <div className="fixed inset-0 bg-slate-900/50 backdrop-blur-sm flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-2xl p-6 max-w-md w-full shadow-xl border border-slate-200 space-y-4">
            <div className="flex items-center gap-3">
              <span className="w-10 h-10 rounded-full bg-indigo-100 text-indigo-700 flex items-center justify-center text-lg font-bold">
                🔒
              </span>
              <div>
                <h4 className="text-lg font-bold text-slate-900">
                  {passwordAction === 'ACTIVATE' ? 'Authorize Model Activation' : 'Authorize Model Rollback'}
                </h4>
                <p className="text-xs text-slate-500">Super-Admin password reconfirmation is required.</p>
              </div>
            </div>

            {passwordError && (
              <p className="p-3 bg-rose-50 border border-rose-200 text-rose-700 text-xs font-bold rounded-lg">
                ⚠️ {passwordError}
              </p>
            )}

            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">Enter Super-Admin Password</label>
              <input
                type="password"
                value={reconfirmPassword}
                onChange={(e) => setReconfirmPassword(e.target.value)}
                placeholder="••••••••••••"
                className="w-full px-4 py-2.5 border border-slate-300 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500"
              />
            </div>

            <div className="flex items-center justify-end gap-3 pt-2">
              <button
                type="button"
                onClick={() => {
                  setShowPasswordModal(false);
                  setReconfirmPassword('');
                  setPasswordError(null);
                }}
                className="px-4 py-2 text-xs font-bold text-slate-600 hover:text-slate-900"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={handleConfirmPasswordAction}
                disabled={isProcessing || !reconfirmPassword}
                className="px-5 py-2.5 bg-indigo-600 hover:bg-indigo-700 disabled:opacity-50 text-white font-bold text-xs rounded-xl transition-all shadow-sm"
              >
                {isProcessing ? 'Verifying...' : 'Authorize Action'}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Reject Modal */}
      {showRejectModal && (
        <div className="fixed inset-0 bg-slate-900/50 backdrop-blur-sm flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-2xl p-6 max-w-md w-full shadow-xl border border-slate-200 space-y-4">
            <h4 className="text-lg font-bold text-slate-900">Reject Calibration</h4>
            <p className="text-xs text-slate-500">Provide an auditable reason for rejecting this calibration run.</p>

            <textarea
              value={rejectionReason}
              onChange={(e) => setRejectionReason(e.target.value)}
              placeholder="e.g., Elevated VIF collinearity on rainfall coefficient, anomalous RMSE spike..."
              rows={3}
              className="w-full px-4 py-2 border border-slate-300 rounded-xl text-xs focus:outline-none focus:ring-2 focus:ring-rose-500"
            />

            <div className="flex items-center justify-end gap-3 pt-2">
              <button
                type="button"
                onClick={() => setShowRejectModal(false)}
                className="px-4 py-2 text-xs font-bold text-slate-600 hover:text-slate-900"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={() => handleReject(currentCalibration?._id)}
                disabled={isProcessing}
                className="px-5 py-2.5 bg-rose-600 hover:bg-rose-700 disabled:opacity-50 text-white font-bold text-xs rounded-xl transition-all shadow-sm"
              >
                {isProcessing ? 'Rejecting...' : 'Confirm Rejection'}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default Algorithm;
