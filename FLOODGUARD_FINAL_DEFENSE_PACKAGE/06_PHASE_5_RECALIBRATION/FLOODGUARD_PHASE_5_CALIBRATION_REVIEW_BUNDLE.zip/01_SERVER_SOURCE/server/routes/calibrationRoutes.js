/**
 * FloodGuard Controlled Calibration & Governance API Routes (Phase 5 Final Production-Path)
 * 
 * Secure server-side routes for super-admin yearly model recalibration,
 * statistical diagnostics review, activation with password reconfirmation,
 * one-click rollback, and immutable audit logging.
 */

import express from 'express';
import multer from 'multer';
import crypto from 'crypto';
import xlsx from 'xlsx';
import bcrypt from 'bcryptjs';
import jwt from 'jsonwebtoken';
import { ModelCalibration } from '../models/ModelCalibration.js';
import { CalibrationAuditLog } from '../models/CalibrationAuditLog.js';
import { ActiveModelVersion } from '../models/ActiveModelVersion.js';
import {
    runCalibration,
    preprocessCalibrationData,
    validateYearlyUploadedRows,
    CALIBRATION_SPECIFICATIONS,
    normalizeRawDailyRow,
} from '../services/calibrationEngine.js';
import {
    invalidateActiveModelCache,
    resolveActiveStationModels,
} from '../services/dailyForecastService.js';
import { PROTECTED_HISTORY_REGISTRY } from '../config/protectedHistoryRegistry.js';
import { STATION_MODEL_REGISTRY } from '../config/stationModelRegistry.js';

export const calibrationRouter = express.Router();

// ── Strict Authentication: No Hardcoded Secret Fallback ──────────

export const getJwtSecret = () => {
    const secret = process.env.JWT_SECRET;
    if (!secret) {
        throw new Error('Server auth configuration error: JWT_SECRET must be configured in environment.');
    }
    return secret;
};

export const authenticateToken = (req, res, next) => {
    let secret;
    try {
        secret = getJwtSecret();
    } catch (err) {
        return res.status(500).json({ success: false, message: err.message });
    }

    const authHeader = req.headers['authorization'];
    const token = authHeader && authHeader.split(' ')[1];
    if (!token) return res.status(401).json({ success: false, message: 'Access denied. No token provided.' });

    jwt.verify(token, secret, (err, user) => {
        if (err) return res.status(403).json({ success: false, message: 'Invalid or expired token.' });
        req.user = user;
        next();
    });
};

export const requireAdmin = (req, res, next) => {
    if (!req.user || (req.user.role !== 'admin' && req.user.role !== 'super_admin')) {
        return res.status(403).json({ success: false, message: 'Admin access required.' });
    }
    next();
};

export const requireSuperAdmin = async (req, res, next) => {
    if (!req.user) {
        return res.status(401).json({ success: false, message: 'Authentication required.' });
    }
    try {
        const AdminUser = req.app.get('AdminUserModel');
        if (AdminUser) {
            const user = await AdminUser.findById(req.user.id);
            if (!user || user.role !== 'super_admin') {
                return res.status(403).json({ success: false, message: 'Super-admin access required.' });
            }
            req.superAdminUser = user;
        } else if (req.user.role !== 'super_admin') {
            return res.status(403).json({ success: false, message: 'Super-admin access required.' });
        }
        next();
    } catch (err) {
        return res.status(500).json({ success: false, message: 'Failed to verify super-admin authorization.' });
    }
};

export const verifyPasswordReconfirmation = async (req, res, next) => {
    const { reconfirmPassword } = req.body || {};
    if (!reconfirmPassword) {
        return res.status(400).json({ success: false, message: 'Password reconfirmation required for this action.' });
    }
    const user = req.superAdminUser;
    if (!user || !user.password) {
        return res.status(403).json({ success: false, message: 'Super-admin authorization failed.' });
    }
    const isMatch = await bcrypt.compare(reconfirmPassword, user.password);
    if (!isMatch) {
        return res.status(403).json({ success: false, message: 'Invalid password reconfirmation.' });
    }
    next();
};

// Memory storage with 20MB limit for dataset uploads
const upload = multer({
    storage: multer.memoryStorage(),
    limits: { fileSize: 20 * 1024 * 1024 },
});

// ── Helper: Parse CSV or XLSX Buffer into Object Rows ─────────────
export function parseBufferToRows(buffer, originalname = '') {
    const isXlsx = originalname.endsWith('.xlsx') || originalname.endsWith('.xls');

    if (isXlsx) {
        const workbook = xlsx.read(buffer, { type: 'buffer' });
        const sheetName = workbook.SheetNames[0];
        const sheet = workbook.Sheets[sheetName];
        return xlsx.utils.sheet_to_json(sheet, { defval: null });
    } else {
        const text = buffer.toString('utf8');
        const lines = text.trim().split(/\r?\n/);
        if (lines.length === 0) return [];
        const headers = lines[0].split(',').map(h => h.trim().replace(/^["']|["']$/g, ''));
        const rows = [];
        for (let i = 1; i < lines.length; i++) {
            const line = lines[i].trim();
            if (!line) continue;
            const vals = line.split(',').map(v => v.trim().replace(/^["']|["']$/g, ''));
            const obj = {};
            headers.forEach((h, idx) => {
                obj[h] = vals[idx] !== undefined && vals[idx] !== '' ? vals[idx] : null;
            });
            rows.push(obj);
        }
        return rows;
    }
}

// ── 1. POST /api/calibration/upload ──────────────────────────────
// Uploads yearly dataset, validates raw schema & dynamic cutoff, persists durable snapshot
calibrationRouter.post('/upload', authenticateToken, requireSuperAdmin, upload.single('dataset'), async (req, res) => {
    try {
        const { stationId } = req.body;
        if (!stationId || !CALIBRATION_SPECIFICATIONS[stationId]) {
            return res.status(400).json({
                success: false,
                message: `Valid stationId is required ('sto_nino', 'nangka', 'tumana'). Received: ${stationId}`,
            });
        }

        if (!req.file || !req.file.buffer) {
            return res.status(400).json({
                success: false,
                message: 'A dataset file (CSV or XLSX) is required.',
            });
        }

        const originalname = req.file.originalname || 'dataset.csv';
        const fileExt = originalname.split('.').pop().toLowerCase();
        if (!['csv', 'xlsx', 'xls'].includes(fileExt)) {
            return res.status(400).json({
                success: false,
                message: 'Invalid file format. Only CSV and Excel (XLSX) files are accepted.',
            });
        }

        const sha256 = crypto.createHash('sha256').update(req.file.buffer).digest('hex');
        const rows = parseBufferToRows(req.file.buffer, originalname);

        if (rows.length === 0) {
            return res.status(400).json({
                success: false,
                message: 'The uploaded dataset is empty.',
            });
        }

        // Determine dynamic latest accepted cutoff date across protected base + prior accepted years
        const priorCalibrations = await ModelCalibration.find({
            stationId,
            status: { $in: ['DEPLOYED', 'SUPERSEDED'] },
        }).sort({ createdAt: 1 });

        const spec = CALIBRATION_SPECIFICATIONS[stationId];
        let latestAcceptedDate = PROTECTED_HISTORY_REGISTRY[stationId]?.endDate || '2023-12-31';
        for (const pc of priorCalibrations) {
            if (Array.isArray(pc.uploadedRows)) {
                for (const pr of pc.uploadedRows) {
                    const normalized = normalizeRawDailyRow(stationId, pr);
                    const d = normalized.Date;
                    if (d && d > latestAcceptedDate) latestAcceptedDate = d;
                }
            }
        }

        // Strict raw-schema validation and duplicate/overlap/future check
        validateYearlyUploadedRows(stationId, rows, latestAcceptedDate);

        const actor = req.superAdminUser ? req.superAdminUser.username : (req.user?.username || 'super_admin');

        // Persist the durable uploaded rows snapshot on the document (always isCanonicalFixture = false)
        const cal = new ModelCalibration({
            stationId,
            candidateId: spec.candidateId,
            candidateDescription: spec.candidateDescription,
            status: 'DRAFT',
            sourceFilename: originalname,
            sourceSha256: sha256,
            sourceRowCount: rows.length,
            uploadedSourceRowCount: rows.length,
            newYearEffectiveRowCount: 0,
            effectiveRowCount: 0,
            uploadedRows: rows, // Durable server-side snapshot
            isCanonicalFixture: false, // Production HTTP uploads are never fixture mode
            createdBy: actor,
        });

        await cal.save();

        // Immutable Audit Log
        await CalibrationAuditLog.create({
            action: 'UPLOAD',
            stationId,
            calibrationId: cal._id.toString(),
            actorUserId: actor,
            metadata: {
                sourceFilename: originalname,
                sourceSha256: sha256,
                sourceRowCount: rows.length,
                latestAcceptedDate,
            },
        });

        res.json({
            success: true,
            message: 'Dataset uploaded, validated, and persisted as durable snapshot. Status: DRAFT.',
            calibrationId: cal._id,
            calibration: cal,
        });
    } catch (err) {
        console.error('Upload Calibration Error:', err);
        res.status(400).json({ success: false, message: err.message });
    }
});

// ── 2. POST /api/calibration/:id/run ─────────────────────────────
// Executes two-stage evaluation + final refit strictly from the persisted uploaded snapshot + prior history
calibrationRouter.post('/:id/run', authenticateToken, requireSuperAdmin, async (req, res) => {
    try {
        const cal = await ModelCalibration.findById(req.params.id);
        if (!cal) {
            return res.status(404).json({ success: false, message: 'Calibration record not found.' });
        }

        // Strictly load rows ONLY from persisted calibration snapshot (no body.rows replacement allowed)
        const uploadedRows = cal.uploadedRows;
        if (!Array.isArray(uploadedRows) || uploadedRows.length === 0) {
            return res.status(400).json({
                success: false,
                message: 'No persisted dataset snapshot found on calibration record. Re-upload dataset.',
            });
        }

        // Query prior accepted yearly snapshots (DEPLOYED or SUPERSEDED)
        const priorCalibrations = await ModelCalibration.find({
            stationId: cal.stationId,
            status: { $in: ['DEPLOYED', 'SUPERSEDED'] },
            _id: { $ne: cal._id },
        }).sort({ createdAt: 1 });

        const priorAcceptedRows = [];
        for (const pc of priorCalibrations) {
            if (Array.isArray(pc.uploadedRows) && pc.uploadedRows.length > 0) {
                priorAcceptedRows.push(...pc.uploadedRows);
            }
        }

        const actor = req.superAdminUser ? req.superAdminUser.username : (req.user?.username || 'super_admin');

        const result = runCalibration({
            stationId: cal.stationId,
            uploadedRows,
            isCanonicalFixture: false, // Production runs are always standard recalibration
            priorAcceptedRows,
            sourceFilename: cal.sourceFilename,
            sourceSha256: cal.sourceSha256,
            createdBy: actor,
        });

        // Update calibration record
        cal.status = 'AUDITED';
        cal.sourceRowCount = result.sourceRowCount;
        cal.uploadedSourceRowCount = result.uploadedSourceRowCount;
        cal.newYearEffectiveRowCount = result.newYearEffectiveRowCount;
        cal.effectiveRowCount = result.effectiveRowCount;
        cal.protectedHistorySha256 = result.protectedHistorySha256;
        cal.protectedHistoryRowCount = result.protectedHistoryRowCount;
        cal.trainingPeriod = result.trainingPeriod;
        cal.validationPeriod = result.validationPeriod;
        cal.evaluationCoefficients = result.evaluationCoefficients;
        cal.coefficients = result.coefficients; // Final full-history refit coefficients for activation
        cal.standardErrorsOLS = result.standardErrorsOLS;
        cal.standardErrorsHC3 = result.standardErrorsHC3;
        cal.hc3TStats = result.hc3TStats;
        cal.hc3PValues = result.hc3PValues;
        cal.vifByPredictor = result.vifByPredictor;
        cal.maxVif = result.maxVif;
        cal.validationMAE = result.validationMAE;
        cal.validationRMSE = result.validationRMSE;
        cal.validationR2 = result.validationR2;
        cal.persistenceMAE = result.persistenceMAE;
        cal.persistenceRMSE = result.persistenceRMSE;
        cal.diagnosticPassed = result.diagnosticPassed;
        cal.diagnosticFailures = result.diagnosticFailures;
        cal.canonicalParityResult = result.canonicalParityResult;

        await cal.save();

        // Audit Log
        await CalibrationAuditLog.create({
            action: 'RUN',
            stationId: cal.stationId,
            calibrationId: cal._id.toString(),
            actorUserId: actor,
            metadata: {
                diagnosticPassed: cal.diagnosticPassed,
                maxVif: cal.maxVif,
                validationMAE: cal.validationMAE,
                validationRMSE: cal.validationRMSE,
                effectiveRowCount: cal.effectiveRowCount,
                newYearEffectiveRowCount: cal.newYearEffectiveRowCount,
            },
        });

        res.json({
            success: true,
            message: 'Two-stage calibration complete. Status: AUDITED.',
            calibration: cal,
        });
    } catch (err) {
        console.error('Run Calibration Error:', err);
        res.status(500).json({ success: false, message: err.message });
    }
});

// ── 3. GET /api/calibration ──────────────────────────────────────
// Lists all calibrations sorted by createdAt desc
calibrationRouter.get('/', authenticateToken, requireAdmin, async (req, res) => {
    try {
        const calibrations = await ModelCalibration.find({}).sort({ createdAt: -1 });
        res.json({ success: true, calibrations });
    } catch (err) {
        console.error('List Calibrations Error:', err);
        res.status(500).json({ success: false, message: err.message });
    }
});

// ── 4. GET /api/calibration/active ───────────────────────────────
// Returns current active deployed models per station
calibrationRouter.get('/active', authenticateToken, requireAdmin, async (req, res) => {
    try {
        const activeModels = await resolveActiveStationModels();
        const activeVersions = await ActiveModelVersion.find({});
        res.json({
            success: true,
            activeModels,
            activeVersions,
            canonicalRegistry: STATION_MODEL_REGISTRY,
        });
    } catch (err) {
        console.error('Get Active Models Error:', err);
        res.status(500).json({ success: false, message: err.message });
    }
});

// ── 5. GET /api/calibration/audit-logs ───────────────────────────
// Returns immutable audit trail of all governance events
calibrationRouter.get('/audit-logs', authenticateToken, requireAdmin, async (req, res) => {
    try {
        const logs = await CalibrationAuditLog.find({}).sort({ timestamp: -1 }).limit(100);
        res.json({ success: true, logs });
    } catch (err) {
        console.error('Get Audit Logs Error:', err);
        res.status(500).json({ success: false, message: err.message });
    }
});

// ── 6. GET /api/calibration/:id ──────────────────────────────────
// Returns specific calibration record details
calibrationRouter.get('/:id', authenticateToken, requireAdmin, async (req, res) => {
    try {
        const cal = await ModelCalibration.findById(req.params.id);
        if (!cal) {
            return res.status(404).json({ success: false, message: 'Calibration record not found.' });
        }
        res.json({ success: true, calibration: cal });
    } catch (err) {
        console.error('Get Calibration Error:', err);
        res.status(500).json({ success: false, message: err.message });
    }
});

// ── 7. POST /api/calibration/:id/approve ─────────────────────────
// Transitions AUDITED -> APPROVED (Super-Admin only; requires diagnosticPassed)
calibrationRouter.post('/:id/approve', authenticateToken, requireSuperAdmin, async (req, res) => {
    try {
        const cal = await ModelCalibration.findById(req.params.id);
        if (!cal) {
            return res.status(404).json({ success: false, message: 'Calibration record not found.' });
        }

        if (cal.status !== 'AUDITED') {
            return res.status(400).json({
                success: false,
                message: `Only calibrations in AUDITED status can be approved. Current status: ${cal.status}`,
            });
        }

        if (!cal.diagnosticPassed) {
            return res.status(400).json({
                success: false,
                message: `Cannot approve calibration that failed statistical diagnostic gates. Failures: ${cal.diagnosticFailures.join('; ')}`,
            });
        }

        const actor = req.superAdminUser ? req.superAdminUser.username : (req.user?.username || 'super_admin');
        cal.status = 'APPROVED';
        cal.reviewedBy = actor;
        cal.reviewedAt = new Date();
        await cal.save();

        await CalibrationAuditLog.create({
            action: 'APPROVE',
            stationId: cal.stationId,
            calibrationId: cal._id.toString(),
            actorUserId: actor,
        });

        res.json({
            success: true,
            message: 'Calibration approved for deployment eligibility. Status: APPROVED.',
            calibration: cal,
        });
    } catch (err) {
        console.error('Approve Calibration Error:', err);
        res.status(500).json({ success: false, message: err.message });
    }
});

// ── 8. POST /api/calibration/:id/reject ──────────────────────────
// Transitions to REJECTED with reason
calibrationRouter.post('/:id/reject', authenticateToken, requireSuperAdmin, async (req, res) => {
    try {
        const cal = await ModelCalibration.findById(req.params.id);
        if (!cal) {
            return res.status(404).json({ success: false, message: 'Calibration record not found.' });
        }

        const actor = req.superAdminUser ? req.superAdminUser.username : (req.user?.username || 'super_admin');
        const reason = req.body.reason || 'Rejected by super administrator.';

        cal.status = 'REJECTED';
        cal.rejectionReason = reason;
        cal.reviewedBy = actor;
        cal.reviewedAt = new Date();
        await cal.save();

        await CalibrationAuditLog.create({
            action: 'REJECT',
            stationId: cal.stationId,
            calibrationId: cal._id.toString(),
            actorUserId: actor,
            reason,
        });

        res.json({
            success: true,
            message: 'Calibration rejected. Status: REJECTED.',
            calibration: cal,
        });
    } catch (err) {
        console.error('Reject Calibration Error:', err);
        res.status(500).json({ success: false, message: err.message });
    }
});

// ── 9. POST /api/calibration/:id/activate ────────────────────────
// Activates APPROVED calibration with password reconfirmation using FINAL REFIT coefficients
calibrationRouter.post('/:id/activate', authenticateToken, requireSuperAdmin, verifyPasswordReconfirmation, async (req, res) => {
    try {
        const cal = await ModelCalibration.findById(req.params.id);
        if (!cal) {
            return res.status(404).json({ success: false, message: 'Calibration record not found.' });
        }

        // Defense-in-depth: Reject activation of test fixture records
        if (cal.isCanonicalFixture === true) {
            return res.status(400).json({
                success: false,
                message: 'Canonical fixture test records cannot be activated for production deployment.',
            });
        }

        if (cal.status !== 'APPROVED') {
            return res.status(400).json({
                success: false,
                message: `Only APPROVED calibrations can be activated. Current status: ${cal.status}`,
            });
        }

        if (!cal.diagnosticPassed) {
            return res.status(400).json({
                success: false,
                message: 'Cannot activate a calibration that failed statistical diagnostic gates.',
            });
        }

        const actor = req.superAdminUser ? req.superAdminUser.username : (req.user?.username || 'super_admin');

        const existingActive = await ActiveModelVersion.findOne({ stationId: cal.stationId });
        const previousVersion = existingActive ? existingActive.modelVersion : '2.0.0-CERTIFIED';
        const previousCoefficients = existingActive ? existingActive.coefficients : null;

        const newVersion = `2.0.0-CALIBRATED-${cal._id.toString().slice(-6).toUpperCase()}`;

        // Upsert ActiveModelVersion with FINAL REFIT coefficients
        const activeRecord = await ActiveModelVersion.findOneAndUpdate(
            { stationId: cal.stationId },
            {
                stationId: cal.stationId,
                modelVersion: newVersion,
                candidateId: cal.candidateId,
                coefficients: cal.coefficients, // Final refit coefficients
                activatedAt: new Date(),
                activatedBy: actor,
                sourceCalibrationId: cal._id.toString(),
                previousVersion,
                previousCoefficients,
            },
            { upsert: true, new: true }
        );

        // Mark previously deployed calibration as SUPERSEDED
        await ModelCalibration.updateMany(
            { stationId: cal.stationId, status: 'DEPLOYED', _id: { $ne: cal._id } },
            { $set: { status: 'SUPERSEDED' } }
        );

        // Mark current calibration as DEPLOYED
        cal.status = 'DEPLOYED';
        cal.activatedBy = actor;
        cal.activatedAt = new Date();
        cal.newModelVersion = newVersion;
        cal.previousModelVersion = previousVersion;
        await cal.save();

        invalidateActiveModelCache();

        // Audit Log
        await CalibrationAuditLog.create({
            action: 'ACTIVATE',
            stationId: cal.stationId,
            calibrationId: cal._id.toString(),
            actorUserId: actor,
            fromVersion: previousVersion,
            toVersion: newVersion,
            metadata: {
                coefficients: Object.fromEntries(cal.coefficients),
            },
        });

        res.json({
            success: true,
            message: `Calibration activated successfully. Live model version updated to ${newVersion}.`,
            calibration: cal,
            activeVersion: activeRecord,
        });
    } catch (err) {
        console.error('Activate Calibration Error:', err);
        res.status(500).json({ success: false, message: err.message });
    }
});

// ── 10. POST /api/calibration/rollback/:stationId ────────────────
// Reverts active model to previous active version or baseline canonical registry
calibrationRouter.post('/rollback/:stationId', authenticateToken, requireSuperAdmin, verifyPasswordReconfirmation, async (req, res) => {
    try {
        const { stationId } = req.params;
        if (!CALIBRATION_SPECIFICATIONS[stationId]) {
            return res.status(400).json({ success: false, message: `Invalid stationId: ${stationId}` });
        }

        const active = await ActiveModelVersion.findOne({ stationId });
        if (!active) {
            return res.json({
                success: true,
                message: `Station ${stationId} is already using the canonical certified baseline model.`,
                stationId,
                modelVersion: '2.0.0-CERTIFIED',
            });
        }

        const actor = req.superAdminUser ? req.superAdminUser.username : (req.user?.username || 'super_admin');
        const fromVersion = active.modelVersion;
        let toVersion = '2.0.0-CERTIFIED';

        if (active.sourceCalibrationId) {
            await ModelCalibration.findByIdAndUpdate(active.sourceCalibrationId, {
                $set: { status: 'ROLLED_BACK' },
            });
        }

        if (active.previousCoefficients && active.previousVersion && active.previousVersion !== '2.0.0-CERTIFIED') {
            active.modelVersion = active.previousVersion;
            active.coefficients = active.previousCoefficients;
            active.activatedAt = new Date();
            active.activatedBy = `${actor} (rollback)`;
            active.previousVersion = '2.0.0-CERTIFIED';
            active.previousCoefficients = null;
            await active.save();
            toVersion = active.modelVersion;
        } else {
            await ActiveModelVersion.deleteOne({ stationId });
            toVersion = '2.0.0-CERTIFIED';
        }

        invalidateActiveModelCache();

        await CalibrationAuditLog.create({
            action: 'ROLLBACK',
            stationId,
            actorUserId: actor,
            fromVersion,
            toVersion,
            reason: req.body.reason || 'Manual rollback by super administrator.',
        });

        res.json({
            success: true,
            message: `Station ${stationId} model rolled back from ${fromVersion} to ${toVersion}.`,
            stationId,
            fromVersion,
            toVersion,
        });
    } catch (err) {
        console.error('Rollback Error:', err);
        res.status(500).json({ success: false, message: err.message });
    }
});
