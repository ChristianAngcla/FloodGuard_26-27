import mongoose from 'mongoose';

const ActiveModelVersionSchema = new mongoose.Schema({
    stationId: {
        type: String,
        required: true,
        unique: true,
        enum: ['sto_nino', 'nangka', 'tumana'],
        index: true,
    },
    modelVersion: {
        type: String,
        required: true,
    },
    candidateId: {
        type: String,
        required: true,
    },
    coefficients: {
        type: Map,
        of: Number,
        required: true,
    },
    activatedAt: {
        type: Date,
        default: Date.now,
    },
    activatedBy: {
        type: String,
        required: true,
    },
    sourceCalibrationId: {
        type: String,
        default: null,
    },
    previousVersion: {
        type: String,
        default: null,
    },
    previousCoefficients: {
        type: Map,
        of: Number,
        default: null,
    },
}, {
    timestamps: true,
});

export const ActiveModelVersion = mongoose.models.ActiveModelVersion || mongoose.model('ActiveModelVersion', ActiveModelVersionSchema);
