import mongoose from 'mongoose';

const ModelCalibrationSchema = new mongoose.Schema({
    stationId: {
        type: String,
        required: true,
        enum: ['sto_nino', 'nangka', 'tumana'],
        index: true,
    },
    candidateId: {
        type: String,
        required: true,
    },
    candidateDescription: {
        type: String,
        required: true,
    },
    modelStructureVersion: {
        type: String,
        default: '2.0.0-LOCKED_SPECIFICATION',
    },
    status: {
        type: String,
        required: true,
        enum: ['DRAFT', 'AUDITED', 'APPROVED', 'DEPLOYED', 'REJECTED', 'ROLLED_BACK', 'SUPERSEDED'],
        default: 'DRAFT',
        index: true,
    },
    sourceFilename: {
        type: String,
        required: true,
    },
    sourceSha256: {
        type: String,
        required: true,
    },
    sourceRowCount: {
        type: Number,
        required: true,
    },
    uploadedSourceRowCount: {
        type: Number,
        default: 0,
    },
    newYearEffectiveRowCount: {
        type: Number,
        default: 0,
    },
    effectiveRowCount: {
        type: Number,
        default: 0,
    },
    uploadedRows: {
        type: [mongoose.Schema.Types.Mixed],
        default: [],
    },
    isCanonicalFixture: {
        type: Boolean,
        default: false,
    },
    protectedHistorySha256: {
        type: String,
        default: null,
    },
    protectedHistoryRowCount: {
        type: Number,
        default: 0,
    },
    trainingPeriod: {
        startDate: String,
        endDate: String,
    },
    validationPeriod: {
        startDate: String,
        endDate: String,
    },
    evaluationCoefficients: {
        type: Map,
        of: Number,
        default: {},
    },
    coefficients: {
        type: Map,
        of: Number,
        default: {},
    },
    standardErrorsOLS: {
        type: Map,
        of: Number,
        default: {},
    },
    standardErrorsHC3: {
        type: Map,
        of: Number,
        default: {},
    },
    hc3TStats: {
        type: Map,
        of: Number,
        default: {},
    },
    hc3PValues: {
        type: Map,
        of: Number,
        default: {},
    },
    vifByPredictor: {
        type: Map,
        of: Number,
        default: {},
    },
    maxVif: {
        type: Number,
        default: 0,
    },
    validationMAE: {
        type: Number,
        default: null,
    },
    validationRMSE: {
        type: Number,
        default: null,
    },
    validationR2: {
        type: Number,
        default: null,
    },
    persistenceMAE: {
        type: Number,
        default: null,
    },
    persistenceRMSE: {
        type: Number,
        default: null,
    },
    diagnosticPassed: {
        type: Boolean,
        default: false,
    },
    diagnosticFailures: {
        type: [String],
        default: [],
    },
    canonicalParityResult: {
        evaluated: { type: Boolean, default: false },
        passed: { type: Boolean, default: false },
        maxAbsoluteDifference: { type: Number, default: null },
    },
    createdBy: {
        type: String,
        required: true,
    },
    createdAt: {
        type: Date,
        default: Date.now,
    },
    reviewedBy: {
        type: String,
        default: null,
    },
    reviewedAt: {
        type: Date,
        default: null,
    },
    activatedBy: {
        type: String,
        default: null,
    },
    activatedAt: {
        type: Date,
        default: null,
    },
    previousModelVersion: {
        type: String,
        default: null,
    },
    newModelVersion: {
        type: String,
        default: null,
    },
    rejectionReason: {
        type: String,
        default: null,
    },
}, {
    timestamps: true,
});

export const ModelCalibration = mongoose.models.ModelCalibration || mongoose.model('ModelCalibration', ModelCalibrationSchema);
