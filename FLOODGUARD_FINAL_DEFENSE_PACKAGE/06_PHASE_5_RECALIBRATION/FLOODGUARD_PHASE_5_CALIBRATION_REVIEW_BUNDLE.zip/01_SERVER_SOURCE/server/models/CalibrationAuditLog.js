import mongoose from 'mongoose';

const CalibrationAuditLogSchema = new mongoose.Schema({
    action: {
        type: String,
        required: true,
        enum: ['UPLOAD', 'RUN', 'APPROVE', 'REJECT', 'ACTIVATE', 'ROLLBACK'],
        index: true,
    },
    stationId: {
        type: String,
        required: true,
        index: true,
    },
    calibrationId: {
        type: String,
        default: null,
        index: true,
    },
    actorUserId: {
        type: String,
        required: true,
    },
    actorRole: {
        type: String,
        default: 'super_admin',
    },
    fromVersion: {
        type: String,
        default: null,
    },
    toVersion: {
        type: String,
        default: null,
    },
    reason: {
        type: String,
        default: null,
    },
    metadata: {
        type: mongoose.Schema.Types.Mixed,
        default: {},
    },
    timestamp: {
        type: Date,
        default: Date.now,
        index: true,
    },
}, {
    timestamps: true,
});

export const CalibrationAuditLog = mongoose.models.CalibrationAuditLog || mongoose.model('CalibrationAuditLog', CalibrationAuditLogSchema);
