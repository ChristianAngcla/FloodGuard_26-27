/**
 * FloodGuard Protected Calibration History Registry & Cryptographic Verification
 * 
 * Manages the immutable baseline historical datasets (2016-01-01 to 2023-12-31)
 * used for yearly in-system recalibrations.
 * 
 * Enforces cryptographic SHA-256 verification on load: any alteration fails closed immediately.
 */

import fs from 'fs';
import path from 'path';
import crypto from 'crypto';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

export const PROTECTED_HISTORY_REGISTRY = {
    sto_nino: {
        stationId: 'sto_nino',
        stationName: 'Sto. Niño Monitoring Station',
        filename: 'sto_nino_protected_history.csv',
        relativePath: '../data/calibration_history/sto_nino_protected_history.csv',
        sha256: '187867e762744f871279d4bad2da9fc1f1c7ff76cbc2fe65ea4cb41ed2be6de5',
        startDate: '2016-01-01',
        endDate: '2023-12-31',
        rowCount: 2922,
    },
    nangka: {
        stationId: 'nangka',
        stationName: 'Nangka River Monitoring Station',
        filename: 'nangka_protected_history.csv',
        relativePath: '../data/calibration_history/nangka_protected_history.csv',
        sha256: '678ef76f8f447fed3500fe379aedfa087157dbadc9da62311bf3f95ade6137c7',
        startDate: '2016-01-01',
        endDate: '2023-12-31',
        rowCount: 2922,
    },
    tumana: {
        stationId: 'tumana',
        stationName: 'Tumana Bridge Monitoring Station',
        filename: 'tumana_protected_history.csv',
        relativePath: '../data/calibration_history/tumana_protected_history.csv',
        sha256: 'b8984cd500c285a6201c07315b7a5a6ad9c08f31fb06d6bc37f5510dbfa02473',
        startDate: '2016-01-01',
        endDate: '2023-12-31',
        rowCount: 2922,
    },
};

/**
 * Loads and cryptographically verifies the protected historical dataset for a station.
 * Fails closed if the file is missing or if its SHA-256 checksum does not match.
 * 
 * @param {string} stationId - 'sto_nino', 'nangka', or 'tumana'.
 * @returns {Object} { stationId, metadata, rows }
 */
export function loadProtectedHistory(stationId) {
    const entry = PROTECTED_HISTORY_REGISTRY[stationId];
    if (!entry) {
        throw new Error(`Invalid stationId for protected history: ${stationId}`);
    }

    const fullPath = path.resolve(__dirname, entry.relativePath);
    if (!fs.existsSync(fullPath)) {
        throw new Error(`Protected historical dataset missing for ${stationId}: ${entry.filename}`);
    }

    const fileContent = fs.readFileSync(fullPath, 'utf8');
    const computedHash = crypto.createHash('sha256').update(fileContent, 'utf8').digest('hex');

    if (computedHash !== entry.sha256) {
        throw new Error(
            `Protected historical dataset integrity verification failed for ${stationId}! ` +
            `Expected SHA-256: ${entry.sha256}, computed: ${computedHash}`
        );
    }

    const lines = fileContent.trim().split(/\r?\n/);
    const headers = lines[0].split(',').map(h => h.trim().replace(/^["']|["']$/g, ''));
    const rows = [];

    for (let i = 1; i < lines.length; i++) {
        const line = lines[i].trim();
        if (!line) continue;
        const vals = line.split(',').map(v => v.trim().replace(/^["']|["']$/g, ''));
        const obj = {};
        headers.forEach((h, idx) => {
            obj[h] = vals[idx] !== undefined && vals[idx] !== '' ? vals[idx] : null;
        });
        rows.push(obj);
    }

    return {
        stationId,
        metadata: entry,
        rows,
    };
}
