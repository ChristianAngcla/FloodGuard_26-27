/**
 * FloodGuard Certified Station Model Registry
 * 
 * Source Authority:
 *   FLOODGUARD_FINAL_CANONICAL_EVIDENCE_R1_1_DOCUMENTATION_REPAIRED.zip
 *   SHA-256: f66867e643e5552ad811ccd2add0468c30c6e4bc2e82bdd9450a66286577975b
 * 
 * Rules:
 * - Single source of truth for the 3 frozen station OLS/MLR equations.
 * - Pure deterministic evaluation; no Ridge, Lasso, AI, or black-box logic.
 * - Missing remote rainfall triggers True Persistence fallback (prediction = lag1 WL).
 * - Missing required in-situ water-level lags return unavailable (null).
 */

export const STATION_MODEL_REGISTRY = {
    sto_nino: {
        stationId: 'sto_nino',
        stationName: 'Sto. Niño Water Level Monitoring Station',
        riverBasin: 'Lower Marikina Mainstem',
        selectedCandidate: 'Candidate 9',
        candidateDescription: 'AR2 + Boso-Boso_t_1',
        modelVersion: '2.0.0-CERTIFIED',
        targetVariable: 'Sto_Nino_WL_max',
        targetSemantics: 'Daily Maximum Water Level (meters above local datum)',
        unit: 'm',
        requiredLags: {
            waterLevel: [1, 3],
            rainfall: [1],
        },
        dependencyGauges: {
            inSituWaterLevel: 'Sto. Niño (DOST-PAGASA FFWS)',
            rainfall: 'Mt. Boso-Boso (MMDA / DOST-PAGASA FFWS)',
        },
        coefficients: {
            intercept: 3.5458516105979454,
            Sto_t_1: 0.464199760356257,
            Sto_t_3: 0.24569344143377558,
            BosoBoso_t_1: 0.011525049019977172,
        },
        thresholds: {
            alert: 15.00,
            alarm: 16.00,
            critical: 17.00,
        },
        thresholdMappingAllowed: true,
        evaluate: (inputs) => {
            const { sto_t_1, sto_t_3, bosoboso_t_1 } = inputs || {};
            const inputsUsed = {};
            const missingInputs = [];

            const hasSto1 = Number.isFinite(sto_t_1) && sto_t_1 !== null;
            const hasSto3 = Number.isFinite(sto_t_3) && sto_t_3 !== null;
            const hasRain = Number.isFinite(bosoboso_t_1) && bosoboso_t_1 !== null;

            if (hasSto1) inputsUsed.Sto_t_1 = sto_t_1;
            else missingInputs.push('Sto_t_1');

            if (hasSto3) inputsUsed.Sto_t_3 = sto_t_3;
            else missingInputs.push('Sto_t_3');

            if (hasRain) inputsUsed.BosoBoso_t_1 = bosoboso_t_1;
            else missingInputs.push('BosoBoso_t_1');

            // 1. If in-situ water level lag(s) missing -> unavailable
            if (!hasSto1 || !hasSto3) {
                return {
                    predictedWaterLevel: null,
                    calculationMode: 'unavailable',
                    fallbackReason: `Missing required in-situ water level lag inputs: ${missingInputs.filter(k => k.startsWith('Sto')).join(', ')}`,
                    inputsUsed,
                    missingInputs,
                };
            }

            // 2. If rainfall missing but in-situ water level available -> true persistence fallback
            if (!hasRain) {
                return {
                    predictedWaterLevel: parseFloat(sto_t_1.toFixed(2)),
                    calculationMode: 'persistence_fallback',
                    fallbackReason: 'Missing Mt. Boso-Boso rainfall telemetry; falling back to lag-1 water level persistence.',
                    inputsUsed,
                    missingInputs,
                };
            }

            // 3. Primary Model (Candidate 9)
            const c = STATION_MODEL_REGISTRY.sto_nino.coefficients;
            const rawPrediction = c.intercept + (c.Sto_t_1 * sto_t_1) + (c.Sto_t_3 * sto_t_3) + (c.BosoBoso_t_1 * bosoboso_t_1);

            return {
                predictedWaterLevel: parseFloat(rawPrediction.toFixed(2)),
                calculationMode: 'primary_model',
                fallbackReason: null,
                inputsUsed,
                missingInputs: [],
            };
        },
    },

    nangka: {
        stationId: 'nangka',
        stationName: 'Nangka River Monitoring Station',
        riverBasin: 'Nangka Tributary',
        selectedCandidate: 'Candidate 4',
        candidateDescription: 'AR1 + Boso-Boso_t_1',
        modelVersion: '2.0.0-CERTIFIED',
        targetVariable: 'Nangka_WL_max',
        targetSemantics: 'Daily Maximum Water Level (meters above local datum)',
        unit: 'm',
        requiredLags: {
            waterLevel: [1],
            rainfall: [1],
        },
        dependencyGauges: {
            inSituWaterLevel: 'Nangka (DOST-PAGASA FFWS)',
            rainfall: 'Mt. Boso-Boso (MMDA / DOST-PAGASA FFWS)',
        },
        coefficients: {
            intercept: 8.114816713807127,
            nangka_wl_t_1: 0.489768812135568,
            bosoboso_rain_t_1: 0.009737494825196964,
        },
        thresholds: {
            alert: 16.50,
            alarm: 17.10,
            critical: 17.70,
        },
        thresholdMappingAllowed: true,
        evaluate: (inputs) => {
            const { nangka_wl_t_1, bosoboso_t_1 } = inputs || {};
            const inputsUsed = {};
            const missingInputs = [];

            const hasNangka1 = Number.isFinite(nangka_wl_t_1) && nangka_wl_t_1 !== null;
            const hasRain = Number.isFinite(bosoboso_t_1) && bosoboso_t_1 !== null;

            if (hasNangka1) inputsUsed.Nangka_WL_t_1 = nangka_wl_t_1;
            else missingInputs.push('Nangka_WL_t_1');

            if (hasRain) inputsUsed.BosoBoso_t_1 = bosoboso_t_1;
            else missingInputs.push('BosoBoso_t_1');

            // 1. If in-situ water level lag missing -> unavailable
            if (!hasNangka1) {
                return {
                    predictedWaterLevel: null,
                    calculationMode: 'unavailable',
                    fallbackReason: 'Missing required in-situ water level lag input: Nangka_WL_t_1',
                    inputsUsed,
                    missingInputs,
                };
            }

            // 2. If rainfall missing but in-situ water level available -> true persistence fallback
            if (!hasRain) {
                return {
                    predictedWaterLevel: parseFloat(nangka_wl_t_1.toFixed(2)),
                    calculationMode: 'persistence_fallback',
                    fallbackReason: 'Missing Mt. Boso-Boso rainfall telemetry; falling back to lag-1 water level persistence.',
                    inputsUsed,
                    missingInputs,
                };
            }

            // 3. Primary Model (Candidate 4)
            const c = STATION_MODEL_REGISTRY.nangka.coefficients;
            const rawPrediction = c.intercept + (c.nangka_wl_t_1 * nangka_wl_t_1) + (c.bosoboso_rain_t_1 * bosoboso_t_1);

            return {
                predictedWaterLevel: parseFloat(rawPrediction.toFixed(2)),
                calculationMode: 'primary_model',
                fallbackReason: null,
                inputsUsed,
                missingInputs: [],
            };
        },
    },

    tumana: {
        stationId: 'tumana',
        stationName: 'Tumana Bridge Monitoring Station',
        riverBasin: 'Middle Marikina Mainstem',
        selectedCandidate: 'Candidate 8',
        candidateDescription: 'AR1 + PAGASA_SG_Rain_t_1',
        modelVersion: '2.0.0-CERTIFIED',
        targetVariable: 'Tumana_WL',
        targetSemantics: 'PAGASA-reported daily Tumana water-level observation',
        unit: 'm',
        requiredLags: {
            waterLevel: [1],
            rainfall: [1],
        },
        dependencyGauges: {
            inSituWaterLevel: 'Tumana Bridge (DOST-PAGASA FFWS)',
            rainfall: 'Science Garden (DOST-PAGASA FFWS, Station Code: 11203101, Field: rfday / Daily Sum 24hr)',
        },
        coefficients: {
            intercept: 1.5147240224821763,
            tumana_wl_t_1: 0.8735442115350864,
            pagasa_sg_rain_t_1: 0.008481630145296813,
        },
        thresholds: null,
        thresholdMappingAllowed: false,
        evaluate: (inputs) => {
            const { tumana_wl_t_1, pagasa_sg_rain_t_1 } = inputs || {};
            const inputsUsed = {};
            const missingInputs = [];

            const hasTumana1 = Number.isFinite(tumana_wl_t_1) && tumana_wl_t_1 !== null;
            const hasSgRain = Number.isFinite(pagasa_sg_rain_t_1) && pagasa_sg_rain_t_1 !== null;

            if (hasTumana1) inputsUsed.Tumana_WL_t_1 = tumana_wl_t_1;
            else missingInputs.push('Tumana_WL_t_1');

            if (hasSgRain) inputsUsed.PAGASA_SG_Rain_t_1 = pagasa_sg_rain_t_1;
            else missingInputs.push('PAGASA_SG_Rain_t_1');

            // 1. If in-situ water level lag missing -> unavailable
            if (!hasTumana1) {
                return {
                    predictedWaterLevel: null,
                    calculationMode: 'unavailable',
                    fallbackReason: 'Missing required in-situ water level lag input: Tumana_WL_t_1',
                    inputsUsed,
                    missingInputs,
                };
            }

            // 2. If Science Garden rainfall missing but in-situ water level available -> true persistence fallback
            if (!hasSgRain) {
                return {
                    predictedWaterLevel: parseFloat(tumana_wl_t_1.toFixed(2)),
                    calculationMode: 'persistence_fallback',
                    fallbackReason: 'Missing Science Garden daily rainfall telemetry; falling back to lag-1 water level persistence.',
                    inputsUsed,
                    missingInputs,
                };
            }

            // 3. Primary Model (Candidate 8)
            const c = STATION_MODEL_REGISTRY.tumana.coefficients;
            const rawPrediction = c.intercept + (c.tumana_wl_t_1 * tumana_wl_t_1) + (c.pagasa_sg_rain_t_1 * pagasa_sg_rain_t_1);

            return {
                predictedWaterLevel: parseFloat(rawPrediction.toFixed(2)),
                calculationMode: 'primary_model',
                fallbackReason: null,
                inputsUsed,
                missingInputs: [],
            };
        },
    },
};
