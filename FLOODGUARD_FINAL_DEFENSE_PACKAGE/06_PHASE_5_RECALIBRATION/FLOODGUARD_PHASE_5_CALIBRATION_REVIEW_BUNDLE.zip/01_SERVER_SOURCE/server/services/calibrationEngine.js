/**
 * FloodGuard Controlled Calibration & Statistical Governance Engine (Phase 5 Final Production-Path)
 * 
 * Implements:
 * 1. Raw Daily Historical Merge & Lag Reconstruction:
 *    - Rebuilds exact calendar lags (t-1 = Date-1d, t-3 = Date-3d) from raw daily time-series.
 *    - Precomputed lag columns in historical archives are ignored for yearly production recalibration.
 *    - Validates presence of required raw columns: Date, In-situ/Target, Rain.
 *    - Rejects malformed non-numeric strings ('abc', 'invalid') in measurement cells.
 * 2. Canonical Internal Raw Normalization (normalizeRawDailyRow):
 *    - Every raw row — regardless of source (protected CSV, prior accepted snapshot, new upload) — is
 *      independently normalized to the internal canonical schema { Date, waterLevel, rainfall }.
 *    - Alias resolution is performed per-row; different source files may legitimately use different
 *      accepted header aliases without causing silent data loss.
 *    - Normalization occurs BEFORE: dynamic cutoff computation, merge, chronological sort, and lag rebuilding.
 *    - The protected history CSV files are never modified; normalization is strictly in-memory.
 * 3. Cumulative Accepted History Across Multiple Recalibration Years:
 *    - Combines static 2016–2023 protected baseline + prior DEPLOYED/SUPERSEDED yearly snapshots + current upload.
 *    - Dynamic historical cutoff prevents overlap across any previously accepted calendar year.
 * 4. Two-Stage Statistical Architecture:
 *    - Stage A (Evaluation): Chronological train/val split for out-of-sample skill & persistence benchmarks.
 *    - Stage B (Final Refit): 100% complete-case refit on all combined historical evidence for activatable production coefficients.
 * 5. Pure Ordinary Least Squares (OLS) Solver: beta = (X'X)^-1 X'y (no Ridge, Lasso, or regularization).
 * 6. HC3 Heteroskedasticity-Consistent Covariance Inference (standard errors, t, p-values only; does NOT alter predictions).
 * 7. Variance Inflation Factor (VIF) Diagnostics (max VIF <= 5.0 gate).
 * 8. Complete-Case Rule & Exact Calendar Arithmetic (missing stays null; no zero-fill, no forward-fill, no interpolation).
 * 9. Strict Verification of New-Year Contribution: requires newYearEffectiveRowCount > 0.
 * 
 * Certified Structural Locks:
 * - sto_nino : Candidate 9 structure (Sto_t_1, Sto_t_3, BosoBoso_t_1)
 * - nangka   : Candidate 4 structure (nangka_wl_t_1, bosoboso_rain_t_1)
 * - tumana   : Candidate 8 structure (tumana_wl_t_1, pagasa_sg_rain_t_1, strictly unmapped)
 *
 * Canonical Internal Raw Schema (post-normalization):
 *   { Date: 'YYYY-MM-DD', waterLevel: number | null, rainfall: number | null }
 */

import crypto from 'crypto';
import { loadProtectedHistory, PROTECTED_HISTORY_REGISTRY } from '../config/protectedHistoryRegistry.js';

// ── Certified Candidate Specifications ───────────────────────────

export const CALIBRATION_SPECIFICATIONS = {
    sto_nino: {
        stationId: 'sto_nino',
        stationName: 'Sto. Niño Monitoring Station',
        candidateId: 'Candidate 9',
        candidateDescription: 'AR2 + Boso-Boso_t_1 (Sto_t_1, Sto_t_3, BosoBoso_t_1)',
        targetVariable: 'Sto_Nino_WL_max',
        targetSemantics: 'Daily Maximum Water Level (meters above local datum)',
        unit: 'm',
        thresholdMappingAllowed: true,
        thresholds: { alert: 15.00, alarm: 16.00, critical: 17.00 },
        requiredPredictorKeys: ['Sto_t_1', 'Sto_t_3', 'BosoBoso_t_1'],
        coefficientKeys: ['intercept', 'Sto_t_1', 'Sto_t_3', 'BosoBoso_t_1'],
        canonicalBaselineCoefficients: {
            intercept: 3.5458516105979454,
            Sto_t_1: 0.464199760356257,
            Sto_t_3: 0.24569344143377558,
            BosoBoso_t_1: 0.011525049019977172,
        },
        rawColumnMapping: {
            date: ['Date', 'date', 'timestamp', 'Timestamp'],
            target: ['Sto', 'Sto_Nino_WL_max', 'Sto_Nino_WL', 'Target_Y', 'water_level'],
            inSitu: ['Sto', 'Sto_Nino_WL_max', 'Sto_Nino_WL', 'Sto_WL'],
            rain: ['BosoBoso', 'Mt_BosoBoso', 'Mt_Bosoboso', 'BosoBoso_Rain', 'bosoboso_rfday'],
        },
        lagColumnMapping: {
            Sto_t_1: ['Sto_t_1', 'sto_t_1', 'Sto_WL_t_1', 'Sto_Nino_WL_t_1'],
            Sto_t_3: ['Sto_t_3', 'sto_t_3', 'Sto_WL_t_3', 'Sto_Nino_WL_t_3'],
            BosoBoso_t_1: ['BosoBoso_t_1', 'bosoboso_t_1', 'Mt_BosoBoso_t_1', 'Mt_Bosoboso_t_1', 'bosoboso_rain_t_1', 'BosoBoso_Rain_t_1'],
        },
    },

    nangka: {
        stationId: 'nangka',
        stationName: 'Nangka River Monitoring Station',
        candidateId: 'Candidate 4',
        candidateDescription: 'AR1 + Boso-Boso_t_1 (nangka_wl_t_1, bosoboso_rain_t_1)',
        targetVariable: 'Nangka_WL_max',
        targetSemantics: 'Daily Maximum Water Level (meters above local datum)',
        unit: 'm',
        thresholdMappingAllowed: true,
        thresholds: { alert: 16.50, alarm: 17.10, critical: 17.70 },
        requiredPredictorKeys: ['nangka_wl_t_1', 'bosoboso_rain_t_1'],
        coefficientKeys: ['intercept', 'nangka_wl_t_1', 'bosoboso_rain_t_1'],
        canonicalBaselineCoefficients: {
            intercept: 8.114816713807127,
            nangka_wl_t_1: 0.489768812135568,
            bosoboso_rain_t_1: 0.009737494825196964,
        },
        rawColumnMapping: {
            date: ['Date', 'date', 'timestamp', 'Timestamp'],
            target: ['Nangka_WL_max', 'Nangka_WL', 'NangkaWL', 'Nangka', 'Target_Y'],
            inSitu: ['Nangka_WL_max', 'Nangka_WL', 'NangkaWL', 'Nangka'],
            rain: ['Mt_BosoBoso', 'Mt_Bosoboso', 'BosoBoso', 'BosoBoso_Rain', 'bosoboso_rfday'],
        },
        lagColumnMapping: {
            nangka_wl_t_1: ['Nangka_WL_t_1', 'nangka_wl_t_1', 'NangkaWL_t_1', 'Nangka_t_1'],
            bosoboso_rain_t_1: ['BosoBoso_t_1', 'bosoboso_rain_t_1', 'bosoboso_t_1', 'Mt_BosoBoso_t_1', 'Mt_Bosoboso_t_1', 'BosoBoso_Rain_t_1'],
        },
    },

    tumana: {
        stationId: 'tumana',
        stationName: 'Tumana Bridge Monitoring Station',
        candidateId: 'Candidate 8',
        candidateDescription: 'AR1 + PAGASA_SG_Rain_t_1 (tumana_wl_t_1, pagasa_sg_rain_t_1)',
        targetVariable: 'Tumana_WL',
        targetSemantics: 'PAGASA-reported daily Tumana water-level observation',
        unit: 'm',
        thresholdMappingAllowed: false,
        thresholds: null,
        requiredPredictorKeys: ['tumana_wl_t_1', 'pagasa_sg_rain_t_1'],
        coefficientKeys: ['intercept', 'tumana_wl_t_1', 'pagasa_sg_rain_t_1'],
        canonicalBaselineCoefficients: {
            intercept: 1.5147240224821763,
            tumana_wl_t_1: 0.8735442115350864,
            pagasa_sg_rain_t_1: 0.008481630145296813,
        },
        rawColumnMapping: {
            date: ['Date', 'date', 'timestamp', 'Timestamp'],
            target: ['Tumana_WL', 'Tumana', 'tumana_wl', 'Target_Y'],
            inSitu: ['Tumana_WL', 'Tumana', 'tumana_wl'],
            rain: ['PAGASA_SG_Rain', 'ScienceGarden', 'Science_Garden', 'ScienceGarden_Rain', 'pagasa_sg_rain', 'rfday'],
        },
        lagColumnMapping: {
            tumana_wl_t_1: ['Tumana_WL_t_1', 'tumana_wl_t_1', 'Tumana_t_1'],
            pagasa_sg_rain_t_1: ['PAGASA_SG_Rain_t_1', 'pagasa_sg_rain_t_1', 'ScienceGarden_t_1', 'Science_Garden_t_1', 'PAGASA_SG_Rain'],
        },
    },
};

// ── Canonical Internal Raw Normalization ─────────────────────────

/**
 * Normalizes a single raw daily row from any accepted external column alias
 * to the canonical internal raw schema: { Date, waterLevel, rainfall }.
 *
 * Alias resolution is performed per-row so that rows from different source
 * files (protected CSV, prior accepted snapshot, current upload) may each use
 * different accepted header names without causing silent data loss.
 *
 * Rules:
 *   - Date is resolved from the first PRESENT accepted date alias.
 *   - waterLevel and rainfall are resolved likewise; absent → null.
 *   - Blank / empty string cells are treated as null.
 *   - Real numeric 0 / "0" / "0.0" → 0 (not null).
 *   - If the row is already in the canonical schema ({ Date, waterLevel, rainfall })
 *     it is returned as-is (idempotent).
 *
 * @param {string} stationId - 'sto_nino', 'nangka', 'tumana'
 * @param {Object} row       - A raw daily row object with any accepted alias headers.
 * @returns {{ Date: string, waterLevel: number|null, rainfall: number|null }}
 */
export function normalizeRawDailyRow(stationId, row) {
    const spec = CALIBRATION_SPECIFICATIONS[stationId];
    if (!spec) throw new Error(`normalizeRawDailyRow: Unknown stationId: ${stationId}`);

    const keys = Object.keys(row);

    // Idempotency guard: if the row is already in the canonical internal schema
    // { Date, waterLevel, rainfall }, return it as-is without re-resolving aliases.
    // This ensures preprocessCalibrationData is safe to call on rows that have already
    // been normalized by mergeProtectedHistoryWithYearlyData.
    if (keys.includes('waterLevel') && keys.includes('rainfall') && keys.includes('Date')) {
        return {
            Date: row.Date,
            waterLevel: row.waterLevel,
            rainfall: row.rainfall,
        };
    }

    // Helper: resolve a numeric value from the first present alias; returns null when absent/blank.
    const resolveNum = (aliases) => {
        for (const alias of aliases) {
            if (keys.includes(alias)) {
                const v = row[alias];
                if (v === null || v === undefined) return null;
                const s = String(v).trim();
                if (s === '') return null;
                const n = Number(s);
                return Number.isFinite(n) ? n : null;
            }
        }
        return null;
    };

    // Resolve date: strip time portion if present.
    let dateStr = null;
    for (const alias of spec.rawColumnMapping.date) {
        if (keys.includes(alias)) {
            const v = row[alias];
            if (v !== null && v !== undefined) {
                dateStr = String(v).trim().split('T')[0].split(' ')[0];
            }
            break;
        }
    }

    // Resolve water level (inSitu aliases cover the same column as target for all stations).
    const waterLevel = resolveNum(
        spec.rawColumnMapping.inSitu.length
            ? spec.rawColumnMapping.inSitu
            : spec.rawColumnMapping.target
    );

    // Resolve rainfall.
    const rainfall = resolveNum(spec.rawColumnMapping.rain);

    return { Date: dateStr, waterLevel, rainfall };
}


// ── Date Validation & Strict Chronological Merging ───────────────

/**
 * Validates whether a string is a real calendar date in YYYY-MM-DD format.
 */
export function isValidCalendarDate(dateStr) {
    if (typeof dateStr !== 'string' || !/^\d{4}-\d{2}-\d{2}$/.test(dateStr)) {
        return false;
    }
    const [y, m, d] = dateStr.split('-').map(Number);
    if (y < 1900 || y > 2100 || m < 1 || m > 12 || d < 1) {
        return false;
    }
    const daysInMonth = new Date(Date.UTC(y, m, 0)).getUTCDate();
    return d <= daysInMonth;
}

/**
 * Validates uploaded yearly rows against strict integrity & raw schema rules:
 * - Presence of required raw columns: Date, In-situ/Target, and Rain
 * - Valid calendar dates (no non-existent dates like 2026-02-31 or 2024-02-30)
 * - No duplicate dates inside upload
 * - No overlap with latest accepted historical cutoff date
 * - No future dates relative to current PST date
 * - Rejection of malformed non-numeric strings ('abc', 'invalid', 'unknown') in measurement cells
 * 
 * @param {string} stationId - 'sto_nino', 'nangka', 'tumana'
 * @param {Array<Object>} uploadedRows - Array of row objects from CSV/XLSX
 * @param {string} latestAcceptedDate - Max date of previously accepted history (e.g. '2023-12-31')
 * @returns {Object} { isValid, dates, rowCount }
 */
export function validateYearlyUploadedRows(stationId, uploadedRows, latestAcceptedDate = '2023-12-31') {
    const spec = CALIBRATION_SPECIFICATIONS[stationId];
    if (!spec) throw new Error(`Unknown stationId: ${stationId}`);

    if (!Array.isArray(uploadedRows) || uploadedRows.length === 0) {
        throw new Error('Uploaded dataset is empty or invalid.');
    }

    const firstRow = uploadedRows[0];
    const keys = Object.keys(firstRow);

    // 1. Verify Raw Schema Columns
    const dateCol = spec.rawColumnMapping.date.find(c => keys.includes(c));
    const targetCol = spec.rawColumnMapping.target.find(c => keys.includes(c)) || spec.rawColumnMapping.inSitu.find(c => keys.includes(c));
    const rainCol = spec.rawColumnMapping.rain.find(c => keys.includes(c));

    if (!dateCol) {
        throw new Error(`Missing required Date column in uploaded dataset. Found columns: ${keys.join(', ')}`);
    }
    if (!targetCol) {
        throw new Error(`Missing required target water level column for ${stationId}. Expected one of: ${spec.rawColumnMapping.target.join(', ')}`);
    }
    if (!rainCol) {
        throw new Error(`Missing required rainfall column for ${stationId}. Expected one of: ${spec.rawColumnMapping.rain.join(', ')}`);
    }

    // Determine current PST date
    const nowPst = new Date(Date.now() + 8 * 3600 * 1000).toISOString().split('T')[0];

    const seenDates = new Set();
    const validatedDates = [];

    for (let i = 0; i < uploadedRows.length; i++) {
        const row = uploadedRows[i];
        const rawDate = String(row[dateCol] || '').trim().split('T')[0].split(' ')[0];

        if (!isValidCalendarDate(rawDate)) {
            throw new Error(`Row ${i + 1}: Invalid calendar date format or non-existent date '${row[dateCol]}'. Expected valid YYYY-MM-DD.`);
        }

        if (seenDates.has(rawDate)) {
            throw new Error(`Duplicate date '${rawDate}' detected in uploaded dataset at row ${i + 1}. Duplicates are strictly rejected.`);
        }

        if (latestAcceptedDate && rawDate <= latestAcceptedDate) {
            throw new Error(`Date overlap violation: Uploaded date '${rawDate}' overlaps previously accepted historical baseline (<= ${latestAcceptedDate}). Overwriting historical data is strictly prohibited.`);
        }

        if (rawDate > nowPst) {
            throw new Error(`Future date violation: Uploaded date '${rawDate}' is in the future relative to current date (${nowPst}). Future observations cannot be calibrated.`);
        }

        // Validate measurement cell data types: non-null values must be strictly numeric
        for (const col of [targetCol, rainCol]) {
            const val = row[col];
            if (val !== null && val !== undefined && String(val).trim() !== '') {
                const strVal = String(val).trim();
                if (isNaN(Number(strVal)) || /[a-zA-Z]/.test(strVal)) {
                    throw new Error(`Row ${i + 1}: Malformed non-numeric value '${val}' in column '${col}'. Non-numeric text cannot be parsed.`);
                }
            }
        }

        seenDates.add(rawDate);
        validatedDates.push(rawDate);
    }

    return {
        isValid: true,
        dates: validatedDates,
        rowCount: uploadedRows.length,
    };
}

/**
 * Merges protected historical baseline, prior accepted yearly snapshots, and new yearly data.
 * 
 * Normalization happens FIRST for all three sources independently so that heterogeneous
 * external column aliases (e.g. 'Date' vs 'date' vs 'timestamp', 'Sto' vs 'Sto_Nino_WL')
 * never cause rows to be silently dropped during cutoff computation, validation, or sorting.
 * 
 * @param {string} stationId - 'sto_nino', 'nangka', 'tumana'
 * @param {Array<Object>} protectedRows - Cryptographically verified baseline rows (2016–2023)
 * @param {Array<Object>} uploadedRows - Current new yearly upload rows (any accepted alias headers)
 * @param {Array<Object>} [priorAcceptedRows=[]] - Prior DEPLOYED/SUPERSEDED calibration snapshots (any accepted alias headers)
 * @returns {Array<{ Date: string, waterLevel: number|null, rainfall: number|null }>} Normalized, chronologically sorted combined rows
 */
export function mergeProtectedHistoryWithYearlyData(stationId, protectedRows, uploadedRows, priorAcceptedRows = []) {
    const spec = CALIBRATION_SPECIFICATIONS[stationId];
    if (!spec) throw new Error(`Unknown stationId: ${stationId}`);

    // Step 1: Normalize ALL three sources independently, per-row.
    //         Each row is resolved through the accepted alias table regardless of which header
    //         the source file used.
    const normProtected = protectedRows.map(r => normalizeRawDailyRow(stationId, r));
    const normPrior = priorAcceptedRows.map(r => normalizeRawDailyRow(stationId, r));
    const normUploaded = uploadedRows.map(r => normalizeRawDailyRow(stationId, r));

    // Step 2: Determine dynamic latest accepted date from normalized dates only.
    //         This is entirely alias-independent — always uses row.Date.
    let latestAcceptedDate = PROTECTED_HISTORY_REGISTRY[stationId]?.endDate || '2023-12-31';
    for (const r of normPrior) {
        const d = r.Date;
        if (d && d > latestAcceptedDate) {
            latestAcceptedDate = d;
        }
    }

    // Step 3: Validate uploaded rows against latest accepted date using pre-normalization raw rows
    //         (validateYearlyUploadedRows needs the original aliased headers to detect schema issues).
    validateYearlyUploadedRows(stationId, uploadedRows, latestAcceptedDate);

    // Step 4: Combine normalized rows: Protected baseline + Prior accepted years + New upload.
    const combined = [...normProtected, ...normPrior, ...normUploaded];

    // Step 5: Sort strictly by canonical Date field ascending.
    combined.sort((a, b) => {
        const da = a.Date || '';
        const db = b.Date || '';
        return da.localeCompare(db);
    });

    return combined;
}


// ── Pure Matrix Linear Algebra Helpers ───────────────────────────

export function matMul(A, B) {
    const n = A.length;
    const m = A[0].length;
    const p = B[0].length;
    const res = Array.from({ length: n }, () => new Float64Array(p));
    for (let i = 0; i < n; i++) {
        for (let k = 0; k < m; k++) {
            const aik = A[i][k];
            for (let j = 0; j < p; j++) {
                res[i][j] += aik * B[k][j];
            }
        }
    }
    return res;
}

export function matTranspose(A) {
    const n = A.length;
    const m = A[0].length;
    const res = Array.from({ length: m }, () => new Float64Array(n));
    for (let i = 0; i < n; i++) {
        for (let j = 0; j < m; j++) {
            res[j][i] = A[i][j];
        }
    }
    return res;
}

export function matInvert(A) {
    const p = A.length;
    const aug = Array.from({ length: p }, (_, i) => {
        const row = new Float64Array(2 * p);
        for (let j = 0; j < p; j++) row[j] = A[i][j];
        row[p + i] = 1.0;
        return row;
    });

    for (let i = 0; i < p; i++) {
        let maxRow = i;
        let maxVal = Math.abs(aug[i][i]);
        for (let r = i + 1; r < p; r++) {
            const val = Math.abs(aug[r][i]);
            if (val > maxVal) {
                maxVal = val;
                maxRow = r;
            }
        }

        if (maxVal < 1e-12) {
            throw new Error(`Singular or rank-deficient design matrix (pivot=${maxVal} at col ${i}).`);
        }

        if (maxRow !== i) {
            const temp = aug[i];
            aug[i] = aug[maxRow];
            aug[maxRow] = temp;
        }

        const pivot = aug[i][i];
        for (let j = 0; j < 2 * p; j++) {
            aug[i][j] /= pivot;
        }

        for (let r = 0; r < p; r++) {
            if (r !== i) {
                const factor = aug[r][i];
                for (let j = 0; j < 2 * p; j++) {
                    aug[r][j] -= factor * aug[i][j];
                }
            }
        }
    }

    const inv = Array.from({ length: p }, (_, i) => {
        const row = new Float64Array(p);
        for (let j = 0; j < p; j++) row[j] = aug[i][p + j];
        return row;
    });

    return inv;
}

// ── Statistical Distribution Functions ───────────────────────────

function logGamma(z) {
    const c = [
        0.99999999999980993,
        676.5203681218851,
        -1259.1392167224028,
        771.32342877765313,
        -176.61502916214059,
        12.507343278686905,
        -0.138571095856205,
        9.9843695780195716e-6,
        1.5056327351493116e-7
    ];
    if (z < 0.5) {
        return Math.log(Math.PI / Math.sin(Math.PI * z)) - logGamma(1 - z);
    }
    z -= 1;
    let x = c[0];
    for (let i = 1; i < 9; i++) {
        x += c[i] / (z + i);
    }
    const t = z + 7.5;
    return 0.5 * Math.log(2 * Math.PI) + (z + 0.5) * Math.log(t) - t + Math.log(x);
}

function incBeta(x, a, b) {
    if (x <= 0) return 0;
    if (x >= 1) return 1;

    const bt = Math.exp(logGamma(a + b) - logGamma(a) - logGamma(b) + a * Math.log(x) + b * Math.log(1 - x));

    if (x < (a + 1) / (a + b + 2)) {
        return bt * betacf(x, a, b) / a;
    } else {
        return 1.0 - (bt * betacf(1 - x, b, a) / b);
    }
}

function betacf(x, a, b) {
    const maxIt = 100;
    const eps = 3e-14;
    const qab = a + b;
    const qap = a + 1;
    const qam = a - 1;
    let c = 1.0;
    let d = 1.0 - qab * x / qap;
    if (Math.abs(d) < 1e-30) d = 1e-30;
    d = 1.0 / d;
    let h = d;

    for (let m = 1; m <= maxIt; m++) {
        const m2 = 2 * m;
        let aa = m * (b - m) * x / ((qam + m2) * (a + m2));
        d = 1.0 + aa * d;
        if (Math.abs(d) < 1e-30) d = 1e-30;
        c = 1.0 + aa / c;
        if (Math.abs(c) < 1e-30) c = 1e-30;
        d = 1.0 / d;
        h *= d * c;

        aa = -(a + m) * (qab + m) * x / ((a + m2) * (qap + m2));
        d = 1.0 + aa * d;
        if (Math.abs(d) < 1e-30) d = 1e-30;
        c = 1.0 + aa / c;
        if (Math.abs(c) < 1e-30) c = 1e-30;
        d = 1.0 / d;
        const del = d * c;
        h *= del;
        if (Math.abs(del - 1.0) < eps) break;
    }
    return h;
}

export function studentTPValue(t, df) {
    if (df <= 0 || !Number.isFinite(t)) return 1.0;
    const t2 = t * t;
    const x = df / (df + t2);
    return incBeta(x, df / 2, 0.5);
}

// ── Pure OLS, HC3, and VIF Solver ────────────────────────────────

export function fitOlsHc3(y, X, predictorNames = []) {
    const n = y.length;
    const k = X[0].length;
    const p = k + 1;

    if (n <= p) {
        throw new Error(`Insufficient observations (n=${n}) for k=${k} predictors (requires n > ${p}).`);
    }

    const Xd = Array.from({ length: n }, (_, i) => {
        const row = new Float64Array(p);
        row[0] = 1.0;
        for (let j = 0; j < k; j++) row[j + 1] = X[i][j];
        return row;
    });

    const Xt = matTranspose(Xd);
    const XtX = matMul(Xt, Xd);

    const Xty = new Float64Array(p);
    for (let j = 0; j < p; j++) {
        let sum = 0;
        for (let i = 0; i < n; i++) sum += Xd[i][j] * y[i];
        Xty[j] = sum;
    }

    const XtX_inv = matInvert(XtX);

    const beta = new Float64Array(p);
    for (let i = 0; i < p; i++) {
        let sum = 0;
        for (let j = 0; j < p; j++) sum += XtX_inv[i][j] * Xty[j];
        beta[i] = sum;
    }

    const pred = new Float64Array(n);
    const resid = new Float64Array(n);
    let sse = 0;
    let sumY = 0;
    for (let i = 0; i < n; i++) {
        let yHat = 0;
        for (let j = 0; j < p; j++) yHat += Xd[i][j] * beta[j];
        pred[i] = yHat;
        const e = y[i] - yHat;
        resid[i] = e;
        sse += e * e;
        sumY += y[i];
    }

    const meanY = sumY / n;
    let sst = 0;
    for (let i = 0; i < n; i++) {
        const dy = y[i] - meanY;
        sst += dy * dy;
    }
    const r2 = sst > 1e-12 ? 1 - (sse / sst) : 0;
    const df_e = n - p;
    const mse = sse / df_e;

    const se_ols = new Float64Array(p);
    for (let j = 0; j < p; j++) {
        se_ols[j] = Math.sqrt(Math.max(0, XtX_inv[j][j] * mse));
    }

    const leverage = new Float64Array(n);
    for (let i = 0; i < n; i++) {
        let hi = 0;
        for (let r = 0; r < p; r++) {
            let xr = Xd[i][r];
            for (let c = 0; c < p; c++) {
                hi += xr * XtX_inv[r][c] * Xd[i][c];
            }
        }
        leverage[i] = Math.min(Math.max(hi, 0), 0.9999);
    }

    const Xt_Omega_Xd = Array.from({ length: p }, () => new Float64Array(p));
    for (let i = 0; i < n; i++) {
        const om_i = (resid[i] * resid[i]) / Math.pow(1 - leverage[i], 2);
        for (let r = 0; r < p; r++) {
            const xir = Xd[i][r];
            for (let c = 0; c < p; c++) {
                Xt_Omega_Xd[r][c] += xir * om_i * Xd[i][c];
            }
        }
    }

    const temp = matMul(XtX_inv, Xt_Omega_Xd);
    const cov_hc3 = matMul(temp, XtX_inv);

    const se_hc3 = new Float64Array(p);
    const t_hc3 = new Float64Array(p);
    const p_hc3 = new Float64Array(p);

    for (let j = 0; j < p; j++) {
        const se = Math.sqrt(Math.max(0, cov_hc3[j][j]));
        se_hc3[j] = se;
        const t = se > 1e-15 ? beta[j] / se : 0;
        t_hc3[j] = t;
        p_hc3[j] = studentTPValue(t, df_e);
    }

    const vifs = new Float64Array(k);
    for (let idx = 0; idx < k; idx++) {
        if (k === 1) {
            vifs[idx] = 1.0;
            continue;
        }
        const targetX = new Float64Array(n);
        const otherX = Array.from({ length: n }, () => new Float64Array(k - 1));
        for (let i = 0; i < n; i++) {
            targetX[i] = X[i][idx];
            let colCount = 0;
            for (let c = 0; c < k; c++) {
                if (c !== idx) {
                    otherX[i][colCount] = X[i][c];
                    colCount++;
                }
            }
        }

        try {
            const subFit = fitOls(targetX, otherX);
            const r2_sub = subFit.r2;
            const vifVal = 1 - r2_sub > 1e-10 ? 1 / (1 - r2_sub) : 9999.0;
            vifs[idx] = vifVal;
        } catch {
            vifs[idx] = 9999.0;
        }
    }

    return {
        beta: Array.from(beta),
        se_ols: Array.from(se_ols),
        se_hc3: Array.from(se_hc3),
        t_hc3: Array.from(t_hc3),
        p_hc3: Array.from(p_hc3),
        vifs: Array.from(vifs),
        maxVif: Math.max(...Array.from(vifs)),
        r2,
        mse,
        n,
        k,
        df_e,
    };
}

function fitOls(y, X) {
    const n = y.length;
    const k = X[0].length;
    const p = k + 1;
    const Xd = Array.from({ length: n }, (_, i) => {
        const row = new Float64Array(p);
        row[0] = 1.0;
        for (let j = 0; j < k; j++) row[j + 1] = X[i][j];
        return row;
    });
    const Xt = matTranspose(Xd);
    const XtX = matMul(Xt, Xd);
    const Xty = new Float64Array(p);
    let sumY = 0;
    for (let i = 0; i < n; i++) {
        sumY += y[i];
        for (let j = 0; j < p; j++) Xty[j] += Xd[i][j] * y[i];
    }
    const XtX_inv = matInvert(XtX);
    const beta = new Float64Array(p);
    for (let i = 0; i < p; i++) {
        let sum = 0;
        for (let j = 0; j < p; j++) sum += XtX_inv[i][j] * Xty[j];
        beta[i] = sum;
    }
    let sse = 0;
    for (let i = 0; i < n; i++) {
        let yHat = 0;
        for (let j = 0; j < p; j++) yHat += Xd[i][j] * beta[j];
        const e = y[i] - yHat;
        sse += e * e;
    }
    const meanY = sumY / n;
    let sst = 0;
    for (let i = 0; i < n; i++) {
        const dy = y[i] - meanY;
        sst += dy * dy;
    }
    const r2 = sst > 1e-12 ? 1 - (sse / sst) : 0;
    return { beta: Array.from(beta), r2 };
}

// ── Raw Daily Preprocessor & Exact Calendar Lag Builder ───────────

/**
 * Preprocesses raw daily time-series rows into complete-case model records.
 * Rebuilds exact calendar date lags (t-1 = Date-1d, t-3 = Date-3d) from raw observations.
 *
 * Input rows may be either:
 *   (a) Already normalized { Date, waterLevel, rainfall } objects (from mergeProtectedHistoryWithYearlyData), or
 *   (b) Raw aliased objects with any accepted header names (e.g. direct fixture datasets).
 * Per-row normalization is applied in both cases, making the function alias-independent.
 *
 * @param {string} stationId - 'sto_nino', 'nangka', 'tumana'
 * @param {Array<Object>} rawRows - Array of daily row objects (any accepted alias headers or pre-normalized)
 * @param {Object} [options={}]
 * @param {boolean} [options.rebuildCalendarLags=true] - Kept for API compatibility (always true in production)
 * @returns {Object} { stationId, sourceRowCount, effectiveRowCount, records }
 */
export function preprocessCalibrationData(stationId, rawRows, options = {}) {
    const spec = CALIBRATION_SPECIFICATIONS[stationId];
    if (!spec) {
        throw new Error(`Unknown stationId: ${stationId}`);
    }

    if (!Array.isArray(rawRows) || rawRows.length === 0) {
        throw new Error('Input dataset is empty or invalid.');
    }

    // Build raw chronological calendar map.
    // Each row is independently normalized via normalizeRawDailyRow so that the calendar map
    // contains { inSitu, rain, target } regardless of which external header aliases the source used.
    const calendarMap = new Map();
    for (const row of rawRows) {
        const norm = normalizeRawDailyRow(stationId, row);
        const rawDate = norm.Date;
        if (!rawDate || !isValidCalendarDate(rawDate)) continue;

        const wl = norm.waterLevel;
        const rf = norm.rainfall;

        calendarMap.set(rawDate, {
            inSitu: Number.isFinite(wl) ? wl : null,
            rain: Number.isFinite(rf) ? rf : null,
            target: Number.isFinite(wl) ? wl : null,
        });
    }

    const shiftDate = (dateStr, days) => {
        const d = new Date(dateStr + 'T00:00:00Z');
        d.setUTCDate(d.getUTCDate() + days);
        return d.toISOString().split('T')[0];
    };

    const sortedDates = Array.from(calendarMap.keys()).sort();
    const processedRecords = [];

    for (const dStr of sortedDates) {
        const entry = calendarMap.get(dStr);
        if (!entry || entry.target === null) continue;

        const d_t_1 = shiftDate(dStr, -1);
        const d_t_3 = shiftDate(dStr, -3);

        const e_t_1 = calendarMap.get(d_t_1);
        const e_t_3 = calendarMap.get(d_t_3);

        if (stationId === 'sto_nino') {
            if (!e_t_1 || !e_t_3) continue;
            if (e_t_1.inSitu === null || e_t_3.inSitu === null || e_t_1.rain === null) continue;

            processedRecords.push({
                date: dStr,
                y: entry.target,
                predictors: {
                    Sto_t_1: e_t_1.inSitu,
                    Sto_t_3: e_t_3.inSitu,
                    BosoBoso_t_1: e_t_1.rain,
                },
                inSituLag1: e_t_1.inSitu,
            });
        } else if (stationId === 'nangka') {
            if (!e_t_1) continue;
            if (e_t_1.inSitu === null || e_t_1.rain === null) continue;

            processedRecords.push({
                date: dStr,
                y: entry.target,
                predictors: {
                    nangka_wl_t_1: e_t_1.inSitu,
                    bosoboso_rain_t_1: e_t_1.rain,
                },
                inSituLag1: e_t_1.inSitu,
            });
        } else if (stationId === 'tumana') {
            if (!e_t_1) continue;
            if (e_t_1.inSitu === null || e_t_1.rain === null) continue;

            processedRecords.push({
                date: dStr,
                y: entry.target,
                predictors: {
                    tumana_wl_t_1: e_t_1.inSitu,
                    pagasa_sg_rain_t_1: e_t_1.rain,
                },
                inSituLag1: e_t_1.inSitu,
            });
        }
    }

    processedRecords.sort((a, b) => a.date.localeCompare(b.date));

    return {
        stationId,
        sourceRowCount: rawRows.length,
        effectiveRowCount: processedRecords.length,
        records: processedRecords,
    };
}


// ── Main Deterministic Calibration Runner ────────────────────────

/**
 * Runs the complete two-stage calibration workflow:
 * Stage A: Evaluation (chronological train/validation split -> metrics & persistence)
 * Stage B: Final Refit (all combined historical complete-case rows -> activatable coefficients & diagnostic gates)
 * 
 * @param {Object} options
 * @param {string} options.stationId - Station identifier ('sto_nino', 'nangka', 'tumana').
 * @param {Array<Object>} options.uploadedRows - Array of uploaded dataset rows.
 * @param {boolean} [options.isCanonicalFixture=false] - True only when verifying canonical fixtures directly in internal test suites.
 * @param {Array<Object>} [options.priorAcceptedRows=[]] - Prior accepted yearly snapshots from DEPLOYED/SUPERSEDED calibrations.
 * @param {string} [options.sourceFilename='uploaded_data.csv'] - File name.
 * @param {string} [options.sourceSha256=''] - SHA-256 hash.
 * @param {string} [options.createdBy='system'] - Actor username.
 * @param {Object} [options.splitConfig] - Optional chronological split configuration.
 * @returns {Object} Complete auditable calibration result object.
 */
export function runCalibration({
    stationId,
    uploadedRows,
    isCanonicalFixture = false,
    priorAcceptedRows = [],
    sourceFilename = 'uploaded_data.csv',
    sourceSha256 = '',
    createdBy = 'system',
    splitConfig = null,
}) {
    const spec = CALIBRATION_SPECIFICATIONS[stationId];
    if (!spec) {
        throw new Error(`Invalid station ID for calibration: ${stationId}`);
    }

    let combinedRows = [];
    let protectedHistorySha256 = null;
    let protectedHistoryRowCount = 0;

    if (isCanonicalFixture) {
        // Canonical fixture reproduction mode (automated internal tests only): run directly on fixture dataset
        combinedRows = uploadedRows;
    } else {
        // Production yearly recalibration mode: load cryptographically verified protected baseline + prior accepted yearly history + new upload
        const protectedData = loadProtectedHistory(stationId);
        protectedHistorySha256 = protectedData.metadata.sha256;
        protectedHistoryRowCount = protectedData.metadata.rowCount;
        combinedRows = mergeProtectedHistoryWithYearlyData(stationId, protectedData.rows, uploadedRows, priorAcceptedRows);
    }

    const { sourceRowCount, effectiveRowCount, records } = preprocessCalibrationData(stationId, combinedRows, { rebuildCalendarLags: true });

    if (effectiveRowCount < 30) {
        throw new Error(`Insufficient complete-case records (${effectiveRowCount} rows). Minimum required is 30.`);
    }

    // Verify and measure the new yearly data's actual contribution to model rows.
    // Use normalizeRawDailyRow to extract dates so this is alias-independent.
    let newYearEffectiveRowCount = effectiveRowCount;
    if (!isCanonicalFixture) {
        const uploadedDateSet = new Set(uploadedRows.map(r => {
            const norm = normalizeRawDailyRow(stationId, r);
            return norm.Date || '';
        }));
        newYearEffectiveRowCount = records.filter(r => uploadedDateSet.has(r.date)).length;

        if (newYearEffectiveRowCount === 0) {
            throw new Error('No usable complete-case model rows were produced from the newly uploaded yearly dataset.');
        }
    }


    // ─────────────────────────────────────────────────────────────
    // STAGE A: CHRONOLOGICAL EVALUATION
    // ─────────────────────────────────────────────────────────────
    const splitIndex = splitConfig?.splitIndex !== undefined
        ? splitConfig.splitIndex
        : Math.floor(effectiveRowCount * 0.8);

    const trainRecords = splitConfig?.trainRecords || records.slice(0, splitIndex);
    const valRecords = splitConfig?.valRecords || (effectiveRowCount > splitIndex ? records.slice(splitIndex) : records);

    const trainY = trainRecords.map(r => r.y);
    const trainX = trainRecords.map(r => spec.requiredPredictorKeys.map(k => r.predictors[k]));

    const evalFit = fitOlsHc3(trainY, trainX, spec.requiredPredictorKeys);

    const evaluationCoefficients = {
        intercept: evalFit.beta[0],
    };
    for (let i = 0; i < spec.requiredPredictorKeys.length; i++) {
        evaluationCoefficients[spec.requiredPredictorKeys[i]] = evalFit.beta[i + 1];
    }

    // Evaluate on validation split
    let valSse = 0;
    let valSae = 0;
    let persistSse = 0;
    let persistSae = 0;
    let valSumY = 0;
    const nVal = valRecords.length;

    for (let i = 0; i < nVal; i++) {
        const r = valRecords[i];
        const actual = r.y;
        valSumY += actual;

        let pred = evaluationCoefficients.intercept;
        for (const k of spec.requiredPredictorKeys) {
            pred += evaluationCoefficients[k] * r.predictors[k];
        }

        const err = actual - pred;
        valSse += err * err;
        valSae += Math.abs(err);

        const pErr = actual - r.inSituLag1;
        persistSse += pErr * pErr;
        persistSae += Math.abs(pErr);
    }

    const valMeanY = valSumY / nVal;
    let valSst = 0;
    for (let i = 0; i < nVal; i++) {
        const dy = valRecords[i].y - valMeanY;
        valSst += dy * dy;
    }

    const validationMAE = parseFloat((valSae / nVal).toFixed(4));
    const validationRMSE = parseFloat(Math.sqrt(valSse / nVal).toFixed(4));
    const validationR2 = valSst > 1e-12 ? parseFloat((1 - (valSse / valSst)).toFixed(4)) : 0;

    const persistenceMAE = parseFloat((persistSae / nVal).toFixed(4));
    const persistenceRMSE = parseFloat(Math.sqrt(persistSse / nVal).toFixed(4));

    // ─────────────────────────────────────────────────────────────
    // STAGE B: FINAL FULL-HISTORY REFIT (ACTIVATABLE COEFFICIENTS)
    // ─────────────────────────────────────────────────────────────
    const allY = records.map(r => r.y);
    const allX = records.map(r => spec.requiredPredictorKeys.map(k => r.predictors[k]));

    const fullFit = fitOlsHc3(allY, allX, spec.requiredPredictorKeys);

    const finalCoefficients = {
        intercept: fullFit.beta[0],
    };
    const standardErrorsOLS = {
        intercept: fullFit.se_ols[0],
    };
    const standardErrorsHC3 = {
        intercept: fullFit.se_hc3[0],
    };
    const hc3TStats = {
        intercept: fullFit.t_hc3[0],
    };
    const hc3PValues = {
        intercept: fullFit.p_hc3[0],
    };
    const vifByPredictor = {};

    for (let i = 0; i < spec.requiredPredictorKeys.length; i++) {
        const key = spec.requiredPredictorKeys[i];
        finalCoefficients[key] = fullFit.beta[i + 1];
        standardErrorsOLS[key] = fullFit.se_ols[i + 1];
        standardErrorsHC3[key] = fullFit.se_hc3[i + 1];
        hc3TStats[key] = fullFit.t_hc3[i + 1];
        hc3PValues[key] = fullFit.p_hc3[i + 1];
        vifByPredictor[key] = fullFit.vifs[i];
    }

    // Evaluate Statistical Diagnostic Gates on the FINAL REFIT specification
    const diagnosticFailures = [];

    for (const k of spec.requiredPredictorKeys) {
        const pVal = hc3PValues[k];
        if (pVal >= 0.05) {
            diagnosticFailures.push(`Predictor ${k} failed significance gate (HC3 p-value = ${pVal.toExponential(3)} >= 0.05).`);
        }
    }

    if (fullFit.maxVif > 5.0) {
        diagnosticFailures.push(`Collinearity violation: max VIF = ${fullFit.maxVif.toFixed(2)} exceeds threshold of 5.0.`);
    }

    if (effectiveRowCount < 30) {
        diagnosticFailures.push(`Effective sample size (${effectiveRowCount}) is below minimum threshold of 30.`);
    }

    const diagnosticPassed = diagnosticFailures.length === 0;

    // Canonical Baseline Parity Comparison (Only evaluated for internal canonical fixture proofs)
    let maxAbsDiff = 0;
    let canonicalParityPassed = true;
    if (isCanonicalFixture) {
        const baseline = spec.canonicalBaselineCoefficients;
        for (const key of spec.coefficientKeys) {
            if (baseline[key] !== undefined && finalCoefficients[key] !== undefined) {
                const diff = Math.abs(finalCoefficients[key] - baseline[key]);
                if (diff > maxAbsDiff) maxAbsDiff = diff;
            }
        }
        canonicalParityPassed = maxAbsDiff <= 1e-5;
    }

    const canonicalParityResult = {
        evaluated: isCanonicalFixture,
        passed: isCanonicalFixture ? canonicalParityPassed : true,
        maxAbsoluteDifference: isCanonicalFixture ? maxAbsDiff : null,
    };

    return {
        stationId,
        candidateId: spec.candidateId,
        candidateDescription: spec.candidateDescription,
        modelStructureVersion: '2.0.0-LOCKED_SPECIFICATION',
        status: 'AUDITED',
        sourceFilename,
        sourceSha256,
        sourceRowCount: combinedRows.length,
        uploadedSourceRowCount: uploadedRows.length,
        newYearEffectiveRowCount,
        effectiveRowCount,
        isCanonicalFixture,
        protectedHistorySha256,
        protectedHistoryRowCount,
        trainingPeriod: {
            startDate: trainRecords[0]?.date || null,
            endDate: trainRecords[trainRecords.length - 1]?.date || null,
        },
        validationPeriod: {
            startDate: valRecords[0]?.date || null,
            endDate: valRecords[valRecords.length - 1]?.date || null,
        },
        evaluationCoefficients,
        coefficients: finalCoefficients, // Final full-history refit coefficients for activation
        standardErrorsOLS,
        standardErrorsHC3,
        hc3TStats,
        hc3PValues,
        vifByPredictor,
        maxVif: parseFloat(fullFit.maxVif.toFixed(4)),
        validationMAE,
        validationRMSE,
        validationR2,
        persistenceMAE,
        persistenceRMSE,
        diagnosticPassed,
        diagnosticFailures,
        canonicalParityResult,
        createdBy,
        createdAt: new Date(),
    };
}
