/**
 * FloodGuard Truthful Daily Forecast Service
 * 
 * Evaluates the three certified station models (Sto. Niño C9, Nangka C4, Tumana C8)
 * using deterministic OLS formulas, strict fallback rules, and dynamic active version resolution.
 */

import { STATION_MODEL_REGISTRY } from '../config/stationModelRegistry.js';
import { ActiveModelVersion } from '../models/ActiveModelVersion.js';

const getStatusLabel = (wl, thresholds, isTumana = false) => {
    if (isTumana) return 'UNMAPPED_DAILY_OBSERVATION';
    if (!Number.isFinite(wl) || wl === null) return 'UNAVAILABLE';
    if (!thresholds) return 'UNMAPPED';
    if (wl >= thresholds.critical) return 'CRITICAL';
    if (wl >= thresholds.alarm) return 'WARNING';
    if (wl >= thresholds.alert) return 'ALERT';
    return 'SAFE';
};

// ── Active Model Version Resolution Cache ────────────────────────
let ACTIVE_MODEL_CACHE = null;
let ACTIVE_MODEL_CACHE_TIME = 0;
const CACHE_TTL_MS = 60 * 1000; // 1 minute

export function invalidateActiveModelCache() {
    ACTIVE_MODEL_CACHE = null;
    ACTIVE_MODEL_CACHE_TIME = 0;
}

/**
 * Evaluates a station's locked structural formula using custom recalibrated coefficients.
 */
function evaluateWithCoefficients(stationId, coefficients, inputs) {
    if (stationId === 'sto_nino') {
        const { sto_t_1, sto_t_3, bosoboso_t_1 } = inputs || {};
        const inputsUsed = {};
        const missingInputs = [];
        const hasSto1 = Number.isFinite(sto_t_1) && sto_t_1 !== null;
        const hasSto3 = Number.isFinite(sto_t_3) && sto_t_3 !== null;
        const hasRain = Number.isFinite(bosoboso_t_1) && bosoboso_t_1 !== null;

        if (hasSto1) inputsUsed.Sto_t_1 = sto_t_1;
        else missingInputs.push('Sto_t_1');

        if (hasSto3) inputsUsed.Sto_t_3 = sto_t_3;
        else missingInputs.push('Sto_t_3');

        if (hasRain) inputsUsed.BosoBoso_t_1 = bosoboso_t_1;
        else missingInputs.push('BosoBoso_t_1');

        if (!hasSto1 || !hasSto3) {
            return {
                predictedWaterLevel: null,
                calculationMode: 'unavailable',
                fallbackReason: `Missing required in-situ water level lag inputs: ${missingInputs.filter(k => k.startsWith('Sto')).join(', ')}`,
                inputsUsed,
                missingInputs,
            };
        }

        if (!hasRain) {
            return {
                predictedWaterLevel: parseFloat(sto_t_1.toFixed(2)),
                calculationMode: 'persistence_fallback',
                fallbackReason: 'Missing Mt. Boso-Boso rainfall telemetry; falling back to lag-1 water level persistence.',
                inputsUsed,
                missingInputs,
            };
        }

        const b0 = coefficients.intercept ?? 3.5458516105979454;
        const b1 = coefficients.Sto_t_1 ?? 0.464199760356257;
        const b2 = coefficients.Sto_t_3 ?? 0.24569344143377558;
        const b3 = coefficients.BosoBoso_t_1 ?? 0.011525049019977172;

        const rawPred = b0 + (b1 * sto_t_1) + (b2 * sto_t_3) + (b3 * bosoboso_t_1);
        return {
            predictedWaterLevel: parseFloat(rawPred.toFixed(2)),
            calculationMode: 'primary_model',
            fallbackReason: null,
            inputsUsed,
            missingInputs: [],
        };
    } else if (stationId === 'nangka') {
        const { nangka_wl_t_1, bosoboso_t_1 } = inputs || {};
        const inputsUsed = {};
        const missingInputs = [];
        const hasNangka1 = Number.isFinite(nangka_wl_t_1) && nangka_wl_t_1 !== null;
        const hasRain = Number.isFinite(bosoboso_t_1) && bosoboso_t_1 !== null;

        if (hasNangka1) inputsUsed.Nangka_WL_t_1 = nangka_wl_t_1;
        else missingInputs.push('Nangka_WL_t_1');

        if (hasRain) inputsUsed.BosoBoso_t_1 = bosoboso_t_1;
        else missingInputs.push('BosoBoso_t_1');

        if (!hasNangka1) {
            return {
                predictedWaterLevel: null,
                calculationMode: 'unavailable',
                fallbackReason: 'Missing required in-situ water level lag input: Nangka_WL_t_1',
                inputsUsed,
                missingInputs,
            };
        }

        if (!hasRain) {
            return {
                predictedWaterLevel: parseFloat(nangka_wl_t_1.toFixed(2)),
                calculationMode: 'persistence_fallback',
                fallbackReason: 'Missing Mt. Boso-Boso rainfall telemetry; falling back to lag-1 water level persistence.',
                inputsUsed,
                missingInputs,
            };
        }

        const b0 = coefficients.intercept ?? 8.114816713807127;
        const b1 = coefficients.nangka_wl_t_1 ?? coefficients.Nangka_WL_t_1 ?? 0.489768812135568;
        const b2 = coefficients.bosoboso_rain_t_1 ?? coefficients.BosoBoso_t_1 ?? 0.009737494825196964;

        const rawPred = b0 + (b1 * nangka_wl_t_1) + (b2 * bosoboso_t_1);
        return {
            predictedWaterLevel: parseFloat(rawPred.toFixed(2)),
            calculationMode: 'primary_model',
            fallbackReason: null,
            inputsUsed,
            missingInputs: [],
        };
    } else if (stationId === 'tumana') {
        const { tumana_wl_t_1, pagasa_sg_rain_t_1 } = inputs || {};
        const inputsUsed = {};
        const missingInputs = [];
        const hasTumana1 = Number.isFinite(tumana_wl_t_1) && tumana_wl_t_1 !== null;
        const hasSgRain = Number.isFinite(pagasa_sg_rain_t_1) && pagasa_sg_rain_t_1 !== null;

        if (hasTumana1) inputsUsed.Tumana_WL_t_1 = tumana_wl_t_1;
        else missingInputs.push('Tumana_WL_t_1');

        if (hasSgRain) inputsUsed.PAGASA_SG_Rain_t_1 = pagasa_sg_rain_t_1;
        else missingInputs.push('PAGASA_SG_Rain_t_1');

        if (!hasTumana1) {
            return {
                predictedWaterLevel: null,
                calculationMode: 'unavailable',
                fallbackReason: 'Missing required in-situ water level lag input: Tumana_WL_t_1',
                inputsUsed,
                missingInputs,
            };
        }

        if (!hasSgRain) {
            return {
                predictedWaterLevel: parseFloat(tumana_wl_t_1.toFixed(2)),
                calculationMode: 'persistence_fallback',
                fallbackReason: 'Missing Science Garden daily rainfall telemetry; falling back to lag-1 water level persistence.',
                inputsUsed,
                missingInputs,
            };
        }

        const b0 = coefficients.intercept ?? 1.5147240224821763;
        const b1 = coefficients.tumana_wl_t_1 ?? coefficients.Tumana_WL_t_1 ?? 0.8735442115350864;
        const b2 = coefficients.pagasa_sg_rain_t_1 ?? coefficients.PAGASA_SG_Rain_t_1 ?? 0.008481630145296813;

        const rawPred = b0 + (b1 * tumana_wl_t_1) + (b2 * pagasa_sg_rain_t_1);
        return {
            predictedWaterLevel: parseFloat(rawPred.toFixed(2)),
            calculationMode: 'primary_model',
            fallbackReason: null,
            inputsUsed,
            missingInputs: [],
        };
    }

    return {
        predictedWaterLevel: null,
        calculationMode: 'unavailable',
        fallbackReason: `Unknown station ID: ${stationId}`,
        inputsUsed: {},
        missingInputs: [],
    };
}

/**
 * Resolves active station models from MongoDB ActiveModelVersion if deployed,
 * or safely falls back to STATION_MODEL_REGISTRY.
 */
export async function resolveActiveStationModels() {
    const now = Date.now();
    if (ACTIVE_MODEL_CACHE && (now - ACTIVE_MODEL_CACHE_TIME) < CACHE_TTL_MS) {
        return ACTIVE_MODEL_CACHE;
    }

    const models = {
        sto_nino: { ...STATION_MODEL_REGISTRY.sto_nino },
        nangka: { ...STATION_MODEL_REGISTRY.nangka },
        tumana: { ...STATION_MODEL_REGISTRY.tumana },
    };

    try {
        if (ActiveModelVersion) {
            const activeVersions = await ActiveModelVersion.find({});
            for (const av of activeVersions) {
                const sId = av.stationId;
                if (models[sId] && av.coefficients) {
                    const rawCoeffs = av.coefficients instanceof Map
                        ? Object.fromEntries(av.coefficients)
                        : (typeof av.coefficients.toObject === 'function' ? av.coefficients.toObject() : av.coefficients);

                    models[sId] = {
                        ...models[sId],
                        modelVersion: av.modelVersion,
                        coefficients: rawCoeffs,
                        isRecalibrated: true,
                        sourceCalibrationId: av.sourceCalibrationId,
                        activatedAt: av.activatedAt,
                        evaluate: (inputs) => evaluateWithCoefficients(sId, rawCoeffs, inputs),
                    };
                }
            }
        }
    } catch (err) {
        console.warn('⚠️ ActiveModelVersion lookup failed; falling back to bootstrap canonical registry:', err.message);
    }

    ACTIVE_MODEL_CACHE = models;
    ACTIVE_MODEL_CACHE_TIME = now;
    return models;
}

export const getPstDates = () => {
    // Current time in Asia/Manila (PST: UTC+8)
    const now = new Date();
    const pstOffsetMs = 8 * 3600 * 1000;
    const pstNow = new Date(now.getTime() + (now.getTimezoneOffset() * 60 * 1000) + pstOffsetMs);

    const pad = (n) => String(n).padStart(2, '0');
    const toYmd = (d) => `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`;

    const todayYmd = toYmd(pstNow);
    const yesterday = new Date(pstNow.getTime() - 24 * 3600 * 1000);
    const yesterdayYmd = toYmd(yesterday);

    return {
        sourceDataDate: yesterdayYmd,
        forecastTargetDate: todayYmd,
    };
};

/**
 * Evaluates daily forecasts for all three certified stations.
 * 
 * @param {Object} telemetry - Telemetry state containing sensors, upstreamRain, dailyInputs, or customDates.
 * @param {Object} [activeModelRegistry] - Optional resolved station model registry.
 * @returns {Object} Structured station forecasts and overall status.
 */
export const evaluateDailyForecasts = (telemetry = {}, activeModelRegistry = null) => {
    const registry = activeModelRegistry || STATION_MODEL_REGISTRY;
    const {
        sensors = {},
        upstreamRain = {},
        dailyInputs = null,
        customDates = null,
    } = telemetry;

    const { sourceDataDate, forecastTargetDate } = customDates || getPstDates();

    // 1. Sto. Niño Inputs (Candidate 9: AR2 + Boso-Boso Rain)
    const sto_t_1 = (dailyInputs && dailyInputs.sto_t_1 !== undefined)
        ? (Number.isFinite(dailyInputs.sto_t_1) && dailyInputs.sto_t_1 !== null ? dailyInputs.sto_t_1 : null)
        : (Number.isFinite(sensors.sto_nino) && sensors.sto_nino !== null ? sensors.sto_nino : null);

    const sto_t_3 = (dailyInputs && dailyInputs.sto_t_3 !== undefined)
        ? (Number.isFinite(dailyInputs.sto_t_3) && dailyInputs.sto_t_3 !== null ? dailyInputs.sto_t_3 : null)
        : (Number.isFinite(sensors.sto_nino_t_3) && sensors.sto_nino_t_3 !== null ? sensors.sto_nino_t_3 : null);

    const bosoboso_t_1 = (dailyInputs && dailyInputs.bosoboso_t_1 !== undefined)
        ? (Number.isFinite(dailyInputs.bosoboso_t_1) && dailyInputs.bosoboso_t_1 !== null ? dailyInputs.bosoboso_t_1 : null)
        : (Number.isFinite(upstreamRain.boso_boso_rfday) && upstreamRain.boso_boso_rfday !== null
            ? upstreamRain.boso_boso_rfday
            : (Number.isFinite(upstreamRain.boso_boso) && upstreamRain.boso_boso !== null ? upstreamRain.boso_boso : null));

    const stoModel = registry.sto_nino;
    const stoEval = stoModel.evaluate({
        sto_t_1,
        sto_t_3,
        bosoboso_t_1,
    });

    const stoStatus = getStatusLabel(stoEval.predictedWaterLevel, stoModel.thresholds, false);

    const stoForecast = {
        stationId: stoModel.stationId,
        stationName: stoModel.stationName,
        sourceDataDate,
        forecastTargetDate,
        predictedWaterLevel: stoEval.predictedWaterLevel,
        unit: stoModel.unit,
        selectedCandidate: stoModel.selectedCandidate,
        modelVersion: stoModel.modelVersion,
        calculationMode: stoEval.calculationMode,
        fallbackReason: stoEval.fallbackReason,
        targetSemantics: stoModel.targetSemantics,
        statusBand: stoStatus,
        status: stoStatus,
        thresholds: stoModel.thresholds,
        thresholdMappingAllowed: stoModel.thresholdMappingAllowed,
        inputsUsed: stoEval.inputsUsed,
        missingInputs: stoEval.missingInputs,
    };

    // 2. Nangka Inputs (Candidate 4: AR1 + Boso-Boso Rain)
    const nangka_wl_t_1 = (dailyInputs && dailyInputs.nangka_wl_t_1 !== undefined)
        ? (Number.isFinite(dailyInputs.nangka_wl_t_1) && dailyInputs.nangka_wl_t_1 !== null ? dailyInputs.nangka_wl_t_1 : null)
        : (Number.isFinite(sensors.nangka) && sensors.nangka !== null ? sensors.nangka : null);

    const nangkaModel = registry.nangka;
    const nangkaEval = nangkaModel.evaluate({
        nangka_wl_t_1,
        bosoboso_t_1,
    });

    const nangkaStatus = getStatusLabel(nangkaEval.predictedWaterLevel, nangkaModel.thresholds, false);

    const nangkaForecast = {
        stationId: nangkaModel.stationId,
        stationName: nangkaModel.stationName,
        sourceDataDate,
        forecastTargetDate,
        predictedWaterLevel: nangkaEval.predictedWaterLevel,
        unit: nangkaModel.unit,
        selectedCandidate: nangkaModel.selectedCandidate,
        modelVersion: nangkaModel.modelVersion,
        calculationMode: nangkaEval.calculationMode,
        fallbackReason: nangkaEval.fallbackReason,
        targetSemantics: nangkaModel.targetSemantics,
        statusBand: nangkaStatus,
        status: nangkaStatus,
        thresholds: nangkaModel.thresholds,
        thresholdMappingAllowed: nangkaModel.thresholdMappingAllowed,
        inputsUsed: nangkaEval.inputsUsed,
        missingInputs: nangkaEval.missingInputs,
    };

    // 3. Tumana Inputs (Candidate 8: AR1 + Science Garden Rain)
    const tumana_wl_t_1 = (dailyInputs && dailyInputs.tumana_wl_t_1 !== undefined)
        ? (Number.isFinite(dailyInputs.tumana_wl_t_1) && dailyInputs.tumana_wl_t_1 !== null ? dailyInputs.tumana_wl_t_1 : null)
        : (Number.isFinite(sensors.tumana) && sensors.tumana !== null ? sensors.tumana : null);

    const pagasa_sg_rain_t_1 = (dailyInputs && dailyInputs.pagasa_sg_rain_t_1 !== undefined)
        ? (Number.isFinite(dailyInputs.pagasa_sg_rain_t_1) && dailyInputs.pagasa_sg_rain_t_1 !== null ? dailyInputs.pagasa_sg_rain_t_1 : null)
        : (Number.isFinite(upstreamRain.science_garden_rfday) && upstreamRain.science_garden_rfday !== null
            ? upstreamRain.science_garden_rfday
            : (Number.isFinite(upstreamRain.science_garden) && upstreamRain.science_garden !== null ? upstreamRain.science_garden : null));

    const tumanaModel = registry.tumana;
    const tumanaEval = tumanaModel.evaluate({
        tumana_wl_t_1,
        pagasa_sg_rain_t_1,
    });

    const tumanaForecast = {
        stationId: tumanaModel.stationId,
        stationName: tumanaModel.stationName,
        sourceDataDate,
        forecastTargetDate,
        predictedWaterLevel: tumanaEval.predictedWaterLevel,
        unit: tumanaModel.unit,
        selectedCandidate: tumanaModel.selectedCandidate,
        modelVersion: tumanaModel.modelVersion,
        calculationMode: tumanaEval.calculationMode,
        fallbackReason: tumanaEval.fallbackReason,
        targetSemantics: tumanaModel.targetSemantics,
        statusBand: 'UNMAPPED_DAILY_OBSERVATION',
        status: 'UNMAPPED_DAILY_OBSERVATION',
        thresholds: null,
        thresholdMappingAllowed: false,
        inputsUsed: tumanaEval.inputsUsed,
        missingInputs: tumanaEval.missingInputs,
    };

    const stations = {
        sto_nino: stoForecast,
        nangka: nangkaForecast,
        tumana: tumanaForecast,
    };

    const activeStatuses = [stoStatus, nangkaStatus].filter(s => s !== 'UNAVAILABLE');
    let overall_status = 'SAFE';
    if (activeStatuses.includes('CRITICAL')) overall_status = 'CRITICAL';
    else if (activeStatuses.includes('WARNING')) overall_status = 'WARNING';
    else if (activeStatuses.includes('ALERT')) overall_status = 'ALERT';

    return {
        stations,
        overall_status,
        sourceDataDate,
        forecastTargetDate,
    };
};
