import express from 'express';
import mongoose from 'mongoose';
import cors from 'cors';
import dotenv from 'dotenv';
import path from 'path';
import bcrypt from 'bcryptjs';
import jwt from 'jsonwebtoken';
import crypto from 'crypto';
import { fileURLToPath } from 'url';
import admin from 'firebase-admin';
import fs from 'fs';
import multer from 'multer';
import { processAndTrain, sanitizeCoefficientsForSave } from './services/modelTraining.js';
import { computePredictions, runBackgroundSync, CACHE, invalidateCoefficientCache } from './services/predictionEngine.js';
import { DailyObservation } from './models/DailyObservation.js';
import { DailyForecast } from './models/DailyForecast.js';
import { RawTelemetryReading } from './models/RawTelemetryReading.js';
import { initDailyForecastScheduler, triggerManualForecastRun } from './services/dailyScheduler.js';
import { executeDailyForecastRun } from './services/dailyPipelineService.js';
import { topicFromBarangay } from './services/dailyFcmDispatcher.js';
import { calibrationRouter } from './routes/calibrationRoutes.js';

// Load environment variables from the root .env file
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
dotenv.config({ path: path.join(__dirname, '../.env') });

const isProduction = process.env.NODE_ENV === 'production' || Boolean(process.env.RENDER);

// Initialize Firebase Admin (env JSON preferred; local file for development only — never commit)
function initFirebaseAdmin() {
    try {
        let serviceAccount = null;
        if (process.env.FIREBASE_SERVICE_ACCOUNT_JSON) {
            serviceAccount = JSON.parse(process.env.FIREBASE_SERVICE_ACCOUNT_JSON);
        } else {
            const serviceAccountPath = path.join(__dirname, 'serviceAccountKey.json');
            if (fs.existsSync(serviceAccountPath)) {
                serviceAccount = JSON.parse(fs.readFileSync(serviceAccountPath, 'utf8'));
            }
        }
        if (!serviceAccount) {
            console.warn('⚠️ Firebase credentials not configured. Set FIREBASE_SERVICE_ACCOUNT_JSON or add a local (gitignored) serviceAccountKey.json. Alerts will not work.');
            return;
        }
        admin.initializeApp({
            credential: admin.credential.cert(serviceAccount)
        });
        console.log('✅ Firebase Admin initialized');
    } catch (err) {
        console.error('❌ Failed to initialize Firebase Admin:', err.message);
    }
}
initFirebaseAdmin();

const app = express();
const PORT = process.env.PORT || 5000;

// Security Hardening: Disable X-Powered-By header
app.disable('x-powered-by');

// Security Headers Middleware
app.use((req, res, next) => {
    res.setHeader('X-Content-Type-Options', 'nosniff');
    res.setHeader('X-Frame-Options', 'SAMEORIGIN');
    res.setHeader('Referrer-Policy', 'strict-origin-when-cross-origin');
    next();
});

// Middleware
app.use(cors({
    origin: [
        'https://floodguard-ai-6a9b6.web.app',
        'https://floodguard-web.web.app',
        'http://localhost:5173',
        'http://localhost:4173',
        'http://localhost:3000',
        'http://localhost:10000',
        'http://localhost:5000',
        'http://127.0.0.1:5173',
        'http://127.0.0.1:4173',
        'http://127.0.0.1:3000'
    ],
    credentials: true
}));
app.use(express.json());

// Set up Multer for Memory Storage (so we don't save Excel files to disk)
const upload = multer({ storage: multer.memoryStorage() });

// JWT secret: never use a hardcoded known fallback
let JWT_SECRET = process.env.JWT_SECRET;
if (!JWT_SECRET) {
    if (isProduction) {
        console.error('❌ JWT_SECRET is required in production. Set it in the environment and restart.');
        process.exit(1);
    }
    JWT_SECRET = crypto.randomBytes(32).toString('hex');
    console.warn('⚠️ JWT_SECRET not set — using an ephemeral secret for this process only. Set JWT_SECRET in .env for stable local tokens.');
}

// Authentication Middleware (any valid JWT)
const authenticateToken = (req, res, next) => {
    const authHeader = req.headers['authorization'];
    const token = authHeader && authHeader.split(' ')[1];

    if (!token) return res.status(401).json({ success: false, message: 'Access denied. No token provided.' });

    jwt.verify(token, JWT_SECRET, (err, user) => {
        if (err) return res.status(403).json({ success: false, message: 'Invalid or expired token.' });
        req.user = user;
        next();
    });
};

// Admin authorization (admin or super_admin)
const requireAdmin = (req, res, next) => {
    if (!req.user || (req.user.role !== 'admin' && req.user.role !== 'super_admin')) {
        return res.status(403).json({ success: false, message: 'Admin access required.' });
    }
    next();
};

// Super-admin authorization with server-side database lookup
const requireSuperAdmin = async (req, res, next) => {
    if (!req.user) {
        return res.status(401).json({ success: false, message: 'Authentication required.' });
    }
    try {
        const user = await AdminUser.findById(req.user.id);
        if (!user || user.role !== 'super_admin') {
            return res.status(403).json({ success: false, message: 'Super-admin access required.' });
        }
        req.superAdminUser = user;
        next();
    } catch (err) {
        return res.status(500).json({ success: false, message: 'Failed to verify super-admin authorization.' });
    }
};

// Password reconfirmation for dangerous calibration actions (activation, rollback)
const verifyPasswordReconfirmation = async (req, res, next) => {
    const { reconfirmPassword } = req.body || {};
    if (!reconfirmPassword) {
        return res.status(400).json({ success: false, message: 'Password reconfirmation required for this action.' });
    }
    const user = req.superAdminUser;
    if (!user || !user.password) {
        return res.status(403).json({ success: false, message: 'Super-admin authorization failed.' });
    }
    const isMatch = await bcrypt.compare(reconfirmPassword, user.password);
    if (!isMatch) {
        return res.status(403).json({ success: false, message: 'Invalid password reconfirmation.' });
    }
    next();
};

// Optional auth: attach req.user when a valid Bearer token is present; otherwise continue
const optionalAuthenticate = (req, res, next) => {
    const authHeader = req.headers['authorization'];
    const token = authHeader && authHeader.split(' ')[1];
    if (!token) return next();
    jwt.verify(token, JWT_SECRET, (err, user) => {
        if (!err) req.user = user;
        next();
    });
};

const allowPublicSimulate = process.env.ALLOW_PUBLIC_SIMULATE === 'true' && !isProduction;

// Root Route (Confirmation)
app.get('/', (req, res) => {
    res.send('🚀 FloodGuard MongoDB Bridge is running!');
});

// MongoDB Connection
const MONGODB_URI = process.env.VITE_MONGODB_URI;

if (!MONGODB_URI) {
    console.error("Error: VITE_MONGODB_URI is not defined in .env");
    process.exit(1);
}

mongoose.connect(MONGODB_URI)
    .then(() => console.log('✅ Connected to MongoDB Atlas'))
    .catch(err => console.error('❌ MongoDB Connection Error:', err));

// Schema for Admin Users (supports admin and super_admin roles)
const adminSchema = new mongoose.Schema({
    name: { type: String, default: 'FloodGuard Admin' },
    username: { type: String, required: true, index: true },
    password: { type: String, required: true },
    role: { type: String, enum: ['admin', 'super_admin'], default: 'admin' },
}, { strict: false });

// We use the 'admin' collection as requested
const AdminUser = mongoose.model('AdminUser', adminSchema, 'admin'); 
app.set('AdminUserModel', AdminUser); 

// --- System Logs Schema ---
const logSchema = new mongoose.Schema({
    timestamp: { type: Date, default: Date.now },
    action: { type: String, required: true },
    admin: { type: String, required: true },
    details: { type: String },
    ip: { type: String }
}, { strict: false });

const SystemLog = mongoose.model('SystemLog', logSchema, 'logs');

// --- User Schema (For Mobile Citizens) ---
const userSchema = new mongoose.Schema({
    uid: { type: String, unique: true }, 
    email: { type: String, required: true, unique: true },
    password: { type: String, required: true },
    first_name: String,
    last_name: String,
    phone: String,
    house_no: String,
    street_name: String,
    barangay: String,
    city: { type: String, default: "Marikina City" },
    province: { type: String, default: "Metro Manila" },
    zip_code: String,
    country: { type: String, default: "Philippines" },
    created_at: { type: Date, default: Date.now }
}, { strict: false });

const User = mongoose.model('User', userSchema, 'users');

// --- Machine Learning Coefficients Schema ---
const coefficientSchema = new mongoose.Schema({
    intercept: Number,
    rain: Number,
    temp: Number,
    humidity: Number,
    wind: Number,
    dataPointsUsed: Number,
    timestamp: { type: Date, default: Date.now }
}, { strict: false });

const Coefficient = mongoose.model('Coefficient', coefficientSchema, 'coefficients');

// --- NEW: Mobile Citizen Auth Routes ---

// CITIZEN SIGNUP
app.post('/api/auth/signup', async (req, res) => {
    try {
        const {
            firstName, lastName, email, password, barangay, phone,
            houseNo, house_no, streetName, street_name,
            city, province, zipCode, zip_code, country,
            first_name, last_name,
        } = req.body;

        const normalizedEmail = String(email || '').trim().toLowerCase();
        if (!normalizedEmail || !password) {
            return res.status(400).json({ success: false, message: 'Email and password are required' });
        }

        // Check if user exists
        const existingUser = await User.findOne({ email: normalizedEmail });
        if (existingUser) {
            return res.status(400).json({ success: false, message: 'Email already registered' });
        }

        // Hash password
        const hashedPassword = await bcrypt.hash(password, 10);

        // Persist address fields (schema supports house_no / street_name; accept camelCase aliases)
        const newUser = new User({
            first_name: firstName || first_name,
            last_name: lastName || last_name,
            email: normalizedEmail,
            password: hashedPassword,
            barangay,
            phone,
            house_no: house_no || houseNo || '',
            street_name: street_name || streetName || '',
            city: city || 'Marikina City',
            province: province || 'Metro Manila',
            zip_code: zip_code || zipCode || '',
            country: country || 'Philippines',
        });

        await newUser.save();
        res.json({ success: true, message: 'User registered successfully' });
    } catch (err) {
        console.error('Signup Error:', err);
        res.status(500).json({ success: false, message: 'Server error' });
    }
});

// CITIZEN LOGIN
app.post('/api/auth/login', async (req, res) => {
    try {
        const { email, password } = req.body;
        const normalizedEmail = String(email || '').trim().toLowerCase();

        // Find user by email (normalized — signup stores lowercase)
        const user = await User.findOne({ email: normalizedEmail });
        if (!user) {
            return res.status(400).json({ success: false, message: 'User not found' });
        }

        // Check password using Bcrypt
        const isMatch = await bcrypt.compare(password, user.password);
        if (!isMatch) {
            return res.status(400).json({ success: false, message: 'Invalid credentials' });
        }

        // Generate JWT Token
        const token = jwt.sign({ id: user._id, role: 'user' }, JWT_SECRET, { expiresIn: '30d' });

        res.json({
            success: true,
            token,
            user: {
                uid: user._id,
                firstName: user.first_name,
                lastName: user.last_name,
                email: user.email,
                barangay: user.barangay,
                phone: user.phone,
                houseNo: user.house_no || '',
                streetName: user.street_name || '',
                city: user.city || 'Marikina City',
                province: user.province || 'Metro Manila',
                zipCode: user.zip_code || '',
                country: user.country || 'Philippines',
            }
        });
    } catch (err) {
        console.error('Login Error:', err);
        res.status(500).json({ success: false, message: 'Server error' });
    }
});

// Optional local-only demo citizen (disabled by default — never auto-create with known password in production)
async function ensureDemoCitizen() {
    if (process.env.ALLOW_DEMO_CITIZEN_SEED !== 'true' || isProduction) return;
    try {
        const email = process.env.DEMO_CITIZEN_EMAIL || 'demo@floodguard.app';
        const plain = process.env.DEMO_CITIZEN_PASSWORD;
        if (!plain) {
            console.warn('⚠️ ALLOW_DEMO_CITIZEN_SEED=true but DEMO_CITIZEN_PASSWORD is unset — skipping demo seed.');
            return;
        }
        const existing = await User.findOne({ email });
        if (existing) return;
        const hashedPassword = await bcrypt.hash(plain, 10);
        await User.create({
            email,
            password: hashedPassword,
            first_name: 'Demo',
            last_name: 'Tester',
            barangay: 'Tumana',
            phone: '09171234567',
            city: 'Marikina City',
            province: 'Metro Manila',
            country: 'Philippines',
        });
        console.log(`✅ Demo citizen ready: ${email} (password from DEMO_CITIZEN_PASSWORD)`);
    } catch (err) {
        console.error('Demo citizen seed failed:', err.message);
    }
}
ensureDemoCitizen();

// Lookup phone number by email for Firebase Phone OTP Reset
app.post('/api/auth/lookup-phone', async (req, res) => {
    try {
        const email = String(req.body.email || '').trim().toLowerCase();
        if (!email) {
            return res.status(400).json({ success: false, message: 'Email is required' });
        }

        const user = await User.findOne({ email });
        if (!user || !user.phone) {
            return res.status(404).json({ success: false, message: 'No registered account found with that email address.' });
        }

        let rawPhone = user.phone.trim();
        let formattedPhone = rawPhone;
        if (formattedPhone.startsWith('0')) formattedPhone = '+63' + formattedPhone.substring(1);
        if (!formattedPhone.startsWith('+')) formattedPhone = '+63' + formattedPhone;

        const digits = rawPhone.replace(/\D/g, '');
        const last4 = digits.length >= 4 ? digits.slice(-4) : '****';
        const maskedPhone = `********${last4}`;

        res.json({
            success: true,
            email: user.email,
            phone: formattedPhone,
            maskedPhone: maskedPhone,
        });
    } catch (err) {
        console.error('Lookup phone error:', err);
        res.status(500).json({ success: false, message: 'Server error' });
    }
});

// Update password after Firebase Phone Auth SMS verification
app.post('/api/auth/update-password', async (req, res) => {
    try {
        const { email, newPassword } = req.body;
        const cleanEmail = String(email || '').trim().toLowerCase();

        if (!cleanEmail || !newPassword || newPassword.length < 6) {
            return res.status(400).json({ success: false, message: 'Email and new password (min 6 chars) are required' });
        }

        const user = await User.findOne({ email: cleanEmail });
        if (!user) {
            return res.status(404).json({ success: false, message: 'User account not found' });
        }

        const salt = await bcrypt.genSalt(10);
        user.password = await bcrypt.hash(newPassword, salt);
        user.reset_code = undefined;
        user.reset_code_expires = undefined;
        await user.save();

        res.json({ success: true, message: 'Password updated successfully. You can log in now.' });
    } catch (err) {
        console.error('Update password error:', err);
        res.status(500).json({ success: false, message: 'Server error' });
    }
});

app.post('/api/auth/forgot-password', async (req, res) => {
    try {
        const identifier = String(req.body.identifier || req.body.email || req.body.phone || '').trim();
        if (!identifier) {
            return res.status(400).json({ success: false, message: 'Phone number or Email is required' });
        }

        const cleanEmail = identifier.toLowerCase();
        const digits = identifier.replace(/\D/g, '');

        const user = await User.findOne({
            $or: [
                { email: cleanEmail },
                { phone: identifier },
                ...(digits && digits.length >= 7 ? [{ phone: new RegExp(digits.slice(-10) + '$') }] : [])
            ]
        });

        // Generate a 6-digit OTP reset code
        const code = String(Math.floor(100000 + Math.random() * 900000));
        
        if (user) {
            user.reset_code = await bcrypt.hash(code, 10);
            user.reset_code_expires = new Date(Date.now() + 15 * 60 * 1000);
            await user.save();
        }

        console.log(`🔑 Password reset code issued for ${identifier} -> OTP: ${code}`);

        res.json({
            success: true,
            message: `Reset code sent to ${identifier}.`,
            expires_in_minutes: 15,
            dev_code: code,
        });
    } catch (err) {
        console.error('Forgot password error:', err);
        res.status(500).json({ success: false, message: 'Server error' });
    }
});

app.post('/api/auth/reset-password', async (req, res) => {
    try {
        const identifier = String(req.body.identifier || req.body.email || req.body.phone || '').trim();
        const code = String(req.body.code || '').trim();
        const newPassword = String(req.body.newPassword || req.body.password || '');

        if (!identifier || !code || newPassword.length < 6) {
            return res.status(400).json({
                success: false,
                message: 'Phone/Email, reset code, and new password (min 6 chars) are required.',
            });
        }

        const cleanEmail = identifier.toLowerCase();
        const digits = identifier.replace(/\D/g, '');

        const user = await User.findOne({
            $or: [
                { email: cleanEmail },
                { phone: identifier },
                ...(digits && digits.length >= 7 ? [{ phone: new RegExp(digits.slice(-10) + '$') }] : [])
            ]
        });

        if (!user || !user.reset_code || !user.reset_code_expires) {
            return res.status(400).json({ success: false, message: 'Invalid or expired reset code.' });
        }
        if (new Date(user.reset_code_expires) < new Date()) {
            return res.status(400).json({ success: false, message: 'Reset code expired. Request a new one.' });
        }

        const ok = await bcrypt.compare(code, user.reset_code);
        if (!ok) {
            return res.status(400).json({ success: false, message: 'Invalid or expired reset code.' });
        }

        user.password = await bcrypt.hash(newPassword, 10);
        user.reset_code = undefined;
        user.reset_code_expires = undefined;
        await user.save();

        res.json({ success: true, message: 'Password updated. You can log in now.' });
    } catch (err) {
        console.error('Reset password error:', err);
        res.status(500).json({ success: false, message: 'Server error' });
    }
});


// Helper to create a log
const createLog = async (action, admin, details, req) => {
    try {
        const ip = req.headers['x-forwarded-for'] || req.socket.remoteAddress;
        await SystemLog.create({ action, admin, details, ip });
    } catch (err) {
        console.error('Failed to create log:', err);
    }
};

// QUARANTINED: Legacy training endpoints permanently disabled under Phase 5 governance
app.post('/api/train', (req, res) => {
    res.status(410).json({
        success: false,
        message: 'Legacy /api/train endpoint has been permanently decommissioned and quarantined under Phase 5 governance. Use /api/calibration/upload.',
    });
});

app.post('/api/train/save', (req, res) => {
    res.status(410).json({
        success: false,
        message: 'Legacy /api/train/save direct coefficient overwrite has been permanently decommissioned and quarantined under Phase 5 governance. All recalibrations must proceed through super-admin audited calibration workflow.',
    });
});

// Phase 5: Controlled Recalibration & Statistical Governance Router
app.use('/api/calibration', calibrationRouter);

// --- API ROUTES ---

// NEW: Live Prediction Endpoint
app.get('/api/status', async (req, res) => {
    try {
        const data = await computePredictions();
        res.json(data);
    } catch (err) {
        console.error('Status Error:', err);
        res.status(500).json({ success: false, message: 'Failed to fetch status.' });
    }
});

// Phase 2: Daily Stored Forecast Endpoint
app.get('/api/forecasts/daily', async (req, res) => {
    try {
        const { date } = req.query;
        const targetDate = date || (new Date(Date.now() + 8 * 3600 * 1000).toISOString().split('T')[0]);
        
        const forecasts = await DailyForecast.find({ forecastTargetDate: targetDate });
        if (!forecasts || forecasts.length === 0) {
            const result = await executeDailyForecastRun(targetDate);
            return res.json({
                success: true,
                forecastTargetDate: targetDate,
                sourceDataDate: result.sourceDataDate,
                overall_status: result.overall_status,
                stations: result.stations,
                isGeneratedOnDemand: true,
            });
        }

        const stations = {};
        forecasts.forEach(f => {
            stations[f.stationId] = f;
        });

        res.json({
            success: true,
            forecastTargetDate: targetDate,
            sourceDataDate: forecasts[0]?.sourceDataDate,
            stations,
            isGeneratedOnDemand: false,
        });
    } catch (err) {
        console.error('Daily Forecast Fetch Error:', err);
        res.status(500).json({ success: false, message: 'Failed to fetch daily forecasts.' });
    }
});

// Phase 2 & 3: Manual trigger endpoint (FCM disabled by default to prevent developer spam)
app.post('/api/forecasts/run-daily', ...(allowPublicSimulate ? [] : [authenticateToken, requireAdmin]), async (req, res) => {
    try {
        const { date, sendNotifications } = req.body || {};
        const result = await triggerManualForecastRun(date, Boolean(sendNotifications));
        res.json({ success: true, message: 'Daily forecast execution completed', result });
    } catch (err) {
        console.error('Run Daily Forecast Error:', err);
        res.status(500).json({ success: false, message: 'Failed to execute daily forecast run.' });
    }
});

// Simulation toggle — mutates server CACHE; admin-only unless ALLOW_PUBLIC_SIMULATE=true (non-production)
app.post('/api/simulate', ...(allowPublicSimulate ? [] : [authenticateToken, requireAdmin]), (req, res) => {
    try {
        if (req.body && req.body.simulate !== undefined) {
            CACHE.simulation_mode = Boolean(req.body.simulate);
            console.log(`[*] TYPHOON SIMULATION MODE: ${CACHE.simulation_mode ? 'ON' : 'OFF'}`);
        }
        res.json({ simulation_active: CACHE.simulation_mode });
    } catch (err) {
        console.error('Simulate error:', err);
        res.status(500).json({ success: false, message: 'Server error' });
    }
});

app.get('/api/simulate', ...(allowPublicSimulate ? [] : [authenticateToken, requireAdmin]), (req, res) => {
    res.json({ simulation_active: CACHE.simulation_mode });
});

// Admin Login Endpoint (Mongo bcrypt only — no hardcoded fallback credentials)
app.post('/api/login', async (req, res) => {
    const { username, password } = req.body;
    console.log(`Login attempt for admin: ${username}`);

    try {
        if (!username || !password) {
            return res.status(400).json({ success: false, message: 'Username and password are required' });
        }

        const adminUser = await AdminUser.findOne({ username });

        if (adminUser) {
            const isMatch = await bcrypt.compare(password, adminUser.password);

            if (isMatch) {
                console.log('✅ Admin login successful');
                createLog('LOGIN_SUCCESS', adminUser.username, 'Admin logged in successfully', req).catch(() => {});

                const userRole = adminUser.role || 'admin';
                const token = jwt.sign(
                    { id: adminUser._id, username: adminUser.username, role: userRole },
                    JWT_SECRET,
                    { expiresIn: '24h' }
                );

                return res.json({
                    success: true,
                    message: 'Login successful',
                    token: token,
                    user: { username: adminUser.username, role: userRole }
                });
            }
            console.log('❌ Invalid password');
            createLog('LOGIN_FAILURE', username, 'Invalid password attempt', req).catch(() => {});
            return res.status(401).json({ success: false, message: 'Invalid username or password' });
        }

        console.log('❌ Admin user not found');
        createLog('LOGIN_FAILURE', username, 'Username not found', req).catch(() => {});
        return res.status(401).json({ success: false, message: 'Invalid username or password' });
    } catch (err) {
        console.error('Login Error:', err);
        res.status(500).json({ success: false, message: 'Server error' });
    }
});

// --- CITIZEN/USER AUTH ROUTES ---

// User Registration
app.post('/api/user/register', async (req, res) => {
    try {
        const { email, password } = req.body;

        // Check if user exists
        const existing = await User.findOne({ email });
        if (existing) return res.status(400).json({ success: false, message: 'Email already registered' });

        // Hash password
        const salt = await bcrypt.genSalt(10);
        const hashedPassword = await bcrypt.hash(password, salt);

        // Generate a UID if not provided
        const uid = req.body.uid || new mongoose.Types.ObjectId().toString();

        const newUser = await User.create({
            ...req.body,
            password: hashedPassword,
            uid: uid
        });

        res.json({ 
            success: true, 
            message: 'User registered successfully',
            user: {
                uid: newUser.uid,
                email: newUser.email,
                first_name: newUser.first_name,
                last_name: newUser.last_name
            }
        });
    } catch (err) {
        console.error('Registration Error:', err);
        res.status(500).json({ success: false, message: err.message });
    }
});

// User Login
app.post('/api/user/login', async (req, res) => {
    try {
        const { email, password } = req.body;
        const user = await User.findOne({ email });

        if (!user) return res.status(401).json({ success: false, message: 'Invalid email or password' });

        const isMatch = await bcrypt.compare(password, user.password);
        if (!isMatch) return res.status(401).json({ success: false, message: 'Invalid email or password' });

        res.json({
            success: true,
            message: 'Login successful',
            user: {
                uid: user.uid,
                email: user.email,
                first_name: user.first_name,
                last_name: user.last_name,
                barangay: user.barangay
            }
        });
    } catch (err) {
        console.error('User Login Error:', err);
        res.status(500).json({ success: false, message: 'Server error' });
    }
});

// Update / Save User Profile
app.put('/api/user/profile', async (req, res) => {
    try {
        const { uid, email } = req.body;
        const searchEmail = String(email || '').trim().toLowerCase();

        let user = null;
        if (uid) {
            user = await User.findOne({ uid });
        }
        if (!user && searchEmail) {
            user = await User.findOne({ email: searchEmail });
        }

        const firstName = req.body.first_name || req.body.firstName;
        const lastName = req.body.last_name || req.body.lastName;
        const houseNo = req.body.house_no || req.body.houseNo;
        const streetName = req.body.street_name || req.body.streetName;
        const zipCode = req.body.zip_code || req.body.zipCode;

        if (!user) {
            user = new User({
                uid: uid || new mongoose.Types.ObjectId().toString(),
                email: searchEmail,
                first_name: firstName || '',
                last_name: lastName || '',
                phone: req.body.phone || '',
                house_no: houseNo || '',
                street_name: streetName || '',
                barangay: req.body.barangay || 'Nangka',
                city: req.body.city || 'Marikina City',
                province: req.body.province || 'Metro Manila',
                zip_code: zipCode || '1800',
                country: req.body.country || 'Philippines',
            });
        } else {
            if (firstName !== undefined) user.first_name = firstName;
            if (lastName !== undefined) user.last_name = lastName;
            if (req.body.phone !== undefined) user.phone = req.body.phone;
            if (houseNo !== undefined) user.house_no = houseNo;
            if (streetName !== undefined) user.street_name = streetName;
            if (req.body.barangay !== undefined) user.barangay = req.body.barangay;
            if (req.body.city !== undefined) user.city = req.body.city;
            if (req.body.province !== undefined) user.province = req.body.province;
            if (zipCode !== undefined) user.zip_code = zipCode;
            if (req.body.country !== undefined) user.country = req.body.country;
        }

        await user.save();

        res.json({
            success: true,
            message: 'Profile saved successfully',
            user: {
                uid: user.uid,
                email: user.email,
                first_name: user.first_name,
                last_name: user.last_name,
                phone: user.phone,
                house_no: user.house_no,
                street_name: user.street_name,
                barangay: user.barangay,
                city: user.city,
                province: user.province,
                zip_code: user.zip_code,
                country: user.country,
            }
        });
    } catch (err) {
        console.error('User Profile Save Error:', err);
        res.status(500).json({ success: false, message: 'Server error saving profile' });
    }
});

app.post('/api/user/profile', async (req, res) => {
    try {
        const { uid, email } = req.body;
        const searchEmail = String(email || '').trim().toLowerCase();

        let user = null;
        if (uid) {
            user = await User.findOne({ uid });
        }
        if (!user && searchEmail) {
            user = await User.findOne({ email: searchEmail });
        }

        const firstName = req.body.first_name || req.body.firstName;
        const lastName = req.body.last_name || req.body.lastName;
        const houseNo = req.body.house_no || req.body.houseNo;
        const streetName = req.body.street_name || req.body.streetName;
        const zipCode = req.body.zip_code || req.body.zipCode;

        if (!user) {
            user = new User({
                uid: uid || new mongoose.Types.ObjectId().toString(),
                email: searchEmail,
                first_name: firstName || '',
                last_name: lastName || '',
                phone: req.body.phone || '',
                house_no: houseNo || '',
                street_name: streetName || '',
                barangay: req.body.barangay || 'Nangka',
                city: req.body.city || 'Marikina City',
                province: req.body.province || 'Metro Manila',
                zip_code: zipCode || '1800',
                country: req.body.country || 'Philippines',
            });
        } else {
            if (firstName !== undefined) user.first_name = firstName;
            if (lastName !== undefined) user.last_name = lastName;
            if (req.body.phone !== undefined) user.phone = req.body.phone;
            if (houseNo !== undefined) user.house_no = houseNo;
            if (streetName !== undefined) user.street_name = streetName;
            if (req.body.barangay !== undefined) user.barangay = req.body.barangay;
            if (req.body.city !== undefined) user.city = req.body.city;
            if (req.body.province !== undefined) user.province = req.body.province;
            if (zipCode !== undefined) user.zip_code = zipCode;
            if (req.body.country !== undefined) user.country = req.body.country;
        }

        await user.save();

        res.json({
            success: true,
            message: 'Profile saved successfully',
            user: {
                uid: user.uid,
                email: user.email,
                first_name: user.first_name,
                last_name: user.last_name,
                phone: user.phone,
                house_no: user.house_no,
                street_name: user.street_name,
                barangay: user.barangay,
                city: user.city,
                province: user.province,
                zip_code: user.zip_code,
                country: user.country,
            }
        });
    } catch (err) {
        console.error('User Profile Save Error:', err);
        res.status(500).json({ success: false, message: 'Server error saving profile' });
    }
});


// Test Endpoint to list collections (Admin only)
app.get('/api/debug/collections', authenticateToken, requireAdmin, async (req, res) => {
    try {
        const collections = await mongoose.connection.db.listCollections().toArray();
        res.json(collections.map(c => c.name));
    } catch (err) {
        console.error('Debug collections error:', err);
        res.status(500).json({ success: false, message: 'Server error' });
    }
});

// Simple Endpoint to fetch Reports (Protected)
const Report = mongoose.model('Report', new mongoose.Schema({
    location: String,
    is_raining: Boolean,
    is_safe: Boolean,
    uid: String,
    flood_depth: Number,
    timestamp: { type: Date, default: Date.now }
}, { strict: false }), 'reports');

// Submit Report — anonymous allowed; authenticated users cannot forge another UID
app.post('/api/reports', optionalAuthenticate, async (req, res) => {
    try {
        let uid = 'anonymous';
        if (req.user && (req.user.id || req.user.uid)) {
            uid = String(req.user.id || req.user.uid);
        }
        // Ignore client-supplied uid for identity (prevents impersonation)

        const newReport = await Report.create({
            location: req.body.location,
            barangay: req.body.barangay,
            street: req.body.street || req.body.street_name,
            is_raining: req.body.is_raining ?? req.body.isRaining,
            is_safe: req.body.is_safe ?? req.body.isSafe,
            uid,
            flood_depth: req.body.flood_depth ?? req.body.floodDepth,
            flood_level: req.body.flood_level ?? req.body.floodLevel,
            reporter_name: req.body.reporter_name ?? req.body.reporterName,
            reporter_phone: req.body.reporter_phone ?? req.body.reporterPhone,
            phone: req.body.reporter_phone ?? req.body.reporterPhone ?? req.body.phone,
            name: req.body.reporter_name ?? req.body.reporterName ?? req.body.name,
            depth: req.body.flood_depth ?? req.body.floodDepth ?? req.body.depth,
            latitude: req.body.latitude ?? req.body.lat,
            longitude: req.body.longitude ?? req.body.lng ?? req.body.lon,
            help_needed: req.body.help_needed ?? req.body.helpNeeded ?? null,
            status: req.body.status || 'pending',
            timestamp: new Date()
        });
        res.status(201).json({ 
            success: true, 
            message: 'Report submitted successfully',
            data: newReport 
        });
    } catch (err) {
        console.error('❌ Error saving report:', err);
        res.status(500).json({ success: false, message: 'Failed to save report' });
    }
});

app.get('/api/reports', authenticateToken, requireAdmin, async (req, res) => {
    try {
        res.setHeader('Cache-Control', 'no-store, no-cache, must-revalidate, private');
        const reports = await Report.find().sort({ _id: -1 }); // Get newest first
        
        // Log the data access
        await createLog('VIEW_REPORTS', req.user.username || req.user.id, `Accessed ${reports.length} report entries`, req);
        
        res.json({ success: true, data: reports });
    } catch (err) {
        console.error('Error fetching reports:', err);
        res.status(500).json({ success: false, message: 'Server error' });
    }
});

// Endpoint to fetch System Logs (Admin only)
app.get('/api/logs', authenticateToken, requireAdmin, async (req, res) => {
    try {
        res.setHeader('Cache-Control', 'no-store, no-cache, must-revalidate, private');
        const logs = await SystemLog.find().sort({ timestamp: -1 }).limit(100);
        res.json({ success: true, data: logs });
    } catch (err) {
        console.error('Error fetching logs:', err);
        res.status(500).json({ success: false, message: 'Server error' });
    }
});

// --- NOTIFICATIONS ---

// Subscribe to Barangay
app.post('/api/user/subscribe', async (req, res) => {
    try {
        const { token, barangay } = req.body;
        if (!token || !barangay) {
            return res.status(400).json({ success: false, message: 'Missing token or barangay' });
        }

        // Canonical topic name
        const topic = topicFromBarangay(barangay);

        // Use Firebase Admin to subscribe the token to the topic
        await admin.messaging().subscribeToTopic(token, topic);

        console.log(`✅ Subscribed token to topic: ${topic}`);
        res.json({ success: true, message: `Subscribed successfully to ${topic}` });
    } catch (error) {
        console.error('❌ Subscription Error:', error);
        res.status(500).json({ success: false, message: 'Failed to subscribe' });
    }
});

// --- ALERTS ---
const RIVER_TO_BARANGAYS = {
    nangka: ['Nangka', 'Parang', 'Fortune'],
    tumana: ['Tumana', 'Malanday', 'Concepcion Uno', 'Marikina Heights', 'Concepcion Dos'],
    sto_nino: [
        'Santo Niño', 'Calumpang', 'Industrial Valley', 'Barangka',
        'San Roque', 'Santa Elena', 'Tañong', 'Jesus Dela Peña',
    ],
};

/** Auto-push when predicted WL band changes (SAFE/ALERT/WARNING/CRITICAL), up or down. */
async function maybeSendAutoWaterLevelAlerts(precomputed = null) {
    if (!admin.apps.length) return;
    try {
        const data = precomputed || await computePredictions();
        const rivers = data.prediction?.rivers || {};
        const rank = { SAFE: 0, ALERT: 1, WARNING: 2, CRITICAL: 3 };
        const labelFor = (s) => (s === 'WARNING' ? 'ALARM' : s);

        for (const [riverKey, river] of Object.entries(rivers)) {
            const status = String(river.status || 'SAFE').toUpperCase();
            const prev = String(CACHE.last_auto_alert?.[riverKey] || 'SAFE').toUpperCase();
            CACHE.last_auto_alert[riverKey] = status;

            if (status === prev) continue; // no band change

            const thr = river.thresholds || {};
            const wl = Number(river.predicted_water_level ?? 0).toFixed(2);
            const goingUp = (rank[status] || 0) > (rank[prev] || 0);
            const direction = goingUp ? 'rising' : 'falling';
            const riverName = riverKey.replace(/_/g, ' ');

            const title = goingUp
                ? `FloodGuard: ${labelFor(status)}`
                : `FloodGuard: Level ${direction} → ${labelFor(status)}`;

            const body =
                `${riverName}: predicted ${wl} m EL moved from ${labelFor(prev)} to ${labelFor(status)} (${direction}). ` +
                `Station bands — Alert ${thr.alert ?? '—'} / Alarm ${thr.alarm ?? '—'} / Critical ${thr.critical ?? '—'} m. ` +
                `Follow PAGASA/MDRRMO. Predictions are not 100% accurate.`;

            const barangays = RIVER_TO_BARANGAYS[riverKey] || [];
            for (const b of barangays) {
                const topic = topicFromBarangay(b);
                try {
                    await admin.messaging().send({
                        notification: { title, body },
                        data: {
                            type: 'water_level_auto',
                            river: riverKey,
                            status,
                            previous_status: prev,
                            direction,
                            water_level: String(wl),
                            barangay: b,
                        },
                        topic,
                    });
                    console.log(`📢 Auto-alert ${prev}→${status} (${direction}) → ${topic}`);
                } catch (err) {
                    console.warn(`Auto-alert failed for ${topic}:`, err.message);
                }
            }
        }
    } catch (err) {
        console.warn('maybeSendAutoWaterLevelAlerts failed:', err.message);
    }
}

app.post('/api/user/send-alert', authenticateToken, requireAdmin, async (req, res) => {
    const { barangay, title, body } = req.body;

    if (!admin.apps.length) {
        return res.status(503).json({ 
            success: false, 
            message: 'Firebase is not initialized. Configure FIREBASE_SERVICE_ACCOUNT_JSON or a local serviceAccountKey.json.' 
        });
    }

    if (!barangay || !title || !body) {
        return res.status(400).json({ success: false, message: 'Missing required fields' });
    }

    // Canonical topic name
    const topic = topicFromBarangay(barangay);

    const message = {
        notification: {
            title: title,
            body: body,
        },
        topic: topic,
    };

    console.log(`📡 Sending FCM message to topic: ${topic}`);

    try {
        const response = await admin.messaging().send(message);
        console.log(`📢 Alert sent to topic [${topic}]`);
        res.json({ success: true, message: 'Alert sent successfully', messageId: response });
    } catch (error) {
        console.error('❌ FCM Error:', error.message);
        res.status(500).json({ success: false, message: 'Failed to send alert' });
    }
});

// --- INITIALIZE BACKGROUND TASKS ---
console.log("[*] Starting Background Telemetry Sync Engine (5-minute polling)...");
const syncTelemetry = async () => {
    await runBackgroundSync();
    // Intraday telemetry collection and storage only; NO automated daily forecast FCM in 5-minute loop
};
syncTelemetry(); // Run immediately on start
setInterval(syncTelemetry, 5 * 60 * 1000); // Then every 5 minutes

// Phase 2 & 3: Initialize 07:00 AM PST Daily Forecast Scheduler & FCM Dispatcher
initDailyForecastScheduler();

app.listen(PORT, () => {
    console.log(`Server running on port ${PORT}`);
});
