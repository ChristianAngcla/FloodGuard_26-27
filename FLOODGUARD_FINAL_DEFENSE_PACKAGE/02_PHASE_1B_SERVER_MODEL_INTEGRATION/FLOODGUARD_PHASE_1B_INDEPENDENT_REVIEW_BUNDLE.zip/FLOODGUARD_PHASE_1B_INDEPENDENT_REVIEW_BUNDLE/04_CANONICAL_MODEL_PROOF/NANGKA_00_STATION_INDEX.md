# Nangka Station Canonical Evidence Index (R1.1 Repaired)

**Station Name**: Nangka River Monitoring Station  
**Target Variable**: Daily Maximum Water Level (`Nangka_WL_max`), meters  
**Selected Operational Model**: **Candidate 4** (`AR1 + Boso-Boso_t_1`)  
**Canonical Tournament Package**: `FLOODGUARD_NANGKA_MODEL_TOURNAMENT_R5_RECONCILED.zip` (SHA-256: `d787621a...`)  
**Canonical Phase 0 Audit Package**: `FLOODGUARD_NANGKA_PHASE0_AUDIT_R3_CERTIFIED.zip` (SHA-256: `2c19a097...`)

---

## 1. Eleven-Point Station Disclosure

1. **Exact Target**: Daily Maximum Water Level at Nangka (`Nangka_WL_max`), derived from hourly MMDA sensor readings (meters above local datum).
2. **Final Candidate & Equation**: Candidate 4  
   $$\widehat{\text{Nangka\_WL}}_t = 8.114817 + 0.489769 \cdot \text{Nangka}_{t-1} + 0.009737 \cdot \text{BosoBoso}_{t-1}$$
3. **Predictor Meanings**:
   - `Nangka_t_1`: Prior-day ($t-1$) Daily Maximum Water Level at Nangka (meters)
   - `BosoBoso_t_1`: Prior-day ($t-1$) Daily Total Rainfall at Mt. Boso-Boso telemetry gauge (mm)
   - *CRITICAL VERIFICATION*: Candidate 4 uses Mt. Boso-Boso rainfall. It does **not** use Mt. Campana rainfall.
4. **Chronological Dates**:
   - Training: 2016-01-01 to 2022-05-26 ($N=1,810$)
   - Validation: 2022-05-27 to 2023-12-31 ($N=318$)
   - Final Refit: 2016-01-01 to 2023-12-31 ($N=2,128$, $R^2 = 0.4335$)
   - Retrospective Evaluation: 2024-01-01 to 2025-12-31 ($N=424$)
5. **HC3 and VIF Status**:
   - Max VIF: **1.5957** (Passes $\le 5.0$ gate)
   - Refit HC3 Standard Errors: Intercept $SE=0.8404$, `Nangka_t_1` $SE=0.0530$ ($p < 0.0001$), `BosoBoso_t_1` $SE=0.0020$ ($p < 0.0001$).
6. **Overall Validation Basis**:
   - Validation MAE: 0.1438 m, RMSE: 0.3846 m, $R^2 = 0.5105$.
   - **Rank 1 Tournament Winner**: Candidate 4 achieved Rank 1 in the frozen 15-candidate validation tournament with 14 of 14 exact-common-date pairwise MAE wins and the lowest validation MAE (0.1438 m). Candidate 5 had a slightly lower candidate-specific validation RMSE (0.3809 m versus 0.3846 m), which is disclosed as a trade-off.
7. **Persistence Trade-off**:
   - On 318 validation dates, Candidate 4 MAE (0.1438 m) vs Persistence (0.1268 m); Candidate 4 RMSE (0.3846 m) vs Persistence (0.4401 m) — **+12.61% RMSE Improvement over Persistence**.
8. **Event & Critical-Day Trade-off**:
   - Candidate 4 won the overall tournament but is **not** the best model on every critical subset.
   - Multi-station models (C11, C14, C15) achieve lower MAE on high stage ($\ge 16.50$ m) and rapid rise ($\ge 0.50$ m) because upstream catchment gauges capture intense localized mountain rain. Candidate 4 is retained for overall tournament victory and high operational robustness.
9. **Availability and Fallback**:
   - Retrospective Availability: Primary model usable on 354 / 424 days (83.49%); 2 days persistence fallback (83.96% total forecast availability). 68 days missing in-situ water level (null return).
10. **Known Limitations**:
    - Flash tributary response: Nangka responds rapidly to localized mountain rainfall. Under extreme flash conditions, single-rainfall lag can lag rapid peak surges.
11. **Authoritative Evidence Paths**:
    - Tournament ZIP: `03_NANGKA/01_CANONICAL_PACKAGE/FLOODGUARD_NANGKA_MODEL_TOURNAMENT_R5_RECONCILED.zip`
    - Phase 0 Audit ZIP: `03_NANGKA/01_CANONICAL_PACKAGE/FLOODGUARD_NANGKA_PHASE0_AUDIT_R3_CERTIFIED.zip`
    - Reconciled Defense PDF: `03_NANGKA/10_DEFENSE_RECORD/FLOODGUARD_NANGKA_COMPLETE_DEFENSE_RECORD_R5_RECONCILED.pdf`
    - Event Sensitivity CSV: `03_NANGKA/07_EVENT_AND_CRITICAL_SENSITIVITY/NANGKA_EVENT_SENSITIVITY_AUDIT_R1.csv`
    - C4 Pairwise Summary: `03_NANGKA/07_EVENT_AND_CRITICAL_SENSITIVITY/NANGKA_EVENT_SENSITIVITY_PAIRWISE_C4_SUMMARY_R1.md`
