# Tumana Station Canonical Evidence Index (R1.1 Repaired)

**Station Name**: Tumana Bridge Monitoring Station  
**Target Variable**: **PAGASA-reported daily Tumana water-level observation** (meters)  
**Selected Operational Model**: **Candidate 8** (`AR1 + PAGASA_SG_Rain_t_1`)  
**Canonical Package**: `FLOODGUARD_TUMANA_DAILY_MODEL_R3_1_2_FINAL_EVIDENCE_RECONCILED.zip`  
**Package SHA-256**: `b84441b13dcbd3afaa7140728f44bbcac3d9db3a71882d15864ff1e9885e38cb`

---

## 1. Eleven-Point Station Disclosure

1. **Exact Target**: Strictly defined as the **PAGASA-reported daily Tumana water-level observation** (in meters), obtained from DOST-PAGASA HMDAS.
   - *CRITICAL PROHIBITION*: Do NOT describe Tumana as maximum, mean, hourly peak, flood depth, probability, or official emergency trigger. Source metadata provides one daily observation per calendar day.
2. **Final Candidate & Equation**: Candidate 8  
   $$\widehat{\text{Tumana\_WL}}_t = 1.514724 + 0.873544 \cdot \text{Tumana}_{t-1} + 0.008482 \cdot \text{PAGASA\_SG\_Rain}_{t-1}$$
3. **Predictor Meanings**:
   - `Tumana_t_1`: Prior-day ($t-1$) PAGASA-reported daily Tumana water-level observation (meters)
   - `PAGASA_SG_Rain_t_1`: Prior-day ($t-1$) Daily Rainfall from PAGASA Science Garden synoptic station (mm)
4. **Chronological Dates**:
   - Training: 2016-01-01 to 2020-12-31 ($N=1,068$)
   - Validation: 2021-01-01 to 2022-12-31 ($N=580$)
   - Final Refit: 2016-01-01 to 2022-12-31 ($N=1,648$, $R^2 = 0.8426$)
   - Retrospective Evaluation: 2024-01-01 to 2025-12-31 ($N=566$)
5. **HC3 and VIF Status**:
   - Max VIF: **1.1212** (Passes $\le 5.0$ gate)
   - Refit HC3 Inference: Intercept ($p = 0.0488$), `Tumana_t_1` ($p = 4.83 \times 10^{-42}$), `PAGASA_SG_Rain_t_1` ($p = 1.22 \times 10^{-8}$).
6. **Overall Validation Basis**:
   - Validation MAE: 0.1481 m, RMSE: 0.3244 m, $R^2 = 0.7723$, Bias: +0.0066 m.
   - **Winner of Frozen Eligible-MLR Rule**: Candidate 8 won the predeclared eligible-MLR MAE rule with 10 of 14 pairwise MAE wins.
7. **Persistence Trade-off**:
   - On 580 validation dates, Candidate 8 MAE (0.1481 m) vs Persistence (0.1416 m); Candidate 8 RMSE (0.3244 m) vs Persistence (0.3604 m) — **+9.99% RMSE Improvement over Persistence**.
8. **Event & Critical-Day Trade-off**:
   - *Disclosed Trade-off*: Candidate 14 (AR2 + SG Rain) achieved lower validation RMSE (0.3101 m vs 0.3244 m) and performs better on high stage ($\ge 13.435$ m: MAE 0.6921 m vs 0.7581 m) and rapid rise ($\ge 0.50$ m: MAE 0.8031 m vs 0.8079 m).
   - *Selection Preservation*: Candidate 8 remains selected because it won the predeclared primary MAE tournament rule, and post-selection sensitivity audits are not a retroactive replacement tournament.
9. **Availability and Fallback**:
   - 310 primary-model days occurred in 2024. One additional primary-model day occurred on 2025-01-01 because the required $t-1$ Science Garden rainfall value for 2024-12-31 was available. The remaining 236 fallback-eligible 2025 days used true persistence when Science Garden rainfall was discontinued. Total forecast availability: **547 / 566 observed days (96.64%)**; 19 days null due to in-situ sensor gap.
10. **Known Limitations**:
    - Daily observation cadence (cannot resolve within-day flash flood peaks); Science Garden rainfall series terminated after 2024, necessitating persistence fallback in 2025.
11. **Authoritative Evidence Paths**:
    - Canonical ZIP: `04_TUMANA/01_CANONICAL_PACKAGE/FLOODGUARD_TUMANA_DAILY_MODEL_R3_1_2_FINAL_EVIDENCE_RECONCILED.zip`
    - Reconciled Defense PDF: `04_TUMANA/10_DEFENSE_RECORD/FLOODGUARD_TUMANA_COMPLETE_DEFENSE_RECORD_R3_1.pdf`
    - Availability Audit CSV: `04_TUMANA/01_CANONICAL_PACKAGE/` (inside ZIP: `TUMANA_RUNTIME_FALLBACK_AVAILABILITY_AUDIT.csv`)
    - Event Sensitivity Report: `04_TUMANA/07_EVENT_AND_CRITICAL_SENSITIVITY/TUMANA_EVENT_SENSITIVITY_REPORT_R1.md`
