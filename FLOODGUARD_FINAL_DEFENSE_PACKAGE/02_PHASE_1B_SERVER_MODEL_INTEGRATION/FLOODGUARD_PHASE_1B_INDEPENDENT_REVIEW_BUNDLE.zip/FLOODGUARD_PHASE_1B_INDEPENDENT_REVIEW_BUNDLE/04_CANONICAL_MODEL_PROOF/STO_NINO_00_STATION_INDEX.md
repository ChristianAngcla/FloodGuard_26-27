# Sto. Niño Station Canonical Evidence Index (R1.1 Repaired)

**Station Name**: Sto. Niño Water Level Monitoring Station  
**Target Variable**: Daily Maximum Water Level (`Sto_Nino_WL_max`), meters  
**Selected Operational Model**: **Candidate 9** (`AR2 + Boso-Boso_t_1`)  
**Canonical Package**: `FLOODGUARD_STO_NINO_CANDIDATE9_FINAL_DEFENSE_CERTIFIED_R2.zip`  
**Package SHA-256**: `4f125ab0c1974cd1bec6c01ce98abb0f1b5d8217e73ca122ba6370967857dd4d`

---

## 1. Eleven-Point Station Disclosure

1. **Exact Target**: Daily Maximum Water Level at Sto. Niño (`Sto_Nino_WL_max`), derived from hourly MMDA sensor readings (meters above local datum).
2. **Final Candidate & Equation**: Candidate 9  
   $$\widehat{\text{Sto\_WL}}_t = 3.545852 + 0.464200 \cdot \text{Sto}_{t-1} + 0.245693 \cdot \text{Sto}_{t-3} + 0.011525 \cdot \text{BosoBoso}_{t-1}$$
3. **Predictor Meanings**:
   - `Sto_t_1`: Prior-day ($t-1$) Daily Maximum Water Level at Sto. Niño (meters)
   - `Sto_t_3`: 3-day antecedent ($t-3$) Daily Maximum Water Level at Sto. Niño (meters)
   - `BosoBoso_t_1`: Prior-day ($t-1$) Daily Total Rainfall at Mt. Boso-Boso telemetry gauge (mm)
   - *CRITICAL VERIFICATION*: Candidate 9 uses Mt. Boso-Boso rainfall. It does **not** use Mt. Oro rainfall.
4. **Chronological Dates**:
   - Training: 2016-01-01 to 2022-05-26 ($N=1,969$)
   - Validation: 2022-05-27 to 2023-12-31 ($N=472$)
   - Final Refit: 2016-01-01 to 2023-12-31 ($N=2,441$, $R^2 = 0.8988$)
   - Retrospective Evaluation: 2024-01-01 to 2025-12-31 ($N=681$)
5. **HC3 and VIF Status**:
   - Max VIF: **2.0610** (Passes $\le 5.0$ gate)
   - Training HC3 p-values: `Sto_t_1` ($p = 5.84 \times 10^{-12}$), `Sto_t_3` ($p = 4.21 \times 10^{-7}$), `BosoBoso_t_1` ($p = 1.82 \times 10^{-7}$) — all slopes $p < 0.0001$.
6. **Overall Validation Basis**:
   - Validation MAE: 0.3163 m, RMSE: 0.5911 m, $R^2 = 0.5722$, Bias: -0.0325 m.
   - *Tournament Disclosure*: In the initial validation tournament, Candidate 13 was Rank 1 (14 wins) and Candidate 15 was Rank 2 (13 wins); Candidate 9 was Rank 9 (6 wins).
   - *Selection Rationale*: Candidate 9 was retained under the certified operational decision framework, with valid diagnostics, a practical dependency set, stated availability, and disclosed trade-offs.
7. **Persistence Trade-off**:
   - On 472 validation dates, Candidate 9 MAE (0.3163 m) vs Persistence (0.1643 m). Persistence is superior in flat baseflow; Candidate 9 provides dynamic responsiveness during rainfall surges.
8. **Event & Critical-Day Trade-off**:
   - On 62 exact-common critical-union dates in 2024-2025: Candidate 9 achieves **lower MAE** (0.7215 m vs 0.7672 m) and **lower RMSE** (0.9154 m vs 0.9457 m) compared to Candidate 14.
   - On rapid-rise-only dates ($N=27$), Candidate 14 has slightly lower RMSE (1.2402 m vs 1.2480 m).
9. **Availability and Fallback**:
   - Retrospective Availability: 617 / 681 observed days (90.60%). 64 days unavailable due to in-situ sensor telemetry gaps.
   - Fallback Rule: If Boso-Boso rain is missing but Sto. Niño lags exist, fallback to AR2; if `Sto_t_1` missing, return null.
10. **Known Limitations**:
    - Extreme surge underestimation during rapid typhoons (e.g. Typhoon Crising 2025 peak of 18.60 m predicted at 13.79 m). Sirens must remain strictly triggered by live sensor readings.
11. **Authoritative Evidence Paths**:
    - Canonical ZIP: `02_STO_NINO/01_CANONICAL_PACKAGE/FLOODGUARD_STO_NINO_CANDIDATE9_FINAL_DEFENSE_CERTIFIED_R2.zip`
    - Reconciled Defense PDF: `02_STO_NINO/10_DEFENSE_RECORD/FLOODGUARD_STO_NINO_COMPLETE_DEFENSE_RECORD_R3_RECONCILED.pdf`
    - Event Sensitivity CSV: `02_STO_NINO/07_EVENT_AND_CRITICAL_SENSITIVITY/STO_NINO_EVENT_SENSITIVITY_AUDIT_R1.csv`
    - Event Sensitivity Report: `02_STO_NINO/07_EVENT_AND_CRITICAL_SENSITIVITY/STO_NINO_EVENT_SENSITIVITY_REPORT_R1.md`
