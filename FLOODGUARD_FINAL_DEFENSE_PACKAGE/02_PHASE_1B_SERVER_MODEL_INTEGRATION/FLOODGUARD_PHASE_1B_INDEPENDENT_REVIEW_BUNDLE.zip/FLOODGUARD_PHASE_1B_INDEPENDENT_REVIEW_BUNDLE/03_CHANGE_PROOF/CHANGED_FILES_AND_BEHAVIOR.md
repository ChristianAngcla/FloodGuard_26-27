# FloodGuard Phase 1B Changed Files & Behavior Specification

## 1. Summary of Changes
Phase 1B refactored the FloodGuard server from a flawed universal 8-variable Phase A model with synthetic 24-hour linear interpolation into a certified, immutable station model registry and truthful daily forecast service.

## 2. File-by-File Change Inventory

### A. [NEW] `server/config/stationModelRegistry.js`
- **Purpose**: Single authoritative source of truth for the 3 frozen station OLS equations (Sto. Niño Candidate 9, Nangka Candidate 4, Tumana Candidate 8).
- **Behavior**: Provides frozen coefficients, required lag definitions, threshold configurations, and pure OLS evaluation methods with strict fallback handling.

### B. [NEW] `server/services/dailyForecastService.js`
- **Purpose**: Evaluates daily forecasts for all three stations based on live/daily telemetry inputs.
- **Behavior**: Outputs typed station forecast objects with calculationMode (`primary_model`, `persistence_fallback`, `unavailable`), targetSemantics, inputsUsed, and missingInputs.

### C. [MODIFY] `server/services/predictionEngine.js`
- **Before**: 
  - Executed generic 8-variable Phase A model across all 5 rivers.
  - Generated fake 24-hour linear interpolation timeline between $Y_0$ and $Y_1$.
  - Called Open-Meteo API for weather variables in model design vector.
  - Used `rejectUnauthorized: false` for HTTPS.
- **After**:
  - Ingests Science Garden `rfday` ("Daily Sum 24hr") and Boso-Boso rainfall.
  - Delegates prediction calculation to `dailyForecastService.js`.
  - Sets `timeline: []` (truthful empty array, eliminating fake 24-hour hydrographs).
  - Decouples Open-Meteo from active forecast calculation.
  - Removes `rejectUnauthorized: false` to enforce strict TLS validation.

### D. [NEW] `server/tests/phase1b_tests.mjs`
- **Purpose**: Automated verification test suite for formula parity, fallback rules, unavailable inputs, TLS security, and output schema.
