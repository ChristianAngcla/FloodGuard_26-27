# FloodGuard Phase 1B Review Scope

**Phase**: Phase 1B (Certified Server-Side Model Registry & Truthful Daily Forecast API)
**Target Component**: `FloodGuard-Website/server`
**Authority**: `FLOODGUARD_FINAL_CANONICAL_EVIDENCE_R1_1_DOCUMENTATION_REPAIRED.zip` (SHA-256: `f66867e643e5552ad811ccd2add0468c30c6e4bc2e82bdd9450a66286577975b`)

## Scope Boundaries
- **IN SCOPE**:
  1. Immutable Server Station Model Registry (`server/config/stationModelRegistry.js`).
  2. Truthful Daily Forecast Service (`server/services/dailyForecastService.js`).
  3. Updating telemetry ingestion for Science Garden `rfday` and Mt. Boso-Boso rainfall (`server/services/predictionEngine.js`).
  4. Updating `GET /api/status` response schema and removing fake 24-hour linear interpolation.
  5. Enforcing strict TLS certificate validation (`rejectUnauthorized: true`).
  6. Automated test suite (`server/tests/phase1b_tests.mjs`).
- **STRICTLY OUT OF SCOPE (UNCHANGED)**:
  1. Web frontend and Flutter mobile applications.
  2. Firebase Cloud Messaging (FCM) push dispatch loops.
  3. Database models and MongoDB schemas.
  4. Admin training and calibration UI.
  5. Canonical research evidence, Excel workbooks, and raw data archives.
