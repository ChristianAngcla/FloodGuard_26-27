/**
 * FloodGuard Truthful Daily Forecast Service
 * 
 * Evaluates the three certified station models (Sto. Niño C9, Nangka C4, Tumana C8)
 * using deterministic OLS formulas and strict fallback rules.
 */

import { STATION_MODEL_REGISTRY } from '../config/stationModelRegistry.js';

const getStatusLabel = (wl, thresholds) => {
    if (!thresholds || !Number.isFinite(wl)) return 'UNMAPPED_DAILY_OBSERVATION';
    if (wl >= thresholds.critical) return 'CRITICAL';
    if (wl >= thresholds.alarm) return 'WARNING';
    if (wl >= thresholds.alert) return 'ALERT';
    return 'SAFE';
};

const getPstDates = () => {
    // Current time in Asia/Manila (PST: UTC+8)
    const now = new Date();
    const pstOffsetMs = 8 * 3600 * 1000;
    const pstNow = new Date(now.getTime() + (now.getTimezoneOffset() * 60 * 1000) + pstOffsetMs);

    const pad = (n) => String(n).padStart(2, '0');
    const toYmd = (d) => `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`;

    const todayYmd = toYmd(pstNow);
    const yesterday = new Date(pstNow.getTime() - 24 * 3600 * 1000);
    const yesterdayYmd = toYmd(yesterday);

    return {
        sourceDataDate: yesterdayYmd,
        forecastTargetDate: todayYmd,
    };
};

/**
 * Evaluates daily forecasts for all three certified stations.
 * 
 * @param {Object} telemetry - Current sensor state and rainfall readings.
 * @returns {Object} Structured station forecasts and overall status.
 */
export const evaluateDailyForecasts = (telemetry = {}) => {
    const {
        sensors = {},
        upstreamRain = {},
        history = [],
        customDates = null,
    } = telemetry;

    const { sourceDataDate, forecastTargetDate } = customDates || getPstDates();

    // 1. Sto. Niño Inputs (Candidate 9: AR2 + Boso-Boso Rain)
    const sto_t_1 = Number.isFinite(sensors.sto_nino) ? sensors.sto_nino : null;
    // For lag 3, look back in sliding history buffer if present, else fallback to lag 1
    const sto_t_3 = (history.length >= 3 && Number.isFinite(history[history.length - 3]?.sto_nino))
        ? history[history.length - 3].sto_nino
        : sto_t_1;
    const bosoboso_t_1 = Number.isFinite(upstreamRain.boso_boso_rfday)
        ? upstreamRain.boso_boso_rfday
        : (Number.isFinite(upstreamRain.boso_boso) ? upstreamRain.boso_boso : null);

    const stoEval = STATION_MODEL_REGISTRY.sto_nino.evaluate({
        sto_t_1,
        sto_t_3,
        bosoboso_t_1,
    });

    const stoStatus = getStatusLabel(stoEval.predictedWaterLevel, STATION_MODEL_REGISTRY.sto_nino.thresholds);

    const stoForecast = {
        stationId: STATION_MODEL_REGISTRY.sto_nino.stationId,
        stationName: STATION_MODEL_REGISTRY.sto_nino.stationName,
        sourceDataDate,
        forecastTargetDate,
        predictedWaterLevel: stoEval.predictedWaterLevel,
        unit: STATION_MODEL_REGISTRY.sto_nino.unit,
        selectedCandidate: STATION_MODEL_REGISTRY.sto_nino.selectedCandidate,
        modelVersion: STATION_MODEL_REGISTRY.sto_nino.modelVersion,
        calculationMode: stoEval.calculationMode,
        fallbackReason: stoEval.fallbackReason,
        targetSemantics: STATION_MODEL_REGISTRY.sto_nino.targetSemantics,
        statusBand: stoStatus,
        status: stoStatus,
        thresholds: STATION_MODEL_REGISTRY.sto_nino.thresholds,
        thresholdMappingAllowed: STATION_MODEL_REGISTRY.sto_nino.thresholdMappingAllowed,
        inputsUsed: stoEval.inputsUsed,
        missingInputs: stoEval.missingInputs,
    };

    // 2. Nangka Inputs (Candidate 4: AR1 + Boso-Boso Rain)
    const nangka_wl_t_1 = Number.isFinite(sensors.nangka) ? sensors.nangka : null;

    const nangkaEval = STATION_MODEL_REGISTRY.nangka.evaluate({
        nangka_wl_t_1,
        bosoboso_t_1,
    });

    const nangkaStatus = getStatusLabel(nangkaEval.predictedWaterLevel, STATION_MODEL_REGISTRY.nangka.thresholds);

    const nangkaForecast = {
        stationId: STATION_MODEL_REGISTRY.nangka.stationId,
        stationName: STATION_MODEL_REGISTRY.nangka.stationName,
        sourceDataDate,
        forecastTargetDate,
        predictedWaterLevel: nangkaEval.predictedWaterLevel,
        unit: STATION_MODEL_REGISTRY.nangka.unit,
        selectedCandidate: STATION_MODEL_REGISTRY.nangka.selectedCandidate,
        modelVersion: STATION_MODEL_REGISTRY.nangka.modelVersion,
        calculationMode: nangkaEval.calculationMode,
        fallbackReason: nangkaEval.fallbackReason,
        targetSemantics: STATION_MODEL_REGISTRY.nangka.targetSemantics,
        statusBand: nangkaStatus,
        status: nangkaStatus,
        thresholds: STATION_MODEL_REGISTRY.nangka.thresholds,
        thresholdMappingAllowed: STATION_MODEL_REGISTRY.nangka.thresholdMappingAllowed,
        inputsUsed: nangkaEval.inputsUsed,
        missingInputs: nangkaEval.missingInputs,
    };

    // 3. Tumana Inputs (Candidate 8: AR1 + Science Garden Rain)
    const tumana_wl_t_1 = Number.isFinite(sensors.tumana) ? sensors.tumana : null;
    const pagasa_sg_rain_t_1 = Number.isFinite(upstreamRain.science_garden_rfday)
        ? upstreamRain.science_garden_rfday
        : (Number.isFinite(upstreamRain.science_garden) ? upstreamRain.science_garden : null);

    const tumanaEval = STATION_MODEL_REGISTRY.tumana.evaluate({
        tumana_wl_t_1,
        pagasa_sg_rain_t_1,
    });

    const tumanaForecast = {
        stationId: STATION_MODEL_REGISTRY.tumana.stationId,
        stationName: STATION_MODEL_REGISTRY.tumana.stationName,
        sourceDataDate,
        forecastTargetDate,
        predictedWaterLevel: tumanaEval.predictedWaterLevel,
        unit: STATION_MODEL_REGISTRY.tumana.unit,
        selectedCandidate: STATION_MODEL_REGISTRY.tumana.selectedCandidate,
        modelVersion: STATION_MODEL_REGISTRY.tumana.modelVersion,
        calculationMode: tumanaEval.calculationMode,
        fallbackReason: tumanaEval.fallbackReason,
        targetSemantics: STATION_MODEL_REGISTRY.tumana.targetSemantics,
        statusBand: 'UNMAPPED_DAILY_OBSERVATION',
        status: 'SAFE', // Safe categorical fallback for UI consumption
        thresholds: null,
        thresholdMappingAllowed: false,
        inputsUsed: tumanaEval.inputsUsed,
        missingInputs: tumanaEval.missingInputs,
    };

    const stations = {
        sto_nino: stoForecast,
        nangka: nangkaForecast,
        tumana: tumanaForecast,
    };

    // Overall Status across threshold-mapped stations only (Sto. Niño & Nangka)
    const activeStatuses = [stoStatus, nangkaStatus];
    let overall_status = 'SAFE';
    if (activeStatuses.includes('CRITICAL')) overall_status = 'CRITICAL';
    else if (activeStatuses.includes('WARNING')) overall_status = 'WARNING';
    else if (activeStatuses.includes('ALERT')) overall_status = 'ALERT';

    return {
        stations,
        overall_status,
        sourceDataDate,
        forecastTargetDate,
    };
};
