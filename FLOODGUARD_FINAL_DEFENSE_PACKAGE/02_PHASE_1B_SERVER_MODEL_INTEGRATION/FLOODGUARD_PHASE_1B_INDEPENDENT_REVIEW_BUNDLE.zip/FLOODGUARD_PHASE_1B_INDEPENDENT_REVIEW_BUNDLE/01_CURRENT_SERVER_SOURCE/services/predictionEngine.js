import axios from 'axios';
import mongoose from 'mongoose';
import https from 'https';
import { evaluateDailyForecasts } from './dailyForecastService.js';
import { STATION_MODEL_REGISTRY } from '../config/stationModelRegistry.js';

// Secure HTTPS agent with standard TLS validation enabled
const pagasaHttpsAgent = new https.Agent({ keepAlive: true });

// --- CONFIGURATION ---
const PAGASA_WATER_API = "https://pasig-marikina-tullahanffws.pagasa.dost.gov.ph/water/map_list.do";
const PAGASA_RAIN_API = "https://pasig-marikina-tullahanffws.pagasa.dost.gov.ph/rainfall/map_list.do";
const PARSER_API = "https://pagasa.chlod.net/api/v1/bulletin/list";

const STATION_MAP = {
    "Sto Nino": "sto_nino",
    "Nangka": "nangka",
    "Tumana Bridge": "tumana",
    "Montalban": "montalban",
    "Rosario": "rosario",
};

// Global Memory for Time-Series (SLIDING WINDOW)
export const CACHE = {
    current_sensors: { 
        sto_nino: 13.0, 
        nangka: 15.9,
        tumana: 12.0, 
        montalban: 21.9,
        rosario: 11.4 
    },
    upstream_rainfall: {
        mt_campana: 0.0,
        boso_boso: 0.0,
        boso_boso_rfday: 0.0,
        mt_aries: 0.0,
        mt_oro: 0.0,
        nangka_rf: 0.0,
        science_garden: 0.0,
        science_garden_rfday: 0.0,
        weighted_total: 0.0
    },
    thresholds: {
        sto_nino: { alert: 15.00, alarm: 16.00, critical: 17.00 },
        nangka: { alert: 16.50, alarm: 17.10, critical: 17.70 },
        tumana: { alert: 17.26, alarm: 18.26, critical: 19.26 },
        montalban: { alert: 22.40, alarm: 23.00, critical: 23.60 },
        rosario: { alert: 13.00, alarm: 14.00, critical: 15.00 },
    },
    history: [], // Keep last 6 readings
    storm: {
        name: "None", category: "No Active Tropical Cyclone",
        center: "--", movement: "--", signal: 0, status_encoded: 0
    },
    weather: {
        source: "PAGASA_FFWS_TELEMETRY",
        precipitation: 0.0, weather_code: 0, status_encoded: 0,
        temperature: 0.0, humidity: 0.0, heat_index: 0.0, wind_speed: 0.0
    },
    simulation_mode: false,
    // Last auto-alert status per river (SAFE/ALERT/WARNING/CRITICAL)
    last_auto_alert: {
        sto_nino: "SAFE",
        nangka: "SAFE",
        tumana: "SAFE",
        montalban: "SAFE",
        rosario: "SAFE",
    },
};

export const invalidateCoefficientCache = () => {
    // Certified models are frozen in stationModelRegistry.js
};

// --- DATA FETCHERS ---

const fetchMarikina = async () => {
    try {
        const pstDate = new Date(Date.now() + 8 * 3600000 - 1200000);
        const ymdhm = pstDate.toISOString().replace(/\D/g, '').slice(0, 11) + '0';
        const ts = Date.now();
        const url = `${PAGASA_WATER_API}?ymdhm=${ymdhm}&basin=&_=${ts}`;
        
        const response = await axios.get(url, { timeout: 10000, httpsAgent: pagasaHttpsAgent });
        const stations = response.data;

        const defaults = { sto_nino: 13.0, nangka: 15.9, tumana: 12.0, montalban: 21.9, rosario: 11.4 };
        const results = { ...CACHE.current_sensors };
        const thresholds = { ...CACHE.thresholds };

        stations.forEach(station => {
            const key = STATION_MAP[station.obsnm];
            if (key) {
                const rawWl = station.wl == null ? "" : String(station.wl);
                const isSuspect = /\(\*\)|\*/.test(rawWl);
                const parseWl = (val) => {
                    if (val == null || val === "") return null;
                    const n = parseFloat(String(val).replace("(*)", "").replace("*", "").trim());
                    return Number.isFinite(n) ? n : null;
                };

                const alert = parseWl(station.alertwl);
                const alarm = parseWl(station.alarmwl);
                const critical = parseWl(station.criticalwl);
                if (alert && alarm && critical) {
                    thresholds[key] = { alert, alarm, critical };
                }

                const stationCritical =
                    thresholds[key]?.critical ??
                    CACHE.thresholds[key]?.critical ??
                    null;
                const baseline = defaults[key];
                let previous_wl = CACHE.current_sensors[key] ?? baseline;

                if (
                    stationCritical != null &&
                    Number.isFinite(previous_wl) &&
                    previous_wl > stationCritical + 2.5
                ) {
                    console.warn(
                        `[!] Poisoned cache for ${key}: ${previous_wl}m > critical+2.5 (${stationCritical}). Resetting to ${baseline}m.`
                    );
                    previous_wl = baseline;
                    results[key] = baseline;
                }

                if (isSuspect) {
                    console.warn(`[!] Suspect PAGASA reading for ${key}: "${rawWl}" — keeping previous/default.`);
                    results[key] = previous_wl;
                } else {
                    const wl = parseWl(rawWl);
                    if (wl !== null && wl >= 0 && wl <= 30.0) {
                        const implausibleVsCritical =
                            stationCritical != null && wl > stationCritical + 2.5;
                        const extremeJump = Math.abs(wl - previous_wl) > 5.0;

                        if (implausibleVsCritical) {
                            console.warn(
                                `[!] Implausible PAGASA reading for ${key}: ${wl}m exceeds critical ${stationCritical}m by >2.5m. Rejecting.`
                            );
                            results[key] = previous_wl;
                        } else if (extremeJump) {
                            console.warn(
                                `[!] HARDWARE GLITCH DETECTED at ${key}: jump from ${previous_wl}m to ${wl}m. Rejecting data.`
                            );
                            results[key] = previous_wl;
                        } else {
                            results[key] = wl;
                        }
                    }
                }
            }
        });
        return { results, thresholds };
    } catch (e) {
        console.warn("[!] PAGASA Water API fetch failed, using cached values:", e.message);
        return { results: CACHE.current_sensors, thresholds: CACHE.thresholds };
    }
};

const fetchUpstreamRainfall = async () => {
    try {
        const pstDate = new Date(Date.now() + 8 * 3600000 - 1200000);
        const ymdhm = pstDate.toISOString().replace(/\D/g, '').slice(0, 11) + '0';
        const ts = Date.now();
        const url = `${PAGASA_RAIN_API}?ymdhm=${ymdhm}&basin=&_=${ts}`;
        
        const response = await axios.get(url, { timeout: 10000, httpsAgent: pagasaHttpsAgent });
        const stations = response.data;

        const rfData = {
            mt_campana: 0.0,
            boso_boso: 0.0,
            boso_boso_rfday: 0.0,
            mt_aries: 0.0,
            mt_oro: 0.0,
            nangka_rf: 0.0,
            science_garden: 0.0,
            science_garden_rfday: 0.0,
            weighted_total: 0.0
        };

        stations.forEach(st => {
            const rf = parseFloat(st.rf1hr || st.rf10m || st.rf || 0.0);
            const rfday = parseFloat(st.rfday || 0.0);

            if (st.obsnm === 'Mt. Campana') rfData.mt_campana = rf;
            if (st.obsnm === 'Boso Boso') {
                rfData.boso_boso = rf;
                rfData.boso_boso_rfday = rfday;
            }
            if (st.obsnm === 'Mt. Aries') rfData.mt_aries = rf;
            if (st.obsnm === 'Mt. Oro') rfData.mt_oro = rf;
            if (st.obsnm === 'Nangka') rfData.nangka_rf = rf;
            if (st.obsnm === 'Science Garden' || String(st.obscd) === '11203101') {
                rfData.science_garden = rf;
                rfData.science_garden_rfday = rfday;
            }
        });

        // Hydrological Spatial Weighting for monitoring overview
        rfData.weighted_total = (
            0.25 * rfData.mt_campana +
            0.25 * rfData.boso_boso +
            0.20 * rfData.mt_oro +
            0.15 * rfData.mt_aries +
            0.15 * rfData.nangka_rf
        );

        return rfData;
    } catch (e) {
        console.warn("[!] PAGASA Upstream Rain API fetch failed, using cached values:", e.message);
        return CACHE.upstream_rainfall;
    }
};

const getStormContext = async () => {
    try {
        const response = await axios.get(PARSER_API, { timeout: 10000 });
        const data = response.data;
        const latest = (data.bulletins && data.bulletins.length > 0) ? data.bulletins[0] : data;
        const cycloneData = latest.cyclone || {};

        if (!cycloneData.name) {
            return { name: "None", category: "No Active Tropical Cyclone", center: "--", movement: "--", signal: 0, status_encoded: 0 };
        }

        const localName = cycloneData.name || '';
        const intName = cycloneData.internationalName || '';
        const name = intName ? `${localName} ${intName}` : localName;
        
        let highestSignal = 0;
        if (latest.signals) {
            Object.keys(latest.signals).forEach(sig => {
                const s = parseInt(sig);
                if (!isNaN(s) && s > highestSignal) highestSignal = s;
            });
        }

        return {
            name,
            category: cycloneData.category || "Unknown Category",
            center: cycloneData.center?.lat ? `${cycloneData.center.lat}°N, ${cycloneData.center.lon}°E` : "--",
            movement: cycloneData.movement || "--",
            signal: highestSignal,
            status_encoded: highestSignal > 0 ? 3 : 0
        };
    } catch (e) {
        console.warn("[!] Storm parser failed:", e.message);
        return { name: "None", category: "No Active Tropical Cyclone", center: "--", movement: "--", signal: 0, status_encoded: 0 };
    }
};

const getLegacyStatusLabel = (wl, alert, alarm, critical) => {
    if (!Number.isFinite(wl)) return "SAFE";
    if (critical != null && wl >= critical) return "CRITICAL";
    if (alarm != null && wl >= alarm) return "WARNING";
    if (alert != null && wl >= alert) return "ALERT";
    return "SAFE";
};

/**
 * Computes deterministic daily predictions using the certified station models.
 * Replaces the uncertified universal Phase A model and synthetic 24h timeline.
 */
export const computePredictions = async () => {
    let sensors = { ...CACHE.current_sensors };
    let upstreamRain = { ...CACHE.upstream_rainfall };
    let storm = { ...CACHE.storm };
    let weather = { ...CACHE.weather };
    let thresholds = { ...CACHE.thresholds };

    if (CACHE.simulation_mode) {
        sensors = { sto_nino: 15.8, nangka: 16.5, tumana: 16.5, montalban: 22.5, rosario: 13.5 };
        upstreamRain = {
            mt_campana: 45.0,
            boso_boso: 50.0,
            boso_boso_rfday: 50.0,
            mt_aries: 40.0,
            mt_oro: 55.0,
            nangka_rf: 35.0,
            science_garden: 80.0,
            science_garden_rfday: 80.0,
            weighted_total: 46.25
        };
        storm = { name: "TYPHOON (TEST SIMULATION)", category: "Super Typhoon", center: "14.6°N, 121.1°E", movement: "Westward 20km/h", signal: 4, status_encoded: 3 };
        weather = { source: "SIMULATION", precipitation: 85.5, weather_code: 95, status_encoded: 3, temperature: 26.0, humidity: 90.0, heat_index: 28.0, wind_speed: 40.0 };
    }

    // Evaluate the 3 certified station daily forecast models
    const forecastResult = evaluateDailyForecasts({
        sensors,
        upstreamRain,
        history: CACHE.history,
    });

    const river_forecasts = {};

    // 1. Certified Stations: Sto. Niño, Nangka, Tumana
    for (const [stKey, stForecast] of Object.entries(forecastResult.stations)) {
        river_forecasts[stKey] = {
            stationId: stForecast.stationId,
            stationName: stForecast.stationName,
            sourceDataDate: stForecast.sourceDataDate,
            forecastTargetDate: stForecast.forecastTargetDate,
            predictedWaterLevel: stForecast.predictedWaterLevel,
            predicted_water_level: stForecast.predictedWaterLevel, // Backward compatibility
            unit: stForecast.unit,
            selectedCandidate: stForecast.selectedCandidate,
            modelVersion: stForecast.modelVersion,
            calculationMode: stForecast.calculationMode,
            fallbackReason: stForecast.fallbackReason,
            targetSemantics: stForecast.targetSemantics,
            statusBand: stForecast.statusBand,
            status: stForecast.status,
            thresholds: stForecast.thresholds || thresholds[stKey] || null,
            thresholdMappingAllowed: stForecast.thresholdMappingAllowed,
            inputsUsed: stForecast.inputsUsed,
            missingInputs: stForecast.missingInputs,
            time_series_insights: {
                trend: "Daily Forecast",
                rate_of_change_m_per_h: 0.0,
                eta_to_alert: "N/A (Daily Forecast)",
                eta_to_warning: "N/A (Daily Forecast)",
                eta_to_critical: "N/A (Daily Forecast)",
                peak_predicted_level: stForecast.predictedWaterLevel ?? sensors[stKey] ?? 0.0,
                peak_expected_time: stForecast.forecastTargetDate,
                one_step_predicted_level: stForecast.predictedWaterLevel ?? sensors[stKey] ?? 0.0,
            }
        };
    }

    // 2. Legacy Stations (Montalban, Rosario) - Read-only status, no certified forecast
    const legacyRivers = ["montalban", "rosario"];
    legacyRivers.forEach((river) => {
        const thr = thresholds[river];
        const currentWl = sensors[river] ?? 0.0;
        const legacyStatus = getLegacyStatusLabel(currentWl, thr?.alert, thr?.alarm, thr?.critical);
        river_forecasts[river] = {
            stationId: river,
            stationName: river.charAt(0).toUpperCase() + river.slice(1),
            sourceDataDate: forecastResult.sourceDataDate,
            forecastTargetDate: forecastResult.forecastTargetDate,
            predictedWaterLevel: currentWl,
            predicted_water_level: currentWl,
            unit: "m",
            selectedCandidate: "LEGACY_UNMONITORED",
            modelVersion: "1.0.0-LEGACY",
            calculationMode: "unavailable",
            fallbackReason: "Legacy station without certified OLS tournament model; displaying live telemetry only.",
            targetSemantics: "Instantaneous Telemetry Reading",
            statusBand: legacyStatus,
            status: legacyStatus,
            thresholds: thr,
            thresholdMappingAllowed: false,
            inputsUsed: { live_wl: currentWl },
            missingInputs: ["Certified_Model_Equation"],
            time_series_insights: {
                trend: "Live Observation",
                rate_of_change_m_per_h: 0.0,
                eta_to_alert: "N/A (Legacy)",
                eta_to_warning: "N/A (Legacy)",
                eta_to_critical: "N/A (Legacy)",
                peak_predicted_level: currentWl,
                peak_expected_time: "Now",
                one_step_predicted_level: currentWl,
            }
        };
    });

    return {
        stations: forecastResult.stations,
        live_sensors: sensors,
        upstream_rainfall: upstreamRain,
        thresholds,
        storm,
        weather,
        prediction: {
            overall_status: forecastResult.overall_status,
            rivers: river_forecasts,
            timeline: [], // Truthful empty timeline - zero fake linear interpolation
        }
    };
};

export const runBackgroundSync = async () => {
    console.log(`[*] Syncing PAGASA Live Telemetry... ${new Date().toLocaleTimeString()}`);
    const { results: sensors, thresholds } = await fetchMarikina();
    const upstreamRain = await fetchUpstreamRainfall();

    CACHE.current_sensors = sensors;
    CACHE.upstream_rainfall = upstreamRain;
    CACHE.thresholds = thresholds;
    CACHE.storm = await getStormContext();

    CACHE.history.push(sensors);
    if (CACHE.history.length > 6) {
        CACHE.history.shift();
    }
};
