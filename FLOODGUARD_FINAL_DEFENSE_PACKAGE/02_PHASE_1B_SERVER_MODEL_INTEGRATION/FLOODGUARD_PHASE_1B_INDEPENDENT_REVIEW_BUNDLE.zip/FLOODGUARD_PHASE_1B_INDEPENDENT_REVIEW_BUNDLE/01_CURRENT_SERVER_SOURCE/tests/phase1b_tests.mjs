/**
 * FloodGuard Phase 1B Automated Test Suite
 * 
 * Tests:
 * 1. Sto. Niño C9, Nangka C4, Tumana C8 exact coefficient parity tests.
 * 2. Tumana Candidate 8 as primary MLR model when Science Garden rfday is present.
 * 3. Tumana True Persistence fallback when Science Garden rfday is missing and Tumana_WL_t_1 exists.
 * 4. Missing required in-situ water level returns unavailable/null.
 * 5. No Open-Meteo dependency in daily forecast evaluation path.
 * 6. No synthetic hourly timeline returned (timeline is empty array).
 * 7. Zero occurrences of rejectUnauthorized: false in server source code.
 */

import { STATION_MODEL_REGISTRY } from '../config/stationModelRegistry.js';
import { evaluateDailyForecasts } from '../services/dailyForecastService.js';
import { computePredictions } from '../services/predictionEngine.js';
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const results = [];

function assert(condition, message) {
    if (!condition) {
        throw new Error(message);
    }
}

function check(name, fn) {
    try {
        fn();
        results.push({ name, pass: true });
        console.log(`[PASS] ${name}`);
    } catch (e) {
        results.push({ name, pass: false, error: e.message });
        console.error(`[FAIL] ${name}: ${e.message}`);
    }
}

async function checkAsync(name, fn) {
    try {
        await fn();
        results.push({ name, pass: true });
        console.log(`[PASS] ${name}`);
    } catch (e) {
        results.push({ name, pass: false, error: e.message });
        console.error(`[FAIL] ${name}: ${e.message}`);
    }
}

console.log('====================================================');
console.log('FLOODGUARD PHASE 1B: AUTOMATED VERIFICATION SUITE');
console.log('====================================================\n');

// 1. STO. NIÑO CANDIDATE 9 PARITY TEST
check('1.1 Sto. Niño C9 Formula Parity (Normal Operation)', () => {
    // Given Sto_t_1 = 13.50, Sto_t_3 = 13.00, BosoBoso_t_1 = 25.0
    // Expected: 3.5458516105979454 + 0.464199760356257*(13.50) + 0.24569344143377558*(13.00) + 0.011525049019977172*(25.0) = 13.294689 m -> 13.29 m
    const result = STATION_MODEL_REGISTRY.sto_nino.evaluate({
        sto_t_1: 13.50,
        sto_t_3: 13.00,
        bosoboso_t_1: 25.0,
    });
    assert(result.calculationMode === 'primary_model', `Expected primary_model, got ${result.calculationMode}`);
    assert(result.predictedWaterLevel === 13.29, `Expected 13.29, got ${result.predictedWaterLevel}`);
    assert(result.inputsUsed.Sto_t_1 === 13.50, 'InputsUsed Sto_t_1 mismatch');
    assert(result.inputsUsed.Sto_t_3 === 13.00, 'InputsUsed Sto_t_3 mismatch');
    assert(result.inputsUsed.BosoBoso_t_1 === 25.0, 'InputsUsed BosoBoso_t_1 mismatch');
});

check('1.2 Sto. Niño C9 Persistence Fallback (Missing Rain)', () => {
    const result = STATION_MODEL_REGISTRY.sto_nino.evaluate({
        sto_t_1: 14.20,
        sto_t_3: 13.80,
        bosoboso_t_1: null,
    });
    assert(result.calculationMode === 'persistence_fallback', `Expected persistence_fallback, got ${result.calculationMode}`);
    assert(result.predictedWaterLevel === 14.20, `Expected 14.20, got ${result.predictedWaterLevel}`);
    assert(result.missingInputs.includes('BosoBoso_t_1'), 'Missing inputs should contain BosoBoso_t_1');
});

// 2. NANGKA CANDIDATE 4 PARITY TEST
check('2.1 Nangka C4 Formula Parity (From Canonical Parity CSV Test 02)', () => {
    // Input: Nangka_WL_t_1 = 15.84, BosoBoso_Rain_t_1 = 25.5
    // Canonical Expected: 16.121060816077048 -> 16.12 m
    const result = STATION_MODEL_REGISTRY.nangka.evaluate({
        nangka_wl_t_1: 15.84,
        bosoboso_t_1: 25.5,
    });
    assert(result.calculationMode === 'primary_model', `Expected primary_model, got ${result.calculationMode}`);
    assert(result.predictedWaterLevel === 16.12, `Expected 16.12, got ${result.predictedWaterLevel}`);
    assert(result.inputsUsed.Nangka_WL_t_1 === 15.84, 'InputsUsed Nangka_WL_t_1 mismatch');
    assert(result.inputsUsed.BosoBoso_t_1 === 25.5, 'InputsUsed BosoBoso_t_1 mismatch');
});

check('2.2 Nangka C4 Persistence Fallback (Missing Rain)', () => {
    const result = STATION_MODEL_REGISTRY.nangka.evaluate({
        nangka_wl_t_1: 16.35,
        bosoboso_t_1: null,
    });
    assert(result.calculationMode === 'persistence_fallback', `Expected persistence_fallback, got ${result.calculationMode}`);
    assert(result.predictedWaterLevel === 16.35, `Expected 16.35, got ${result.predictedWaterLevel}`);
});

// 3. TUMANA CANDIDATE 8 PARITY TEST & PRIMARY MODEL ENFORCEMENT
check('3.1 Tumana C8 Formula Parity (From Canonical Parity CSV Test 02)', () => {
    // Input: Tumana_WL_t_1 = 12.50, PAGASA_SG_Rain_t_1 = 15.0
    // Canonical Expected: 12.561251118850205 -> 12.56 m
    const result = STATION_MODEL_REGISTRY.tumana.evaluate({
        tumana_wl_t_1: 12.50,
        pagasa_sg_rain_t_1: 15.0,
    });
    assert(result.calculationMode === 'primary_model', `Expected primary_model, got ${result.calculationMode}`);
    assert(result.predictedWaterLevel === 12.56, `Expected 12.56, got ${result.predictedWaterLevel}`);
    assert(result.inputsUsed.Tumana_WL_t_1 === 12.50, 'InputsUsed Tumana_WL_t_1 mismatch');
    assert(result.inputsUsed.PAGASA_SG_Rain_t_1 === 15.0, 'InputsUsed PAGASA_SG_Rain_t_1 mismatch');
});

check('3.2 Tumana C8 Persistence Fallback (Missing Science Garden Rain)', () => {
    const result = STATION_MODEL_REGISTRY.tumana.evaluate({
        tumana_wl_t_1: 12.80,
        pagasa_sg_rain_t_1: null,
    });
    assert(result.calculationMode === 'persistence_fallback', `Expected persistence_fallback, got ${result.calculationMode}`);
    assert(result.predictedWaterLevel === 12.80, `Expected 12.80, got ${result.predictedWaterLevel}`);
    assert(result.missingInputs.includes('PAGASA_SG_Rain_t_1'), 'Missing inputs should contain PAGASA_SG_Rain_t_1');
});

check('3.3 Tumana Target Semantics & Threshold Mapping Restrictions', () => {
    const reg = STATION_MODEL_REGISTRY.tumana;
    assert(reg.targetSemantics === 'PAGASA-reported daily Tumana water-level observation', `Target semantics mismatch: ${reg.targetSemantics}`);
    assert(reg.thresholds === null, 'Tumana thresholds must be null');
    assert(reg.thresholdMappingAllowed === false, 'Tumana thresholdMappingAllowed must be false');
});

// 4. MISSING IN-SITU WATER LEVEL LAGS (UNAVAILABLE / NULL)
check('4.1 Sto. Niño Missing In-Situ WL Lag Returns Unavailable/Null', () => {
    const res1 = STATION_MODEL_REGISTRY.sto_nino.evaluate({ sto_t_1: null, sto_t_3: 13.0, bosoboso_t_1: 20.0 });
    assert(res1.calculationMode === 'unavailable', 'Expected unavailable');
    assert(res1.predictedWaterLevel === null, 'Expected null predicted level');

    const res3 = STATION_MODEL_REGISTRY.sto_nino.evaluate({ sto_t_1: 13.0, sto_t_3: null, bosoboso_t_1: 20.0 });
    assert(res3.calculationMode === 'unavailable', 'Expected unavailable for missing lag 3');
    assert(res3.predictedWaterLevel === null, 'Expected null predicted level for missing lag 3');
});

check('4.2 Nangka Missing In-Situ WL Lag Returns Unavailable/Null', () => {
    const res = STATION_MODEL_REGISTRY.nangka.evaluate({ nangka_wl_t_1: null, bosoboso_t_1: 20.0 });
    assert(res.calculationMode === 'unavailable', 'Expected unavailable');
    assert(res.predictedWaterLevel === null, 'Expected null predicted level');
});

check('4.3 Tumana Missing In-Situ WL Lag Returns Unavailable/Null', () => {
    const res = STATION_MODEL_REGISTRY.tumana.evaluate({ tumana_wl_t_1: null, pagasa_sg_rain_t_1: 20.0 });
    assert(res.calculationMode === 'unavailable', 'Expected unavailable');
    assert(res.predictedWaterLevel === null, 'Expected null predicted level');
});

// 5. DAILY FORECAST SERVICE & GET /api/status RESPONSE SHAPE
check('5.1 evaluateDailyForecasts Output Contract', () => {
    const output = evaluateDailyForecasts({
        sensors: { sto_nino: 13.45, nangka: 15.82, tumana: 12.30 },
        upstreamRain: { boso_boso_rfday: 18.5, science_garden_rfday: 42.0 },
    });

    assert(output.stations, 'Missing stations dictionary');
    assert(output.stations.sto_nino, 'Missing sto_nino forecast');
    assert(output.stations.nangka, 'Missing nangka forecast');
    assert(output.stations.tumana, 'Missing tumana forecast');

    const requiredKeys = [
        'stationId', 'stationName', 'sourceDataDate', 'forecastTargetDate',
        'predictedWaterLevel', 'unit', 'selectedCandidate', 'modelVersion',
        'calculationMode', 'fallbackReason', 'targetSemantics', 'inputsUsed', 'missingInputs'
    ];

    for (const [stId, st] of Object.entries(output.stations)) {
        for (const k of requiredKeys) {
            assert(k in st, `Station ${stId} missing required key: ${k}`);
        }
        assert(st.unit === 'm', `Station ${stId} unit must be 'm'`);
        assert(st.modelVersion === '2.0.0-CERTIFIED', `Station ${stId} modelVersion must be 2.0.0-CERTIFIED`);
    }

    assert(output.stations.tumana.calculationMode === 'primary_model', 'Tumana with valid SG rain should be primary_model');
    assert(output.stations.tumana.targetSemantics === 'PAGASA-reported daily Tumana water-level observation', 'Tumana target semantics mismatch');
});

await checkAsync('5.2 computePredictions Integrates Truthful Schema & Zero Fake Timeline', async () => {
    const res = await computePredictions();
    assert(res.stations, 'Missing top-level stations');
    assert(res.prediction?.rivers, 'Missing prediction.rivers');
    assert(Array.isArray(res.prediction.timeline), 'Timeline should be array');
    assert(res.prediction.timeline.length === 0, `Timeline must be empty array (no fake 24h interpolation), got length ${res.prediction.timeline.length}`);
    assert(res.stations.sto_nino.predictedWaterLevel !== undefined, 'Missing sto_nino predictedWaterLevel');
    assert(res.stations.nangka.predictedWaterLevel !== undefined, 'Missing nangka predictedWaterLevel');
    assert(res.stations.tumana.predictedWaterLevel !== undefined, 'Missing tumana predictedWaterLevel');
});

// 6. SECURITY & ARCHITECTURAL PURITY AUDIT
check('6.1 Zero Occurrences of rejectUnauthorized: false in Server Code', () => {
    const serverDir = path.resolve(__dirname, '..');
    const filesToScan = [
        path.join(serverDir, 'index.js'),
        path.join(serverDir, 'services', 'predictionEngine.js'),
        path.join(serverDir, 'services', 'dailyForecastService.js'),
        path.join(serverDir, 'services', 'modelTraining.js'),
        path.join(serverDir, 'config', 'stationModelRegistry.js'),
    ];

    for (const file of filesToScan) {
        if (fs.existsSync(file)) {
            const content = fs.readFileSync(file, 'utf-8');
            assert(!content.includes('rejectUnauthorized: false'), `Security violation: rejectUnauthorized: false found in ${file}`);
        }
    }
});

check('6.2 No Open-Meteo Ingestion in Active Daily Forecast Service', () => {
    const dailyForecastCode = fs.readFileSync(path.join(__dirname, '../services/dailyForecastService.js'), 'utf-8');
    const registryCode = fs.readFileSync(path.join(__dirname, '../config/stationModelRegistry.js'), 'utf-8');

    assert(!dailyForecastCode.includes('open-meteo'), 'dailyForecastService.js must not reference open-meteo');
    assert(!registryCode.includes('open-meteo'), 'stationModelRegistry.js must not reference open-meteo');
});

console.log('\n====================================================');
const passedCount = results.filter(r => r.pass).length;
console.log(`TEST SUMMARY: ${passedCount}/${results.length} PASSED`);
console.log('====================================================');

if (passedCount === results.length) {
    console.log('\nALL PHASE 1B VERIFICATION TESTS PASSED SUCCESSFULLY.');
    process.exit(0);
} else {
    console.error(`\nFAILED ${results.length - passedCount} TESTS.`);
    process.exit(1);
}
