# Science Garden Locked Operational Rule

FloodGuard uses the PAGASA Science Garden rfday / Daily Sum (24hr) field as the prior completed source-day rainfall input for Tumana Candidate 8. True persistence is used only when that telemetry field is genuinely missing or unavailable.

## Implementation Details
1. **Primary Model Trigger**:
   When `Tumana_WL_t_1` exists AND Science Garden `rfday` is valid numeric, execute Candidate 8:
   $$\widehat{\text{Tumana\_WL}}_t = 1.5147240224821763 + 0.8735442115350864 \cdot \text{Tumana}_{t-1} + 0.008481630145296813 \cdot \text{PAGASA\_SG\_Rain}_{t-1}$$
2. **Fallback Trigger**:
   When Science Garden `rfday` is null/missing/unavailable but `Tumana_WL_t_1` exists, return True Persistence:
   $$\widehat{\text{Tumana\_WL}}_t = \text{Tumana}_{t-1}$$
   with `calculationMode: "persistence_fallback"`.
3. **Unavailable Trigger**:
   When `Tumana_WL_t_1` is null/missing, return `null` with `calculationMode: "unavailable"`.
4. **Target Semantics**:
   Strictly `"PAGASA-reported daily Tumana water-level observation"`.
