# DOST-PAGASA Science Garden Telemetry Mapping Specification

**Target Station**: Science Garden Synoptic Station (Agham Road, Diliman, Quezon City)
**Official Station Code (`obscd`)**: `11203101`
**Official Station Name (`obsnm`)**: `Science Garden`
**Endpoint URL**: `https://pasig-marikina-tullahanffws.pagasa.dost.gov.ph/rainfall/map_list.do`

## Exact Ingestion Mapping

| Live Telemetry Field | Stated Display Label | Type | Destination Model Feature | Description |
|---|---|---|---|---|
| `obsnm` | Station Name | String | Station Matcher | Must equal `"Science Garden"` |
| `obscd` | Station Code | String | Station ID | Must equal `"11203101"` |
| `rfday` | Daily Sum (24hr) | Float (mm) | `PAGASA_SG_Rain_t_1` | Prior completed source-day 24-hour rainfall input for Tumana Candidate 8 |
| `rf1hr` | 1-Hour Rainfall | Float (mm) | Telemetry Monitoring | 1-hour rainfall volume |
| `rf` | 10-Min Rainfall | Float (mm) | Telemetry Monitoring | 10-minute instantaneous rainfall rate |
| `timestr` | Observation Time | String | Date/Time Stamp | Human-readable PST timestamp (`YYYY-MM-DD HH:mm`) |
| `ymdhm` | Observation Timestamp | String | Date/Time ID | 12-digit numeric PST timestamp (`YYYYMMDDHHmm`) |
