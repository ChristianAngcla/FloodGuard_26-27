/**
 * FloodGuard Phase 2 Sealed Closure Verification Suite
 * 
 * Comprehensive verification of:
 * 1. Frozen C9, C4, C8 parity and fallback rules (untouched).
 * 2. Test A: Separate water and rain source observation timestamps (boundary preservation).
 * 3. Test B: Cached rainfall is never persisted as raw observation.
 * 4. Test C: Exact rf1hr only for model rainfall (numeric 0.0 is valid zero, rf10m/rf never substituted).
 * 5. Test D: Source observation timestamp determines date & hour (midnight crossover).
 * 6. Test E: Strict Sto. Niño 24/24 hourly completeness (23 hours returns null).
 * 7. Test F: Strict Nangka 24/24 hourly completeness (23 hours returns null).
 * 8. Test G: Top-of-hour window selection [h:00, h:05] eliminates out-of-order & late polls.
 * 9. Test H: /api/status forecast source separation (live telemetry vs persisted forecast; Tumana peak_predicted_level: null).
 * 10. Test I: True End-to-End Production Pipeline Execution (RawTelemetry -> finalizeCalendarDayObservations -> DailyObservation -> getCompletedDailyInputs -> executeDailyForecastRun -> DailyForecast upsert idempotency).
 * 11. Security and schema audits: zero rejectUnauthorized: false, zero Open-Meteo in forecast path.
 */

import { STATION_MODEL_REGISTRY } from '../config/stationModelRegistry.js';
import { evaluateDailyForecasts } from '../services/dailyForecastService.js';
import { computePredictions, CACHE } from '../services/predictionEngine.js';
import {
    subtractCalendarDays,
    parsePstYmdhm,
    extractHourlyTopWindowObservations,
    aggregateCompleteHourlyWaterLevelMax,
    aggregateCompleteHourlyRainfallTotal,
    recordRawTelemetrySync,
    finalizeCalendarDayObservations,
    getCompletedDailyInputs,
    executeDailyForecastRun,
} from '../services/dailyPipelineService.js';
import { getMsUntilNext0700Pst } from '../services/dailyScheduler.js';
import { DailyObservation } from '../models/DailyObservation.js';
import { DailyForecast } from '../models/DailyForecast.js';
import { RawTelemetryReading } from '../models/RawTelemetryReading.js';
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const results = [];

function assert(condition, message) {
    if (!condition) {
        throw new Error(message);
    }
}

function check(name, fn) {
    try {
        fn();
        results.push({ name, pass: true });
        console.log(`[PASS] ${name}`);
    } catch (e) {
        results.push({ name, pass: false, error: e.message });
        console.error(`[FAIL] ${name}: ${e.message}`);
    }
}

async function checkAsync(name, fn) {
    try {
        await fn();
        results.push({ name, pass: true });
        console.log(`[PASS] ${name}`);
    } catch (e) {
        results.push({ name, pass: false, error: e.message });
        console.error(`[FAIL] ${name}: ${e.message}`);
    }
}

console.log('================================================================');
console.log('FLOODGUARD PHASE 2 SEALED CLOSURE VERIFICATION SUITE');
console.log('================================================================\n');

// 1. FROZEN MODEL FORMULA PARITY TESTS
check('1.1 Sto. Niño C9 Parity (Normal Operation)', () => {
    const result = STATION_MODEL_REGISTRY.sto_nino.evaluate({
        sto_t_1: 13.50,
        sto_t_3: 13.00,
        bosoboso_t_1: 25.0,
    });
    assert(result.calculationMode === 'primary_model', `Expected primary_model, got ${result.calculationMode}`);
    assert(result.predictedWaterLevel === 13.29, `Expected 13.29, got ${result.predictedWaterLevel}`);
});

check('1.2 Sto. Niño C9 Persistence Fallback (Missing Rain)', () => {
    const result = STATION_MODEL_REGISTRY.sto_nino.evaluate({
        sto_t_1: 14.20,
        sto_t_3: 13.80,
        bosoboso_t_1: null,
    });
    assert(result.calculationMode === 'persistence_fallback', `Expected persistence_fallback, got ${result.calculationMode}`);
    assert(result.predictedWaterLevel === 14.20, `Expected 14.20, got ${result.predictedWaterLevel}`);
});

check('2.1 Nangka C4 Parity (Normal Operation)', () => {
    const result = STATION_MODEL_REGISTRY.nangka.evaluate({
        nangka_wl_t_1: 15.84,
        bosoboso_t_1: 25.5,
    });
    assert(result.calculationMode === 'primary_model', `Expected primary_model, got ${result.calculationMode}`);
    assert(result.predictedWaterLevel === 16.12, `Expected 16.12, got ${result.predictedWaterLevel}`);
});

check('2.2 Nangka C4 Persistence Fallback (Missing Rain)', () => {
    const result = STATION_MODEL_REGISTRY.nangka.evaluate({
        nangka_wl_t_1: 16.35,
        bosoboso_t_1: null,
    });
    assert(result.calculationMode === 'persistence_fallback', `Expected persistence_fallback, got ${result.calculationMode}`);
    assert(result.predictedWaterLevel === 16.35, `Expected 16.35, got ${result.predictedWaterLevel}`);
});

check('3.1 Tumana C8 Parity (Normal Operation)', () => {
    const result = STATION_MODEL_REGISTRY.tumana.evaluate({
        tumana_wl_t_1: 12.50,
        pagasa_sg_rain_t_1: 15.0,
    });
    assert(result.calculationMode === 'primary_model', `Expected primary_model, got ${result.calculationMode}`);
    assert(result.predictedWaterLevel === 12.56, `Expected 12.56, got ${result.predictedWaterLevel}`);
});

check('3.2 Tumana C8 Persistence Fallback (Missing Science Garden Rain)', () => {
    const result = STATION_MODEL_REGISTRY.tumana.evaluate({
        tumana_wl_t_1: 12.80,
        pagasa_sg_rain_t_1: null,
    });
    assert(result.calculationMode === 'persistence_fallback', `Expected persistence_fallback, got ${result.calculationMode}`);
    assert(result.predictedWaterLevel === 12.80, `Expected 12.80, got ${result.predictedWaterLevel}`);
});

check('3.3 Tumana Target Semantics & Strict Unmapped Restrictions', () => {
    const reg = STATION_MODEL_REGISTRY.tumana;
    assert(reg.targetSemantics === 'PAGASA-reported daily Tumana water-level observation', 'Target semantics mismatch');
    assert(reg.thresholds === null, 'Tumana thresholds must be null');
    assert(reg.thresholdMappingAllowed === false, 'Tumana thresholdMappingAllowed must be false');
});

// ================================================================
// PHASE 2 FINAL DATA-CONSTRUCTION CONSISTENCY TESTS (TESTS A - I)
// ================================================================

await checkAsync('4.1 [Test A] Separate Water & Rain Source Timestamps Across Midnight Boundary', async () => {
    // Water request at 23:50 (belongs to 2026-08-18 Hour 23), Rain request at 00:00 (belongs to 2026-08-19 Hour 0)
    const waterMeta = parsePstYmdhm('202608182350');
    const rainMeta = parsePstYmdhm('202608190000');

    assert(waterMeta.dateStr === '2026-08-18', `Water date mismatch: ${waterMeta.dateStr}`);
    assert(waterMeta.hour === 23, `Water hour mismatch: ${waterMeta.hour}`);
    assert(rainMeta.dateStr === '2026-08-19', `Rain date mismatch: ${rainMeta.dateStr}`);
    assert(rainMeta.hour === 0, `Rain hour mismatch: ${rainMeta.hour}`);

    // Stale/failed fetch suppression:
    const count = await recordRawTelemetrySync({
        freshSensors: { sto_nino: null, nangka: null, tumana: null },
        freshUpstreamRain: { boso_boso_rf1hr: null, science_garden_rf1hr: null },
        waterSourceYmdhm: '202608182350',
        rainSourceYmdhm: '202608190000'
    });
    assert(count === 0, `Stale/failed fetch must insert 0 records, got ${count}`);
});

await checkAsync('4.2 [Test B] Cached Rainfall Is Not Persisted as Raw Observation', async () => {
    // Failed rainfall fetch -> freshUpstreamRain has null
    const count = await recordRawTelemetrySync({
        freshSensors: { sto_nino: 13.50 }, // valid WL
        freshUpstreamRain: { boso_boso_rf1hr: null, science_garden_rf1hr: null }, // failed rain
        waterSourceYmdhm: '202608191200',
        rainSourceYmdhm: '202608191200'
    });
    assert(count === 1, `Must insert only 1 WL record and 0 rain records, got ${count}`);
});

check('4.3 [Test C] Exact rf1hr Only (No rf10m or rf fallback; 0.0 is valid zero)', () => {
    // Case 1: rf1hr missing, rf10m present -> raw model rainfall must be null
    const stPayload = { obsnm: 'Boso Boso', rf1hr: null, rf10m: '3.0', rf: '4.0' };
    const exactRf1hr = (stPayload.rf1hr !== null && stPayload.rf1hr !== undefined && stPayload.rf1hr !== '')
        ? parseFloat(stPayload.rf1hr)
        : null;
    assert(exactRf1hr === null, 'rf1hr must not fallback to rf10m or rf');

    // Case 2: rf1hr = "0.0" -> valid numeric 0.0
    const zeroPayload = { obsnm: 'Boso Boso', rf1hr: '0.0' };
    const zeroRf1hr = parseFloat(zeroPayload.rf1hr);
    assert(zeroRf1hr === 0.0, 'rf1hr = 0.0 must be preserved as valid 0.0');
});

check('4.4 [Test D] Source Observation Timestamp Determines Date & Hour (Midnight Crossover)', () => {
    const { dateStr, hour, minute } = parsePstYmdhm('202608182350');
    assert(dateStr === '2026-08-18', `Expected date 2026-08-18, got ${dateStr}`);
    assert(hour === 23, `Expected hour 23, got ${hour}`);
    assert(minute === 50, `Expected minute 50, got ${minute}`);
});

check('4.5 [Test E] Strict Sto. Niño 24/24 Hourly Completeness (23 Hours Returns Null)', () => {
    // 24 complete top-of-hour readings (12.00 to 14.30)
    const complete24 = [];
    for (let h = 0; h < 24; h++) {
        complete24.push({ hour: h, minute: 0, value: 12.00 + (h * 0.1) });
    }
    const fullMax = aggregateCompleteHourlyWaterLevelMax(complete24);
    assert(fullMax === 14.30, `Expected 14.30m, got ${fullMax}`);

    // Incomplete (only 23 hours present, hour 15 missing)
    const incomplete23 = complete24.filter(r => r.hour !== 15);
    incomplete23.push({ hour: 10, minute: 5, value: 16.00 });
    incomplete23.push({ hour: 11, minute: 5, value: 16.00 });
    
    const incompleteMax = aggregateCompleteHourlyWaterLevelMax(incomplete23);
    assert(incompleteMax === null, `23 hours must return null daily max, got ${incompleteMax}`);
});

check('4.6 [Test F] Strict Nangka 24/24 Hourly Completeness (23 Hours Returns Null)', () => {
    const complete24 = [];
    for (let h = 0; h < 24; h++) {
        complete24.push({ hour: h, minute: 0, value: 15.50 + (h * 0.05) });
    }
    const fullMax = aggregateCompleteHourlyWaterLevelMax(complete24);
    assert(fullMax === 16.65, `Expected 16.65m, got ${fullMax}`);

    const incomplete23 = complete24.filter(r => r.hour !== 22);
    const incompleteMax = aggregateCompleteHourlyWaterLevelMax(incomplete23);
    assert(incompleteMax === null, `23 hours must return null daily max for Nangka, got ${incompleteMax}`);
});

check('4.7 [Test G] Top-of-Hour Window Selection [h:00, h:05] & Out-of-Order Elimination', () => {
    const rawPolls = [
        { hour: 10, minute: 20, value: 4.0 },
        { hour: 10, minute: 0, value: 2.0 },
        { hour: 10, minute: 5, value: 2.2 },
    ];
    const map = extractHourlyTopWindowObservations(rawPolls);
    assert(map[10] !== undefined, 'Hour 10 must be present');
    assert(map[10].value === 2.0, `Expected 2.0 (closest to minute 00), got ${map[10].value}`);

    const latePolls = [{ hour: 10, minute: 20, value: 4.0 }];
    const lateMap = extractHourlyTopWindowObservations(latePolls);
    assert(lateMap[10] === undefined, 'Hour 10 with only minute 20 poll must be missing');
});

await checkAsync('4.8 [Test H] /api/status Forecast Source Separation & Tumana peak_predicted_level: null', async () => {
    // Set live cache to extreme critical level
    CACHE.current_sensors.sto_nino = 17.50;
    CACHE.current_sensors.tumana = 16.00;
    
    const statusResult = await computePredictions();
    // 1. Live sensor section reflects live telemetry
    assert(statusResult.live_sensors.sto_nino === 17.50, 'live_sensors must reflect live telemetry');

    // 2. Daily forecast fields do NOT mirror live sensor values
    const stoPrediction = statusResult.prediction.rivers.sto_nino;
    assert(stoPrediction.predictedWaterLevel !== 17.50, 'Daily forecast must never mirror instantaneous live sensor level');
    assert(stoPrediction.one_step_predicted_level !== 17.50, 'one_step_predicted_level must not fall back to live sensor value');

    // 3. Tumana peak_predicted_level must be strictly null (never daily max or peak)
    const tumanaPrediction = statusResult.prediction.rivers.tumana;
    assert(tumanaPrediction.peak_predicted_level === null, 'Tumana peak_predicted_level must be null');
    assert(tumanaPrediction.thresholds === null, 'Tumana thresholds must be null');
    assert(tumanaPrediction.thresholdMappingAllowed === false, 'Tumana thresholdMappingAllowed must be false');
});

await checkAsync('4.9 [Test I] True End-to-End Production Pipeline Execution & Upsert Idempotency', async () => {
    // Mock DB store for isolation
    const mockRawDb = [];
    const mockDailyObsDb = new Map();
    const mockDailyForecastDb = new Map();

    // Populate 24 hourly top-of-hour readings for 2026-08-19
    for (let h = 0; h < 24; h++) {
        // Sto Niño: base 13.0m, peak 13.50m at hour 14
        mockRawDb.push({ date: '2026-08-19', hour: h, minute: 0, stationId: 'sto_nino', variable: 'wl', value: h === 14 ? 13.50 : 13.00 });
        // Nangka: base 15.5m, peak 16.20m at hour 16
        mockRawDb.push({ date: '2026-08-19', hour: h, minute: 0, stationId: 'nangka', variable: 'wl', value: h === 16 ? 16.20 : 15.50 });
        // Boso-Boso: 1.0mm per hour -> 24.0mm
        mockRawDb.push({ date: '2026-08-19', hour: h, minute: 0, stationId: 'boso_boso', variable: 'rf1hr', value: 1.0 });
    }

    // Populate existing completed Sto. Niño lag t-3 (2026-08-17)
    mockDailyObsDb.set('2026-08-17:sto_nino:wl_max', { date: '2026-08-17', stationId: 'sto_nino', variable: 'wl_max', value: 13.00, isCompleted: true });

    // Monkey-patch Mongoose methods for this test
    const origRawFind = RawTelemetryReading.find;
    const origObsFindOne = DailyObservation.findOne;
    const origObsFindOneAndUpdate = DailyObservation.findOneAndUpdate;
    const origForecastFindOneAndUpdate = DailyForecast.findOneAndUpdate;

    try {
        RawTelemetryReading.find = (query) => {
            const matches = mockRawDb.filter(r => r.date === query.date && r.stationId === query.stationId && r.variable === query.variable);
            return Promise.resolve(matches);
        };

        DailyObservation.findOne = (query) => {
            const varList = Array.isArray(query.variable?.$in) ? query.variable.$in : [query.variable];
            for (const v of varList) {
                const key = `${query.date}:${query.stationId}:${v}`;
                const doc = mockDailyObsDb.get(key);
                if (doc && (query.isCompleted === undefined || doc.isCompleted === query.isCompleted)) {
                    return Promise.resolve(doc);
                }
            }
            return Promise.resolve(null);
        };

        DailyObservation.findOneAndUpdate = (filter, update) => {
            const key = `${filter.date}:${filter.stationId}:${filter.variable}`;
            const doc = { ...filter, ...update, isCompleted: update.isCompleted ?? true };
            mockDailyObsDb.set(key, doc);
            return Promise.resolve(doc);
        };

        DailyForecast.findOneAndUpdate = (filter, update) => {
            const key = `${filter.stationId}:${filter.forecastTargetDate}`;
            const doc = { ...filter, ...update };
            mockDailyForecastDb.set(key, doc);
            return Promise.resolve(doc);
        };

        // --- EXECUTE PRODUCTION PIPELINE: RUN 1 ---
        const result1 = await executeDailyForecastRun('2026-08-20');

        assert(result1.forecastTargetDate === '2026-08-20', 'Target date mismatch');
        assert(result1.sourceDataDate === '2026-08-19', 'Source date mismatch');
        
        // Verify DailyObservation was produced by finalizeCalendarDayObservations
        const stoObs = mockDailyObsDb.get('2026-08-19:sto_nino:wl_max');
        assert(stoObs && stoObs.value === 13.50, `Sto daily max mismatch: ${stoObs?.value}`);
        assert(stoObs.isCompleted === true, 'Sto observation must have isCompleted: true');

        const nangkaObs = mockDailyObsDb.get('2026-08-19:nangka:wl_max');
        assert(nangkaObs && nangkaObs.value === 16.20, `Nangka daily max mismatch: ${nangkaObs?.value}`);

        const bosoObs = mockDailyObsDb.get('2026-08-19:boso_boso:rainfall_total');
        assert(bosoObs && bosoObs.value === 24.0, `Boso rain total mismatch: ${bosoObs?.value}`);

        // Verify DailyForecast records persisted in MongoDB
        assert(mockDailyForecastDb.size === 3, `Expected 3 station forecasts in DB, got ${mockDailyForecastDb.size}`);
        
        const stoForecast = mockDailyForecastDb.get('sto_nino:2026-08-20');
        assert(stoForecast.calculationMode === 'primary_model', 'Sto forecast should be primary_model');
        assert(stoForecast.predictedWaterLevel === 13.28, `Sto forecast level mismatch: ${stoForecast.predictedWaterLevel}`); // 3.54585 + 0.4642*13.5 + 0.2457*13.0 + 0.0115*24 = 13.28m

        const tumanaForecast = mockDailyForecastDb.get('tumana:2026-08-20');
        assert(tumanaForecast.calculationMode === 'unavailable', 'Tumana without official observation must be unavailable');
        assert(tumanaForecast.predictedWaterLevel === null, 'Tumana predicted WL must be null');

        // --- EXECUTE PRODUCTION PIPELINE: RUN 2 (IDEMPOTENCY VERIFICATION) ---
        await executeDailyForecastRun('2026-08-20');

        // Verify database records were updated in place without duplicate documents
        assert(mockDailyForecastDb.size === 3, `Idempotency violation: DB contains ${mockDailyForecastDb.size} records after rerun`);
        assert(mockDailyForecastDb.get('sto_nino:2026-08-20').predictedWaterLevel === 13.28, 'Sto forecast value altered on idempotent rerun');
    } finally {
        // Restore original functions
        RawTelemetryReading.find = origRawFind;
        DailyObservation.findOne = origObsFindOne;
        DailyObservation.findOneAndUpdate = origObsFindOneAndUpdate;
        DailyForecast.findOneAndUpdate = origForecastFindOneAndUpdate;
    }
});

// ================================================================
// SECURITY & ARCHITECTURAL PURITY AUDIT
// ================================================================

check('5.1 Zero Occurrences of rejectUnauthorized: false in Server Code', () => {
    const serverDir = path.resolve(__dirname, '..');
    const filesToScan = [
        path.join(serverDir, 'index.js'),
        path.join(serverDir, 'services', 'predictionEngine.js'),
        path.join(serverDir, 'services', 'dailyForecastService.js'),
        path.join(serverDir, 'services', 'dailyPipelineService.js'),
        path.join(serverDir, 'services', 'dailyScheduler.js'),
        path.join(serverDir, 'config', 'stationModelRegistry.js'),
    ];

    for (const file of filesToScan) {
        if (fs.existsSync(file)) {
            const content = fs.readFileSync(file, 'utf-8');
            assert(!content.includes('rejectUnauthorized: false'), `Security violation: rejectUnauthorized: false found in ${file}`);
        }
    }
});

check('5.2 No Open-Meteo Ingestion in Active Daily Forecast Service', () => {
    const dailyForecastCode = fs.readFileSync(path.join(__dirname, '../services/dailyForecastService.js'), 'utf-8');
    const registryCode = fs.readFileSync(path.join(__dirname, '../config/stationModelRegistry.js'), 'utf-8');
    const pipelineCode = fs.readFileSync(path.join(__dirname, '../services/dailyPipelineService.js'), 'utf-8');

    assert(!dailyForecastCode.includes('open-meteo'), 'dailyForecastService.js must not reference open-meteo');
    assert(!registryCode.includes('open-meteo'), 'stationModelRegistry.js must not reference open-meteo');
    assert(!pipelineCode.includes('open-meteo'), 'dailyPipelineService.js must not reference open-meteo');
});

check('5.3 Exact Calendar-Day Subtraction Logic (Leap Years, Month Transitions, Year Boundaries)', () => {
    assert(subtractCalendarDays('2026-08-20', 1) === '2026-08-19', '2026-08-20 - 1 failed');
    assert(subtractCalendarDays('2026-08-20', 3) === '2026-08-17', '2026-08-20 - 3 failed');
    assert(subtractCalendarDays('2026-03-01', 1) === '2026-02-28', '2026-03-01 - 1 failed');
    assert(subtractCalendarDays('2026-03-01', 3) === '2026-02-26', '2026-03-01 - 3 failed');
    assert(subtractCalendarDays('2026-01-01', 1) === '2025-12-31', '2026-01-01 - 1 failed');
    assert(subtractCalendarDays('2026-01-01', 3) === '2025-12-29', '2026-01-01 - 3 failed');
});

check('5.4 Daily Scheduler 07:00 AM Asia/Manila (UTC+8) Timing Calculation', () => {
    const ms = getMsUntilNext0700Pst();
    assert(typeof ms === 'number', 'ms must be a number');
    assert(ms > 0, `ms must be positive, got ${ms}`);
    assert(ms <= 24 * 3600 * 1000, `ms cannot exceed 24 hours, got ${ms}`);
});

check('5.5 Schema Validation for DailyObservation, DailyForecast, and RawTelemetryReading', () => {
    assert(DailyObservation.schema.path('date'), 'DailyObservation missing date path');
    assert(DailyObservation.schema.path('stationId'), 'DailyObservation missing stationId path');
    assert(DailyObservation.schema.path('variable'), 'DailyObservation missing variable path');
    assert(DailyObservation.schema.path('isCompleted'), 'DailyObservation missing isCompleted path');

    assert(DailyForecast.schema.path('stationId'), 'DailyForecast missing stationId path');
    assert(DailyForecast.schema.path('forecastTargetDate'), 'DailyForecast missing forecastTargetDate path');
    assert(DailyForecast.schema.path('predictedWaterLevel'), 'DailyForecast missing predictedWaterLevel path');
    assert(DailyForecast.schema.path('calculationMode'), 'DailyForecast missing calculationMode path');

    assert(RawTelemetryReading.schema.path('date'), 'RawTelemetryReading missing date path');
    assert(RawTelemetryReading.schema.path('hour'), 'RawTelemetryReading missing hour path');
    assert(RawTelemetryReading.schema.path('minute'), 'RawTelemetryReading missing minute path');
    assert(RawTelemetryReading.schema.path('stationId'), 'RawTelemetryReading missing stationId path');
    assert(RawTelemetryReading.schema.path('variable'), 'RawTelemetryReading missing variable path');
});

console.log('\n================================================================');
const passedCount = results.filter(r => r.pass).length;
console.log(`TEST SUMMARY: ${passedCount}/${results.length} PASSED`);
console.log('================================================================');

if (passedCount === results.length) {
    console.log('\nALL PHASE 2 SEALED CLOSURE VERIFICATION TESTS PASSED SUCCESSFULLY.');
    process.exit(0);
} else {
    console.error(`\nFAILED ${results.length - passedCount} TESTS.`);
    process.exit(1);
}
