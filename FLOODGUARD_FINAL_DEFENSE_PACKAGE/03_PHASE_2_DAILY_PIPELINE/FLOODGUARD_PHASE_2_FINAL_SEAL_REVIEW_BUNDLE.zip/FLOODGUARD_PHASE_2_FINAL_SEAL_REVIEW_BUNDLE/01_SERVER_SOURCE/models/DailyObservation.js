import mongoose from 'mongoose';

const dailyObservationSchema = new mongoose.Schema({
    date: {
        type: String, // Format: YYYY-MM-DD (Asia/Manila calendar date)
        required: true,
        index: true,
    },
    stationId: {
        type: String, // 'sto_nino', 'nangka', 'tumana', 'boso_boso', 'science_garden'
        required: true,
        index: true,
    },
    variable: {
        type: String, // 'wl_max', 'wl_obs', 'rainfall_total', 'rfday'
        required: true,
        index: true,
    },
    value: {
        type: Number,
        default: null,
    },
    unit: {
        type: String,
        enum: ['m', 'mm'],
        required: true,
    },
    source: {
        type: String,
        default: 'PAGASA_FFWS',
    },
    isCompleted: {
        type: Boolean,
        default: true,
    },
    createdAt: {
        type: Date,
        default: Date.now,
    },
    updatedAt: {
        type: Date,
        default: Date.now,
    },
}, { collection: 'daily_observations' });

dailyObservationSchema.index({ date: 1, stationId: 1, variable: 1 }, { unique: true });

export const DailyObservation = mongoose.models.DailyObservation || mongoose.model('DailyObservation', dailyObservationSchema);
export default DailyObservation;
