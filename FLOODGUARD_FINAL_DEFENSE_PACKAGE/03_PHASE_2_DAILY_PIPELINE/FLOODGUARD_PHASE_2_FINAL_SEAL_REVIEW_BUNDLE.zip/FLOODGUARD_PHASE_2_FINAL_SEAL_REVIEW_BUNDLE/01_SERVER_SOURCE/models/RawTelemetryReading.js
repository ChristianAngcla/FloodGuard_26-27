import mongoose from 'mongoose';

const rawTelemetryReadingSchema = new mongoose.Schema({
    date: {
        type: String, // YYYY-MM-DD in Asia/Manila (UTC+8)
        required: true,
        index: true,
    },
    timestamp: {
        type: Date,
        required: true,
        index: true,
    },
    hour: {
        type: Number, // 0-23 in Asia/Manila (UTC+8)
        required: true,
        index: true,
    },
    minute: {
        type: Number, // 0-59 in Asia/Manila (UTC+8)
        required: true,
        default: 0,
    },
    stationId: {
        type: String, // 'sto_nino', 'nangka', 'tumana', 'boso_boso', 'science_garden'
        required: true,
        index: true,
    },
    variable: {
        type: String, // 'wl', 'rf1hr', 'wl_obs', 'rfday'
        required: true,
        index: true,
    },
    value: {
        type: Number,
        default: null,
    },
    unit: {
        type: String,
        enum: ['m', 'mm'],
        required: true,
    },
    source: {
        type: String,
        default: 'PAGASA_FFWS',
    },
    createdAt: {
        type: Date,
        default: Date.now,
    },
}, { collection: 'raw_telemetry_readings' });

rawTelemetryReadingSchema.index({ date: 1, stationId: 1, variable: 1, timestamp: 1 });
rawTelemetryReadingSchema.index({ date: 1, stationId: 1, variable: 1, hour: 1 });

export const RawTelemetryReading = mongoose.models.RawTelemetryReading || mongoose.model('RawTelemetryReading', rawTelemetryReadingSchema);
export default RawTelemetryReading;
