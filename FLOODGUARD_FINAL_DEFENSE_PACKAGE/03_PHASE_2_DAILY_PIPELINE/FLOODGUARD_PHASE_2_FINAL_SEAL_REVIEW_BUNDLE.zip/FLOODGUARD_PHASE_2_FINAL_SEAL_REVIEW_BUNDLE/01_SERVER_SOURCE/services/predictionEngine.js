import axios from 'axios';
import mongoose from 'mongoose';
import https from 'https';
import { evaluateDailyForecasts, getPstDates } from './dailyForecastService.js';
import { recordRawTelemetrySync } from './dailyPipelineService.js';
import { DailyForecast } from '../models/DailyForecast.js';
import { STATION_MODEL_REGISTRY } from '../config/stationModelRegistry.js';

// Secure HTTPS agent with standard TLS validation enabled
const pagasaHttpsAgent = new https.Agent({ keepAlive: true });

// --- CONFIGURATION ---
const PAGASA_WATER_API = "https://pasig-marikina-tullahanffws.pagasa.dost.gov.ph/water/map_list.do";
const PAGASA_RAIN_API = "https://pasig-marikina-tullahanffws.pagasa.dost.gov.ph/rainfall/map_list.do";
const PARSER_API = "https://pagasa.chlod.net/api/v1/bulletin/list";

const STATION_MAP = {
    "Sto Nino": "sto_nino",
    "Nangka": "nangka",
    "Tumana Bridge": "tumana",
    "Montalban": "montalban",
    "Rosario": "rosario",
};

// Global Memory for Time-Series (SLIDING WINDOW)
export const CACHE = {
    current_sensors: { 
        sto_nino: 13.0, 
        nangka: 15.9,
        tumana: 12.0, 
        montalban: 21.9,
        rosario: 11.4 
    },
    upstream_rainfall: {
        mt_campana: 0.0,
        boso_boso: 0.0,
        boso_boso_rfday: 0.0,
        mt_aries: 0.0,
        mt_oro: 0.0,
        nangka_rf: 0.0,
        science_garden: 0.0,
        science_garden_rfday: 0.0,
        weighted_total: 0.0
    },
    thresholds: {
        sto_nino: { alert: 15.00, alarm: 16.00, critical: 17.00 },
        nangka: { alert: 16.50, alarm: 17.10, critical: 17.70 },
        tumana: { alert: 17.26, alarm: 18.26, critical: 19.26 },
        montalban: { alert: 22.40, alarm: 23.00, critical: 23.60 },
        rosario: { alert: 13.00, alarm: 14.00, critical: 15.00 },
    },
    history: [], // Keep last 6 readings
    storm: {
        name: "None", category: "No Active Tropical Cyclone",
        center: "--", movement: "--", signal: 0, status_encoded: 0
    },
    weather: {
        source: "PAGASA_FFWS_TELEMETRY",
        precipitation: 0.0, weather_code: 0, status_encoded: 0,
        temperature: 0.0, humidity: 0.0, heat_index: 0.0, wind_speed: 0.0
    },
    simulation_mode: false,
    last_auto_alert: {
        sto_nino: "SAFE",
        nangka: "SAFE",
        tumana: "SAFE",
        montalban: "SAFE",
        rosario: "SAFE",
    },
};

export const invalidateCoefficientCache = () => {
    // Certified models are frozen in stationModelRegistry.js
};

// --- DATA FETCHERS ---

const parseWlValue = (val) => {
    if (val == null || val === "" || val === "nodata") return null;
    const clean = String(val).replace("(*)", "").replace("*", "").trim();
    if (clean === "") return null;
    const n = parseFloat(clean);
    return Number.isFinite(n) ? n : null;
};

const parseRainValue = (val) => {
    if (val == null || val === "" || val === "nodata") return null;
    const n = parseFloat(String(val).trim());
    return Number.isFinite(n) ? n : null;
};

const fetchMarikina = async () => {
    const pstDate = new Date(Date.now() + 8 * 3600000 - 1200000);
    const ymdhm = pstDate.toISOString().replace(/\D/g, '').slice(0, 11) + '0';
    const ts = Date.now();
    const url = `${PAGASA_WATER_API}?ymdhm=${ymdhm}&basin=&_=${ts}`;

    const freshValidSensors = {
        sto_nino: null,
        nangka: null,
        tumana: null,
    };

    try {
        const response = await axios.get(url, { timeout: 10000, httpsAgent: pagasaHttpsAgent });
        const stations = response.data;

        const defaults = { sto_nino: 13.0, nangka: 15.9, tumana: 12.0, montalban: 21.9, rosario: 11.4 };
        const results = { ...CACHE.current_sensors };
        const thresholds = { ...CACHE.thresholds };

        stations.forEach(station => {
            const key = STATION_MAP[station.obsnm];
            if (key) {
                const rawWl = station.wl == null ? "" : String(station.wl);
                const isSuspect = /\(\*\)|\*/.test(rawWl);

                const alert = parseWlValue(station.alertwl);
                const alarm = parseWlValue(station.alarmwl);
                const critical = parseWlValue(station.criticalwl);
                if (alert && alarm && critical) {
                    thresholds[key] = { alert, alarm, critical };
                }

                const stationCritical =
                    thresholds[key]?.critical ??
                    CACHE.thresholds[key]?.critical ??
                    null;
                const baseline = defaults[key];
                let previous_wl = CACHE.current_sensors[key] ?? baseline;

                if (
                    stationCritical != null &&
                    Number.isFinite(previous_wl) &&
                    previous_wl > stationCritical + 2.5
                ) {
                    console.warn(
                        `[!] Poisoned cache for ${key}: ${previous_wl}m > critical+2.5 (${stationCritical}). Resetting to ${baseline}m.`
                    );
                    previous_wl = baseline;
                    results[key] = baseline;
                }

                if (isSuspect) {
                    console.warn(`[!] Suspect PAGASA reading for ${key}: "${rawWl}" — keeping previous/default for display.`);
                    results[key] = previous_wl;
                    // NOT fresh valid
                } else {
                    const wl = parseWlValue(rawWl);
                    if (wl !== null && wl >= 0 && wl <= 30.0) {
                        const implausibleVsCritical =
                            stationCritical != null && wl > stationCritical + 2.5;
                        const extremeJump = Math.abs(wl - previous_wl) > 5.0;

                        if (implausibleVsCritical) {
                            console.warn(
                                `[!] Implausible PAGASA reading for ${key}: ${wl}m exceeds critical ${stationCritical}m by >2.5m. Rejecting.`
                            );
                            results[key] = previous_wl;
                        } else if (extremeJump) {
                            console.warn(
                                `[!] HARDWARE GLITCH DETECTED at ${key}: jump from ${previous_wl}m to ${wl}m. Rejecting data.`
                            );
                            results[key] = previous_wl;
                        } else {
                            results[key] = wl;
                            if (key in freshValidSensors) {
                                freshValidSensors[key] = wl;
                            }
                        }
                    }
                }
            }
        });
        return { results, freshValidSensors, thresholds, sourceYmdhm: ymdhm };
    } catch (e) {
        console.warn("[!] PAGASA Water API fetch failed, using cached values for display:", e.message);
        return { results: CACHE.current_sensors, freshValidSensors, thresholds: CACHE.thresholds, sourceYmdhm: ymdhm };
    }
};

const fetchUpstreamRainfall = async () => {
    const pstDate = new Date(Date.now() + 8 * 3600000 - 1200000);
    const ymdhm = pstDate.toISOString().replace(/\D/g, '').slice(0, 11) + '0';
    const ts = Date.now();
    const url = `${PAGASA_RAIN_API}?ymdhm=${ymdhm}&basin=&_=${ts}`;

    const freshValidUpstreamRain = {
        boso_boso_rf1hr: null,
        science_garden_rf1hr: null,
    };

    try {
        const response = await axios.get(url, { timeout: 10000, httpsAgent: pagasaHttpsAgent });
        const stations = response.data;

        const rfData = {
            mt_campana: null,
            boso_boso: null,
            boso_boso_rfday: null,
            mt_aries: null,
            mt_oro: null,
            nangka_rf: null,
            science_garden: null,
            science_garden_rfday: null,
            weighted_total: null
        };

        stations.forEach(st => {
            const rf = parseRainValue(st.rf1hr || st.rf10m || st.rf);
            const rfday = parseRainValue(st.rfday);
            const exactRf1hr = parseRainValue(st.rf1hr); // STRICT exact rf1hr only for model buffer

            if (st.obsnm === 'Mt. Campana') rfData.mt_campana = rf;
            if (st.obsnm === 'Boso Boso') {
                rfData.boso_boso = rf;
                rfData.boso_boso_rfday = rfday;
                freshValidUpstreamRain.boso_boso_rf1hr = exactRf1hr;
            }
            if (st.obsnm === 'Mt. Aries') rfData.mt_aries = rf;
            if (st.obsnm === 'Mt. Oro') rfData.mt_oro = rf;
            if (st.obsnm === 'Nangka') rfData.nangka_rf = rf;
            if (st.obsnm === 'Science Garden' || String(st.obscd) === '11203101') {
                rfData.science_garden = rf;
                rfData.science_garden_rfday = rfday;
                freshValidUpstreamRain.science_garden_rf1hr = exactRf1hr;
            }
        });

        // Hydrological Spatial Weighting for monitoring overview
        const c_campana = rfData.mt_campana || 0.0;
        const c_boso = rfData.boso_boso || 0.0;
        const c_oro = rfData.mt_oro || 0.0;
        const c_aries = rfData.mt_aries || 0.0;
        const c_nangka = rfData.nangka_rf || 0.0;

        rfData.weighted_total = (
            0.25 * c_campana +
            0.25 * c_boso +
            0.20 * c_oro +
            0.15 * c_aries +
            0.15 * c_nangka
        );

        return { rfData, freshValidUpstreamRain, sourceYmdhm: ymdhm };
    } catch (e) {
        console.warn("[!] PAGASA Upstream Rain API fetch failed, using cached values for display:", e.message);
        return { rfData: CACHE.upstream_rainfall, freshValidUpstreamRain, sourceYmdhm: ymdhm };
    }
};

const getStormContext = async () => {
    try {
        const response = await axios.get(PARSER_API, { timeout: 10000 });
        const data = response.data;
        const latest = (data.bulletins && data.bulletins.length > 0) ? data.bulletins[0] : data;
        const cycloneData = latest.cyclone || {};

        if (!cycloneData.name) {
            return { name: "None", category: "No Active Tropical Cyclone", center: "--", movement: "--", signal: 0, status_encoded: 0 };
        }

        const localName = cycloneData.name || '';
        const intName = cycloneData.internationalName || '';
        const name = intName ? `${localName} ${intName}` : localName;
        
        let highestSignal = 0;
        if (latest.signals) {
            Object.keys(latest.signals).forEach(sig => {
                const s = parseInt(sig);
                if (!isNaN(s) && s > highestSignal) highestSignal = s;
            });
        }

        return {
            name,
            category: cycloneData.category || "Unknown Category",
            center: cycloneData.center?.lat ? `${cycloneData.center.lat}°N, ${cycloneData.center.lon}°E` : "--",
            movement: cycloneData.movement || "--",
            signal: highestSignal,
            status_encoded: highestSignal > 0 ? 3 : 0
        };
    } catch (e) {
        console.warn("[!] Storm parser failed:", e.message);
        return { name: "None", category: "No Active Tropical Cyclone", center: "--", movement: "--", signal: 0, status_encoded: 0 };
    }
};

const getLegacyStatusLabel = (wl, alert, alarm, critical) => {
    if (!Number.isFinite(wl)) return "SAFE";
    if (critical != null && wl >= critical) return "CRITICAL";
    if (alarm != null && wl >= alarm) return "WARNING";
    if (alert != null && wl >= alert) return "ALERT";
    return "SAFE";
};

/**
 * Computes deterministic daily predictions using persisted DailyForecast records from MongoDB.
 * Never calculates daily model outputs directly from intraday live cache.
 */
export const computePredictions = async () => {
    let sensors = { ...CACHE.current_sensors };
    let upstreamRain = { ...CACHE.upstream_rainfall };
    let storm = { ...CACHE.storm };
    let weather = { ...CACHE.weather };
    let thresholds = { ...CACHE.thresholds };

    if (CACHE.simulation_mode) {
        sensors = { sto_nino: 15.8, nangka: 16.5, tumana: 16.5, montalban: 22.5, rosario: 13.5 };
        upstreamRain = {
            mt_campana: 45.0,
            boso_boso: 50.0,
            boso_boso_rfday: 50.0,
            mt_aries: 40.0,
            mt_oro: 55.0,
            nangka_rf: 35.0,
            science_garden: 80.0,
            science_garden_rfday: 80.0,
            weighted_total: 46.25
        };
        storm = { name: "TYPHOON (TEST SIMULATION)", category: "Super Typhoon", center: "14.6°N, 121.1°E", movement: "Westward 20km/h", signal: 4, status_encoded: 3 };
        weather = { source: "SIMULATION", precipitation: 85.5, weather_code: 95, status_encoded: 3, temperature: 26.0, humidity: 90.0, heat_index: 28.0, wind_speed: 40.0 };
    }

    const { forecastTargetDate, sourceDataDate } = getPstDates();

    // Query authoritative persisted DailyForecast records for today
    let persistedForecasts = [];
    if (mongoose.connection && mongoose.connection.readyState === 1) {
        try {
            persistedForecasts = await DailyForecast.find({ forecastTargetDate });
        } catch (err) {
            console.warn("[!] Could not fetch persisted daily forecasts from MongoDB:", err.message);
        }
    }

    const stations = {};
    const river_forecasts = {};

    // 1. Certified Stations: Sto. Niño, Nangka, Tumana
    const certifiedKeys = ['sto_nino', 'nangka', 'tumana'];
    certifiedKeys.forEach(stKey => {
        const reg = STATION_MODEL_REGISTRY[stKey];
        const persisted = persistedForecasts.find(f => f.stationId === stKey);
        const isTumana = stKey === 'tumana';

        let stForecast;
        if (persisted) {
            stForecast = {
                stationId: persisted.stationId,
                stationName: reg.stationName,
                sourceDataDate: persisted.sourceDataDate,
                forecastTargetDate: persisted.forecastTargetDate,
                predictedWaterLevel: persisted.predictedWaterLevel,
                unit: persisted.unit,
                selectedCandidate: persisted.candidateId,
                modelVersion: persisted.modelVersion,
                calculationMode: persisted.calculationMode,
                fallbackReason: persisted.fallbackReason,
                targetSemantics: persisted.targetSemantics,
                statusBand: persisted.statusBand,
                status: persisted.status,
                thresholds: isTumana ? null : persisted.thresholds,
                thresholdMappingAllowed: isTumana ? false : persisted.thresholdMappingAllowed,
                inputsUsed: persisted.inputsUsed,
                missingInputs: persisted.missingInputs,
            };
        } else {
            // Unavailable when no scheduled daily run has executed
            const unavailStatus = isTumana ? 'UNMAPPED_DAILY_OBSERVATION' : 'UNAVAILABLE';
            stForecast = {
                stationId: reg.stationId,
                stationName: reg.stationName,
                sourceDataDate,
                forecastTargetDate,
                predictedWaterLevel: null,
                unit: reg.unit,
                selectedCandidate: reg.selectedCandidate,
                modelVersion: reg.modelVersion,
                calculationMode: 'unavailable',
                fallbackReason: 'Daily forecast not yet computed for target date.',
                targetSemantics: reg.targetSemantics,
                statusBand: unavailStatus,
                status: unavailStatus,
                thresholds: isTumana ? null : reg.thresholds,
                thresholdMappingAllowed: isTumana ? false : reg.thresholdMappingAllowed,
                inputsUsed: {},
                missingInputs: isTumana ? ['PAGASA_Tumana_Daily_Observation', 'PAGASA_SG_Rain_t_1'] : ['Daily_Completed_Lags'],
            };
        }

        stations[stKey] = stForecast;
        river_forecasts[stKey] = {
            ...stForecast,
            predicted_water_level: stForecast.predictedWaterLevel,
            peak_predicted_level: isTumana ? null : stForecast.predictedWaterLevel,
            one_step_predicted_level: stForecast.predictedWaterLevel,
            time_series_insights: {
                trend: "Daily Forecast",
                rate_of_change_m_per_h: 0.0,
                eta_to_alert: "N/A (Daily Forecast)",
                eta_to_warning: "N/A (Daily Forecast)",
                eta_to_critical: "N/A (Daily Forecast)",
                peak_predicted_level: isTumana ? null : stForecast.predictedWaterLevel,
                peak_expected_time: isTumana ? "N/A (Tumana Observation)" : (stForecast.predictedWaterLevel !== null ? stForecast.forecastTargetDate : "N/A"),
                one_step_predicted_level: stForecast.predictedWaterLevel,
            }
        };
    });

    // 2. Legacy Stations (Montalban, Rosario) - Read-only live telemetry
    const legacyRivers = ["montalban", "rosario"];
    legacyRivers.forEach((river) => {
        const thr = thresholds[river];
        const currentWl = sensors[river] ?? 0.0;
        const legacyStatus = getLegacyStatusLabel(currentWl, thr?.alert, thr?.alarm, thr?.critical);
        river_forecasts[river] = {
            stationId: river,
            stationName: river.charAt(0).toUpperCase() + river.slice(1),
            sourceDataDate,
            forecastTargetDate,
            predictedWaterLevel: currentWl,
            predicted_water_level: currentWl,
            unit: "m",
            selectedCandidate: "LEGACY_UNMONITORED",
            modelVersion: "1.0.0-LEGACY",
            calculationMode: "unavailable",
            fallbackReason: "Legacy station without certified OLS tournament model; displaying live telemetry only.",
            targetSemantics: "Instantaneous Telemetry Reading",
            statusBand: legacyStatus,
            status: legacyStatus,
            thresholds: thr,
            thresholdMappingAllowed: false,
            inputsUsed: { live_wl: currentWl },
            missingInputs: ["Certified_Model_Equation"],
            time_series_insights: {
                trend: "Live Observation",
                rate_of_change_m_per_h: 0.0,
                eta_to_alert: "N/A (Legacy)",
                eta_to_warning: "N/A (Legacy)",
                eta_to_critical: "N/A (Legacy)",
                peak_predicted_level: currentWl,
                peak_expected_time: "Now",
                one_step_predicted_level: currentWl,
            }
        };
    });

    // Overall Status across threshold-mapped certified stations
    const activeStatuses = [stations.sto_nino.status, stations.nangka.status].filter(s => s !== 'UNAVAILABLE');
    let overall_status = 'SAFE';
    if (activeStatuses.includes('CRITICAL')) overall_status = 'CRITICAL';
    else if (activeStatuses.includes('WARNING')) overall_status = 'WARNING';
    else if (activeStatuses.includes('ALERT')) overall_status = 'ALERT';

    return {
        stations,
        live_sensors: sensors,
        upstream_rainfall: upstreamRain,
        thresholds,
        storm,
        weather,
        prediction: {
            overall_status,
            rivers: river_forecasts,
            timeline: [], // Truthful empty timeline - zero fake linear interpolation
        }
    };
};

export const runBackgroundSync = async () => {
    console.log(`[*] Syncing PAGASA Live Telemetry... ${new Date().toLocaleTimeString()}`);
    const { results: sensors, freshValidSensors, thresholds, sourceYmdhm: waterYmdhm } = await fetchMarikina();
    const { rfData: upstreamRain, freshValidUpstreamRain, sourceYmdhm: rainYmdhm } = await fetchUpstreamRainfall();

    CACHE.current_sensors = sensors;
    CACHE.upstream_rainfall = upstreamRain;
    CACHE.thresholds = thresholds;
    CACHE.storm = await getStormContext();

    CACHE.history.push(sensors);
    if (CACHE.history.length > 6) {
        CACHE.history.shift();
    }

    // Persist raw timestamped telemetry reading using dedicated source observation timestamps
    await recordRawTelemetrySync({
        freshSensors: freshValidSensors,
        freshUpstreamRain: freshValidUpstreamRain,
        waterSourceYmdhm: waterYmdhm,
        rainSourceYmdhm: rainYmdhm,
    }).catch(() => {});
};
