/**
 * FloodGuard Daily Pipeline Service (Phase 2)
 * 
 * Manages official intraday telemetry ingestion, non-overlapping hourly rainfall aggregation,
 * calendar-day maximum water level computation with strict 24/24 completeness, exact calendar lag retrieval,
 * and deterministic daily forecast persistence into MongoDB.
 */

import { DailyObservation } from '../models/DailyObservation.js';
import { DailyForecast } from '../models/DailyForecast.js';
import { RawTelemetryReading } from '../models/RawTelemetryReading.js';
import { evaluateDailyForecasts, getPstDates } from './dailyForecastService.js';

/**
 * Parses the official PAGASA requested/source observation ymdhm (e.g. '202608190000')
 * into exact Asia/Manila (UTC+8) date, hour, minute, and timestamp.
 */
export const parsePstYmdhm = (ymdhm) => {
    if (typeof ymdhm === 'string' && ymdhm.length >= 12) {
        const y = parseInt(ymdhm.slice(0, 4), 10);
        const m = parseInt(ymdhm.slice(4, 6), 10);
        const d = parseInt(ymdhm.slice(6, 8), 10);
        const h = parseInt(ymdhm.slice(8, 10), 10);
        const min = parseInt(ymdhm.slice(10, 12), 10);
        
        // UTC timestamp corresponding to Asia/Manila (UTC+8)
        const utcMs = Date.UTC(y, m - 1, d, h - 8, min, 0);
        const pad = (n) => String(n).padStart(2, '0');
        return {
            dateStr: `${y}-${pad(m)}-${pad(d)}`,
            hour: h,
            minute: min,
            timestamp: new Date(utcMs),
        };
    }

    // Fallback: Current time in Asia/Manila (UTC+8)
    const now = new Date();
    const pstOffsetMs = 8 * 3600 * 1000;
    const pstDate = new Date(now.getTime() + (now.getTimezoneOffset() * 60 * 1000) + pstOffsetMs);
    const pad = (n) => String(n).padStart(2, '0');
    return {
        dateStr: `${pstDate.getFullYear()}-${pad(pstDate.getMonth() + 1)}-${pad(pstDate.getDate())}`,
        hour: pstDate.getHours(),
        minute: pstDate.getMinutes(),
        timestamp: now,
    };
};

/**
 * Performs exact calendar day subtraction on YYYY-MM-DD string without timezone drift.
 * 
 * @param {string} dateStr - 'YYYY-MM-DD'
 * @param {number} days - Number of days to subtract
 * @returns {string} - 'YYYY-MM-DD'
 */
export const subtractCalendarDays = (dateStr, days) => {
    const [year, month, day] = dateStr.split('-').map(Number);
    const date = new Date(Date.UTC(year, month - 1, day));
    date.setUTCDate(date.getUTCDate() - days);

    const pad = (n) => String(n).padStart(2, '0');
    return `${date.getUTCFullYear()}-${pad(date.getUTCMonth() + 1)}-${pad(date.getUTCDate())}`;
};

/**
 * Pure helper: Extracts representative top-of-hour observation for each hour (0..23).
 * Follows approved evidence rule: selects the valid observation in the top-of-hour window [h:00, h:05]
 * closest to minute 00. If no observation exists in [h:00, h:05], that hour is considered missing.
 */
export const extractHourlyTopWindowObservations = (readings = []) => {
    const hourlyMap = {};

    // Group readings by hour
    for (const r of readings) {
        const hour = r.hour;
        const minute = Number.isFinite(r.minute) ? r.minute : 0;
        const val = r.value;

        if (Number.isFinite(hour) && hour >= 0 && hour <= 23 && Number.isFinite(val) && val !== null) {
            // Must be within top-of-hour window [0, 5]
            if (minute >= 0 && minute <= 5) {
                if (hourlyMap[hour] === undefined || minute < hourlyMap[hour].minute) {
                    hourlyMap[hour] = { value: val, minute };
                }
            }
        }
    }

    return hourlyMap;
};

/**
 * Pure aggregation function: Computes the daily maximum from 24 hourly water-level observations.
 * Strictly enforces 24/24 hourly completeness.
 * If fewer than 24 valid hourly top-of-hour windows exist, returns null (cannot compute partial-day max).
 */
export const aggregateCompleteHourlyWaterLevelMax = (readings = []) => {
    const hourlyMap = extractHourlyTopWindowObservations(readings);
    const hoursCovered = Object.keys(hourlyMap).length;

    if (hoursCovered < 24) {
        return null; // Incomplete calendar day -> daily max is unavailable
    }

    const values = Object.values(hourlyMap).map(item => item.value);
    const maxVal = Math.max(...values);
    return Number(maxVal.toFixed(2));
};

/**
 * Pure aggregation function: Aggregates non-overlapping hourly rainfall (rf1hr).
 * Selects exactly ONE representative reading per top-of-hour window [h:00, h:05] to prevent double-counting.
 * Strictly requires 24/24 hourly completeness.
 * Returns the 24-hour total sum if complete, or null if coverage is incomplete.
 */
export const aggregateCompleteHourlyRainfallTotal = (readings = []) => {
    const hourlyMap = extractHourlyTopWindowObservations(readings);
    const hoursCovered = Object.keys(hourlyMap).length;

    if (hoursCovered < 24) {
        return null; // Incomplete coverage -> returns null to trigger persistence fallback
    }

    const total = Object.values(hourlyMap).reduce((sum, item) => sum + item.value, 0);
    return Number(total.toFixed(2));
};

/**
 * Records or updates a single daily observation record in MongoDB.
 */
export const recordDailyObservation = async ({
    date,
    stationId,
    variable,
    value,
    unit,
    source = 'PAGASA_FFWS',
    isCompleted = true,
}) => {
    const filter = { date, stationId, variable };
    const update = {
        date,
        stationId,
        variable,
        value: Number.isFinite(value) && value !== null ? value : null,
        unit,
        source,
        isCompleted,
        updatedAt: new Date(),
    };

    return await DailyObservation.findOneAndUpdate(filter, update, {
        upsert: true,
        new: true,
        setDefaultsOnInsert: true,
    });
};

/**
 * Persists raw telemetry snapshot received during periodic sync into RawTelemetryReading collection.
 * STRICTLY persists only fresh, genuine, newly observed values. Never persists cached or stale readings.
 */
export const recordRawTelemetrySync = async ({
    freshSensors = {},
    freshUpstreamRain = {},
    waterSourceYmdhm = null,
    rainSourceYmdhm = null,
    sourceYmdhm = null,
}) => {
    const waterMeta = parsePstYmdhm(waterSourceYmdhm || sourceYmdhm);
    const rainMeta = parsePstYmdhm(rainSourceYmdhm || sourceYmdhm);
    const docs = [];

    // Water level readings (Sto. Niño, Nangka, Tumana) use waterMeta
    if (Number.isFinite(freshSensors.sto_nino) && freshSensors.sto_nino !== null) {
        docs.push({ date: waterMeta.dateStr, timestamp: waterMeta.timestamp, hour: waterMeta.hour, minute: waterMeta.minute, stationId: 'sto_nino', variable: 'wl', value: freshSensors.sto_nino, unit: 'm' });
    }
    if (Number.isFinite(freshSensors.nangka) && freshSensors.nangka !== null) {
        docs.push({ date: waterMeta.dateStr, timestamp: waterMeta.timestamp, hour: waterMeta.hour, minute: waterMeta.minute, stationId: 'nangka', variable: 'wl', value: freshSensors.nangka, unit: 'm' });
    }
    if (Number.isFinite(freshSensors.tumana) && freshSensors.tumana !== null) {
        docs.push({ date: waterMeta.dateStr, timestamp: waterMeta.timestamp, hour: waterMeta.hour, minute: waterMeta.minute, stationId: 'tumana', variable: 'wl', value: freshSensors.tumana, unit: 'm' });
    }

    // Rainfall readings (EXACT rf1hr only — numeric 0.0 is valid) use rainMeta
    if (Number.isFinite(freshUpstreamRain.boso_boso_rf1hr) && freshUpstreamRain.boso_boso_rf1hr !== null) {
        docs.push({ date: rainMeta.dateStr, timestamp: rainMeta.timestamp, hour: rainMeta.hour, minute: rainMeta.minute, stationId: 'boso_boso', variable: 'rf1hr', value: freshUpstreamRain.boso_boso_rf1hr, unit: 'mm' });
    }
    if (Number.isFinite(freshUpstreamRain.science_garden_rf1hr) && freshUpstreamRain.science_garden_rf1hr !== null) {
        docs.push({ date: rainMeta.dateStr, timestamp: rainMeta.timestamp, hour: rainMeta.hour, minute: rainMeta.minute, stationId: 'science_garden', variable: 'rf1hr', value: freshUpstreamRain.science_garden_rf1hr, unit: 'mm' });
    }

    if (docs.length > 0) {
        await RawTelemetryReading.insertMany(docs, { ordered: false }).catch(() => {});
    }
    return docs.length;
};

/**
 * Finalizes a completed calendar day by strictly aggregating raw collected readings into DailyObservation.
 * - Sto. Niño: Daily maximum water level across 24 hourly top-of-hour windows (wl_max)
 * - Nangka: Daily maximum water level across 24 hourly top-of-hour windows (wl_max)
 * - Mt. Boso-Boso: Non-overlapping 24-hr rainfall sum of exact rf1hr (rainfall_total)
 * - Science Garden: Non-overlapping 24-hr rainfall sum of exact rf1hr (rfday)
 * - Tumana: Left untouched unless an official daily observation was explicitly ingested.
 */
export const finalizeCalendarDayObservations = async (targetCalendarDate) => {
    // 1. Sto. Niño Daily Max (Strict 24/24)
    const stoDocs = await RawTelemetryReading.find({ date: targetCalendarDate, stationId: 'sto_nino', variable: 'wl' });
    const stoMax = aggregateCompleteHourlyWaterLevelMax(stoDocs.map(d => ({ hour: d.hour, minute: d.minute, value: d.value })));
    await recordDailyObservation({
        date: targetCalendarDate,
        stationId: 'sto_nino',
        variable: 'wl_max',
        value: stoMax,
        unit: 'm',
        isCompleted: true,
    });

    // 2. Nangka Daily Max (Strict 24/24)
    const nangkaDocs = await RawTelemetryReading.find({ date: targetCalendarDate, stationId: 'nangka', variable: 'wl' });
    const nangkaMax = aggregateCompleteHourlyWaterLevelMax(nangkaDocs.map(d => ({ hour: d.hour, minute: d.minute, value: d.value })));
    await recordDailyObservation({
        date: targetCalendarDate,
        stationId: 'nangka',
        variable: 'wl_max',
        value: nangkaMax,
        unit: 'm',
        isCompleted: true,
    });

    // 3. Mt. Boso-Boso Non-Overlapping Hourly Rainfall Total (Strict 24/24)
    const bosoDocs = await RawTelemetryReading.find({ date: targetCalendarDate, stationId: 'boso_boso', variable: 'rf1hr' });
    const bosoTotal = aggregateCompleteHourlyRainfallTotal(bosoDocs.map(d => ({ hour: d.hour, minute: d.minute, value: d.value })));
    await recordDailyObservation({
        date: targetCalendarDate,
        stationId: 'boso_boso',
        variable: 'rainfall_total',
        value: bosoTotal,
        unit: 'mm',
        isCompleted: true,
    });

    // 4. Science Garden Non-Overlapping Hourly Rainfall Total (Strict 24/24)
    const sgDocs = await RawTelemetryReading.find({ date: targetCalendarDate, stationId: 'science_garden', variable: 'rf1hr' });
    const sgTotal = aggregateCompleteHourlyRainfallTotal(sgDocs.map(d => ({ hour: d.hour, minute: d.minute, value: d.value })));
    await recordDailyObservation({
        date: targetCalendarDate,
        stationId: 'science_garden',
        variable: 'rfday',
        value: sgTotal,
        unit: 'mm',
        isCompleted: true,
    });

    return {
        date: targetCalendarDate,
        stoMax,
        nangkaMax,
        bosoTotal,
        sgTotal,
    };
};

/**
 * Retrieves completed daily model inputs for a target forecast date using EXACT calendar lags.
 * 
 * Target T -> t-1 = T - 1 calendar day, t-3 = T - 3 calendar days.
 * Strictly enforces `isCompleted: true`. Missing data returns null (zero-fill and interpolation are prohibited).
 */
export const getCompletedDailyInputs = async (forecastTargetDate) => {
    const t_1 = subtractCalendarDays(forecastTargetDate, 1);
    const t_3 = subtractCalendarDays(forecastTargetDate, 3);

    // Query observations in parallel for exact calendar dates with isCompleted: true
    const [
        sto1Doc,
        sto3Doc,
        bosoRainDoc,
        nangka1Doc,
        tumana1Doc,
        sgRainDoc,
    ] = await Promise.all([
        DailyObservation.findOne({ date: t_1, stationId: 'sto_nino', variable: 'wl_max', isCompleted: true }),
        DailyObservation.findOne({ date: t_3, stationId: 'sto_nino', variable: 'wl_max', isCompleted: true }),
        DailyObservation.findOne({ date: t_1, stationId: 'boso_boso', variable: { $in: ['rainfall_total', 'rfday'] }, isCompleted: true }),
        DailyObservation.findOne({ date: t_1, stationId: 'nangka', variable: 'wl_max', isCompleted: true }),
        DailyObservation.findOne({ date: t_1, stationId: 'tumana', variable: 'wl_obs', isCompleted: true }),
        DailyObservation.findOne({ date: t_1, stationId: 'science_garden', variable: 'rfday', isCompleted: true }),
    ]);

    const parseVal = (doc) => {
        if (!doc || doc.value === null || doc.value === undefined) return null;
        return Number.isFinite(doc.value) ? doc.value : null;
    };

    return {
        sto_t_1: parseVal(sto1Doc),
        sto_t_3: parseVal(sto3Doc),
        bosoboso_t_1: parseVal(bosoRainDoc),
        nangka_wl_t_1: parseVal(nangka1Doc),
        tumana_wl_t_1: parseVal(tumana1Doc),
        pagasa_sg_rain_t_1: parseVal(sgRainDoc),
        sourceDataDate: t_1,
        antecedentDate3: t_3,
        forecastTargetDate,
    };
};

/**
 * Executes a full daily forecast run for a given target date, evaluates certified OLS equations,
 * and persists idempotent records in the DailyForecast collection.
 */
export const executeDailyForecastRun = async (targetDateStr = null) => {
    const { forecastTargetDate: defaultTarget } = getPstDates();
    const forecastTargetDate = targetDateStr || defaultTarget;
    const t_1 = subtractCalendarDays(forecastTargetDate, 1);

    // 1. Finalize yesterday's collected telemetry into completed DailyObservation records
    await finalizeCalendarDayObservations(t_1);

    // 2. Retrieve completed daily inputs using exact calendar lags (isCompleted: true only)
    const dailyInputs = await getCompletedDailyInputs(forecastTargetDate);

    // 3. Deterministically evaluate certified station models
    const forecastResult = evaluateDailyForecasts({
        dailyInputs,
        customDates: {
            sourceDataDate: dailyInputs.sourceDataDate,
            forecastTargetDate,
        },
    });

    // 4. Upsert into MongoDB for idempotent persistence
    const saveOperations = Object.values(forecastResult.stations).map(async (st) => {
        const filter = { stationId: st.stationId, forecastTargetDate: st.forecastTargetDate };
        const update = {
            stationId: st.stationId,
            forecastTargetDate: st.forecastTargetDate,
            sourceDataDate: st.sourceDataDate,
            predictedWaterLevel: st.predictedWaterLevel,
            unit: st.unit,
            calculationMode: st.calculationMode,
            fallbackReason: st.fallbackReason,
            candidateId: st.selectedCandidate,
            modelVersion: st.modelVersion,
            targetSemantics: st.targetSemantics,
            statusBand: st.statusBand,
            status: st.status,
            thresholds: st.thresholds,
            thresholdMappingAllowed: st.thresholdMappingAllowed,
            inputsUsed: st.inputsUsed,
            missingInputs: st.missingInputs,
            updatedAt: new Date(),
        };

        return await DailyForecast.findOneAndUpdate(filter, update, {
            upsert: true,
            new: true,
            setDefaultsOnInsert: true,
        });
    });

    const persistedForecasts = await Promise.all(saveOperations);

    return {
        success: true,
        forecastTargetDate,
        sourceDataDate: dailyInputs.sourceDataDate,
        antecedentDate3: dailyInputs.antecedentDate3,
        overall_status: forecastResult.overall_status,
        stations: forecastResult.stations,
        persistedCount: persistedForecasts.length,
    };
};
